package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.AmbientNoirMood
import com.example.audio.SoundCue
import com.example.audio.SoundManager
import com.example.data.Case01SilentRoom
import com.example.data.EvidenceRepository
import com.example.data.GameProgressRepository
import com.example.data.InterrogationEngine
import com.example.data.LocalGameData
import com.example.data.LocalizedCaseData
import com.example.data.LocalizedStrings
import com.example.data.UiStrings
import com.example.model.AppLanguage
import com.example.model.ClueCategory
import com.example.model.DetectiveNote
import com.example.model.EndingResult
import com.example.model.EvidenceItem
import com.example.model.GameScreen
import com.example.model.GameSettings
import com.example.model.InterrogationFeedback
import com.example.model.InvestigationFlowPhase
import com.example.model.InvestigationProgress
import com.example.model.NoteCategory
import com.example.model.SuspectId
import java.util.UUID
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class BoardFeedback(
    val title: String,
    val message: String,
    val isMatch: Boolean
)

data class GameUiState(
    val isLoading: Boolean = true,
    val flowPhase: InvestigationFlowPhase = InvestigationFlowPhase.MAIN_MENU,
    val currentScreen: GameScreen = GameScreen.MAIN_MENU,
    val screenHistory: List<GameScreen> = emptyList(),
    val progress: InvestigationProgress = InvestigationProgress(),
    val settings: GameSettings = GameSettings(),
    val strings: UiStrings = LocalizedStrings.get(AppLanguage.ENGLISH),
    val caseData: LocalizedCaseData = LocalGameData.getCase(AppLanguage.ENGLISH),
    val activeZoneId: String? = Case01SilentRoom.CRIME_ZONES.first().id,
    val activeZoneOutcomeText: String? = null,
    val selectedBoardClueId: String? = null,
    val boardFeedback: BoardFeedback? = null,
    val latestContradictionBanner: String? = null,
    val interrogationFeedback: InterrogationFeedback? = null,
    val endingResult: EndingResult? = null,
    val accusationSuspect: SuspectId? = null,
    val accusationEvidenceIds: List<String> = emptyList(),
    val accusationMethodId: String = Case01SilentRoom.TRUE_METHOD_ID,
    val toastMessage: String? = null
)

class GameStateViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = GameProgressRepository(application.applicationContext)
    val evidenceRepository = EvidenceRepository()
    val soundManager = SoundManager()

    val collectedEvidence: StateFlow<List<EvidenceItem>> = evidenceRepository.evidenceItems

    private val _uiState = MutableStateFlow(GameUiState())
    val uiState: StateFlow<GameUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            val savedSettings = repository.settingsFlow.first()
            soundManager.setMuted(savedSettings.isMuted)
            soundManager.setAmbientEnabled(savedSettings.ambientMusicEnabled)
            soundManager.setAmbientMood(SoundManager.moodForScreen(_uiState.value.currentScreen))
            val savedProgress = repository.progressFlow.first()
            val caseData = LocalGameData.getCase(savedSettings.language)
            val strings = LocalizedStrings.get(savedSettings.language)
            evidenceRepository.syncFromProgress(
                collectedClueIds = savedProgress.collectedClues,
                discoveredConnections = savedProgress.discoveredConnections,
                caseData = caseData
            )
            val restoredEnding = savedProgress.achievedEndingId?.let {
                savedProgress.accusedSuspect?.let { accused ->
                    caseData.evaluateEnding(
                        accused,
                        savedProgress.accusedEvidenceIds,
                        savedProgress.accusedMethodId ?: Case01SilentRoom.TRUE_METHOD_ID,
                        savedProgress.discoveredConnections,
                        savedProgress.recordedDecisions
                    )
                }
            }
            _uiState.update {
                it.copy(
                    isLoading = false,
                    settings = savedSettings,
                    strings = strings,
                    caseData = caseData,
                    progress = savedProgress,
                    endingResult = restoredEnding
                )
            }
        }
    }

    fun addEvidence(clueId: String): EvidenceItem? {
        val state = _uiState.value
        val added = evidenceRepository.addEvidence(
            clueId = clueId,
            caseData = state.caseData,
            discoveredConnections = state.progress.discoveredConnections
        ) ?: return null

        if (clueId !in state.progress.collectedClues) {
            val updatedProgress = state.progress.copy(
                hasActiveInvestigation = true,
                collectedClues = state.progress.collectedClues + clueId
            )
            _uiState.update { it.copy(progress = updatedProgress) }
            persistCurrentProgress()
        }
        return added
    }

    fun listEvidence(categoryFilter: ClueCategory? = null): List<EvidenceItem> {
        return evidenceRepository.listEvidence(categoryFilter)
    }

    fun examineEvidence(clueId: String) {
        soundManager.onDossierOrPageTurn()
        evidenceRepository.markEvidenceExamined(clueId)
    }

    fun saveDetectiveNote(
        noteId: String? = null,
        title: String,
        body: String,
        category: NoteCategory = NoteCategory.GENERAL,
        linkedSuspectId: SuspectId? = null,
        linkedClueId: String? = null
    ): DetectiveNote? {
        val trimmedBody = body.trim()
        if (trimmedBody.isEmpty()) return null
        val trimmedTitle = title.trim()
        val now = System.currentTimeMillis()

        var savedNote: DetectiveNote? = null
        _uiState.update { state ->
            val existingNotes = state.progress.detectiveNotes
            val existingMatch = noteId?.let { id -> existingNotes.firstOrNull { it.id == id } }
            val note = if (existingMatch != null) {
                existingMatch.copy(
                    title = trimmedTitle,
                    body = trimmedBody,
                    category = category,
                    linkedSuspectId = linkedSuspectId,
                    linkedClueId = linkedClueId,
                    updatedAtMillis = now
                )
            } else {
                DetectiveNote(
                    id = noteId ?: "note_${UUID.randomUUID().toString().take(8)}",
                    title = trimmedTitle,
                    body = trimmedBody,
                    category = category,
                    linkedSuspectId = linkedSuspectId,
                    linkedClueId = linkedClueId,
                    isPinned = false,
                    updatedAtMillis = now
                )
            }
            savedNote = note
            val updatedList = if (existingMatch != null) {
                existingNotes.map { if (it.id == existingMatch.id) note else it }
            } else {
                listOf(note) + existingNotes
            }
            state.copy(
                progress = state.progress.copy(
                    hasActiveInvestigation = true,
                    detectiveNotes = updatedList
                ),
                toastMessage = state.strings.noteSavedToast
            )
        }
        soundManager.playEffect(SoundCue.PAGE_TURN)
        persistCurrentProgress()
        return savedNote
    }

    fun togglePinDetectiveNote(noteId: String) {
        soundManager.playEffect(SoundCue.CLICK)
        _uiState.update { state ->
            val updatedNotes = state.progress.detectiveNotes.map { note ->
                if (note.id == noteId) note.copy(isPinned = !note.isPinned) else note
            }
            state.copy(progress = state.progress.copy(detectiveNotes = updatedNotes))
        }
        persistCurrentProgress()
    }

    fun deleteDetectiveNote(noteId: String) {
        soundManager.playEffect(SoundCue.CLICK)
        _uiState.update { state ->
            val updatedNotes = state.progress.detectiveNotes.filterNot { it.id == noteId }
            state.copy(
                progress = state.progress.copy(detectiveNotes = updatedNotes),
                toastMessage = state.strings.noteDeletedToast
            )
        }
        persistCurrentProgress()
    }

    fun setLanguage(language: AppLanguage) {
        if (_uiState.value.settings.language == language) return
        soundManager.onDossierOrPageTurn()
        val updatedSettings = _uiState.value.settings.copy(language = language)
        val newCaseData = LocalGameData.getCase(language)
        val newStrings = LocalizedStrings.get(language)
        val currentProgress = _uiState.value.progress
        evidenceRepository.syncFromProgress(
            collectedClueIds = currentProgress.collectedClues,
            discoveredConnections = currentProgress.discoveredConnections,
            caseData = newCaseData
        )
        _uiState.update { state ->
            val updatedEnding = state.progress.accusedSuspect?.let { accused ->
                if (state.progress.achievedEndingId != null) {
                    newCaseData.evaluateEnding(
                        accused,
                        state.progress.accusedEvidenceIds,
                        state.progress.accusedMethodId ?: Case01SilentRoom.TRUE_METHOD_ID,
                        state.progress.discoveredConnections,
                        state.progress.recordedDecisions
                    )
                } else {
                    state.endingResult
                }
            }
            state.copy(
                settings = updatedSettings,
                strings = newStrings,
                caseData = newCaseData,
                activeZoneOutcomeText = null,
                boardFeedback = null,
                latestContradictionBanner = null,
                interrogationFeedback = null,
                endingResult = updatedEnding
            )
        }
        viewModelScope.launch { repository.updateSettings(updatedSettings) }
    }

    fun navigateTo(screen: GameScreen, recordInHistory: Boolean = true) {
        val fromScreen = _uiState.value.currentScreen
        soundManager.onScreenTransition(fromScreen, screen)
        _uiState.update { state ->
            val newHistory = if (recordInHistory && state.currentScreen != screen) {
                state.screenHistory + state.currentScreen
            } else {
                state.screenHistory
            }
            val updatedProgress = if (isInvestigationScreen(screen) && state.progress.hasActiveInvestigation) {
                state.progress.copy(currentScreen = screen)
            } else {
                state.progress
            }
            state.copy(
                flowPhase = phaseForScreen(screen),
                currentScreen = screen,
                screenHistory = newHistory,
                progress = updatedProgress,
                latestContradictionBanner = null,
                interrogationFeedback = null,
                boardFeedback = null
            )
        }
        persistCurrentProgress()
    }

    fun openMainMenu() {
        navigateTo(GameScreen.MAIN_MENU, recordInHistory = false)
    }

    fun enterInvestigationPhase() {
        navigateTo(GameScreen.CRIME_SCENE)
    }

    fun enterInterrogationPhase(suspectId: SuspectId? = null) {
        if (suspectId != null) {
            openInterrogation(suspectId)
        } else {
            navigateTo(GameScreen.SUSPECT_SELECTION)
        }
    }

    fun navigateBack(): Boolean {
        val state = _uiState.value
        if (state.currentScreen == GameScreen.MAIN_MENU) return false
        val previous = state.screenHistory.lastOrNull() ?: GameScreen.MAIN_MENU
        soundManager.onScreenTransition(state.currentScreen, previous)
        val trimmedHistory = if (state.screenHistory.isNotEmpty()) {
            state.screenHistory.dropLast(1)
        } else {
            emptyList()
        }
        _uiState.update {
            it.copy(
                flowPhase = phaseForScreen(previous),
                currentScreen = previous,
                screenHistory = trimmedHistory,
                latestContradictionBanner = null,
                interrogationFeedback = null,
                boardFeedback = null
            )
        }
        return true
    }

    fun startNewInvestigation() {
        val fromScreen = _uiState.value.currentScreen
        soundManager.onScreenTransition(fromScreen, GameScreen.CASE_INTRO)
        evidenceRepository.clear()
        val caseData = _uiState.value.caseData
        val initialStress = caseData.suspects.associate { it.id to it.baseStress }
        val initialNodes = SuspectId.entries.associateWith { Case01SilentRoom.getInitialNodeId(it) }
        val history = _uiState.value.progress.unlockedEndingsHistory
        val freshProgress = InvestigationProgress(
            hasActiveInvestigation = true,
            currentScreen = GameScreen.CASE_INTRO,
            suspectStress = initialStress,
            currentDialogueBySuspect = initialNodes,
            selectedSuspect = SuspectId.VICTOR,
            unlockedEndingsHistory = history
        )
        _uiState.update {
            it.copy(
                flowPhase = InvestigationFlowPhase.INVESTIGATION,
                currentScreen = GameScreen.CASE_INTRO,
                screenHistory = listOf(GameScreen.MAIN_MENU),
                progress = freshProgress,
                activeZoneId = caseData.crimeZones.first().id,
                activeZoneOutcomeText = null,
                selectedBoardClueId = null,
                boardFeedback = null,
                latestContradictionBanner = null,
                interrogationFeedback = null,
                endingResult = null,
                accusationSuspect = null,
                accusationEvidenceIds = emptyList(),
                accusationMethodId = Case01SilentRoom.TRUE_METHOD_ID
            )
        }
        persistCurrentProgress()
    }

    fun continueInvestigation() {
        val progress = _uiState.value.progress
        if (!progress.hasActiveInvestigation) return
        val fromScreen = _uiState.value.currentScreen
        val target = if (progress.achievedEndingId != null && _uiState.value.endingResult != null) {
            GameScreen.ENDING
        } else if (isInvestigationScreen(progress.currentScreen)) {
            progress.currentScreen
        } else {
            GameScreen.CRIME_SCENE
        }
        soundManager.onScreenTransition(fromScreen, target)
        _uiState.update {
            it.copy(
                flowPhase = phaseForScreen(target),
                currentScreen = target,
                screenHistory = listOf(GameScreen.MAIN_MENU)
            )
        }
    }

    fun selectCrimeZone(zoneId: String) {
        if (_uiState.value.activeZoneId != zoneId) {
            soundManager.onZoneChanged()
        } else {
            soundManager.playEffect(SoundCue.CLICK)
        }
        _uiState.update {
            it.copy(activeZoneId = zoneId, activeZoneOutcomeText = null)
        }
    }

    fun inspectCrimeZone(zoneId: String, thorough: Boolean) {
        val state = _uiState.value
        val zone = state.caseData.crimeZones.firstOrNull { it.id == zoneId } ?: return
        val currentProgress = state.progress
        val alreadyInspected = zoneId in currentProgress.inspectedZones

        val updatedClues = currentProgress.collectedClues + zone.clueIds
        evidenceRepository.addEvidenceBatch(
            clueIds = zone.clueIds,
            caseData = state.caseData,
            discoveredConnections = currentProgress.discoveredConnections
        )
        val decisionTag = if (thorough) zone.carefulDecisionTag else zone.quickDecisionTag
        val updatedDecisions = if (!alreadyInspected) {
            currentProgress.recordedDecisions + decisionTag
        } else {
            currentProgress.recordedDecisions
        }
        val outcome = if (thorough) zone.carefulOutcome else zone.quickOutcome

        soundManager.playEffect(if (!alreadyInspected) SoundCue.CLUE_FOUND else SoundCue.PAGE_TURN)

        val updatedProgress = currentProgress.copy(
            hasActiveInvestigation = true,
            inspectedZones = currentProgress.inspectedZones + zoneId,
            collectedClues = updatedClues,
            recordedDecisions = updatedDecisions
        )

        _uiState.update {
            it.copy(
                progress = updatedProgress,
                activeZoneOutcomeText = outcome,
                toastMessage = if (!alreadyInspected) {
                    "+${zone.clueIds.size} ${state.strings.cluesLabel}: ${zone.name}"
                } else {
                    state.strings.evidenceLoggedBadge
                }
            )
        }
        persistCurrentProgress()
    }

    fun openInterrogation(suspectId: SuspectId) {
        val fromScreen = _uiState.value.currentScreen
        soundManager.onScreenTransition(fromScreen, GameScreen.INTERROGATION)
        _uiState.update { state ->
            val currentNodeMap = state.progress.currentDialogueBySuspect.toMutableMap()
            if (!currentNodeMap.containsKey(suspectId)) {
                currentNodeMap[suspectId] = Case01SilentRoom.getInitialNodeId(suspectId)
            }
            val visited = state.progress.visitedDialogueNodes + currentNodeMap.getValue(suspectId)
            state.copy(
                flowPhase = InvestigationFlowPhase.INTERROGATION,
                currentScreen = GameScreen.INTERROGATION,
                screenHistory = state.screenHistory + state.currentScreen,
                progress = state.progress.copy(
                    currentScreen = GameScreen.INTERROGATION,
                    selectedSuspect = suspectId,
                    currentDialogueBySuspect = currentNodeMap,
                    visitedDialogueNodes = visited
                ),
                latestContradictionBanner = null,
                interrogationFeedback = null
            )
        }
        persistCurrentProgress()
    }

    fun selectDialogueOption(optionId: String) {
        val state = _uiState.value
        val suspectId = state.progress.selectedSuspect
        val currentNodeId = state.progress.currentDialogueBySuspect[suspectId]
            ?: Case01SilentRoom.getInitialNodeId(suspectId)
        val currentNode = state.caseData.dialogueNodes[currentNodeId] ?: return
        val option = currentNode.options.firstOrNull { it.id == optionId } ?: return
        val nextNode = state.caseData.dialogueNodes[option.nextNodeId] ?: return

        val currentStress = state.progress.suspectStress[suspectId]
            ?: state.caseData.suspects.first { it.id == suspectId }.baseStress
        val newStress = (currentStress + nextNode.stressDelta).coerceIn(5, 100)

        val newContradictions = if (nextNode.contradictionFound != null) {
            state.progress.detectedContradictions + nextNode.id
        } else {
            state.progress.detectedContradictions
        }
        val isNewContradiction = nextNode.contradictionFound != null &&
            nextNode.id !in state.progress.detectedContradictions

        if (isNewContradiction) {
            soundManager.playEffect(SoundCue.CONTRADICTION)
        } else {
            soundManager.playEffect(SoundCue.CLICK)
        }

        val updatedDecisions = if (option.decisionTag != null && option.decisionTag !in state.progress.recordedDecisions) {
            state.progress.recordedDecisions + option.decisionTag
        } else {
            state.progress.recordedDecisions
        }

        val updatedClues = if (nextNode.unlocksClueId != null) {
            evidenceRepository.addEvidence(
                clueId = nextNode.unlocksClueId,
                caseData = state.caseData,
                discoveredConnections = state.progress.discoveredConnections
            )
            state.progress.collectedClues + nextNode.unlocksClueId
        } else {
            state.progress.collectedClues
        }

        val updatedProgress = state.progress.copy(
            currentDialogueBySuspect = state.progress.currentDialogueBySuspect + (suspectId to nextNode.id),
            visitedDialogueNodes = state.progress.visitedDialogueNodes + nextNode.id,
            suspectStress = state.progress.suspectStress + (suspectId to newStress),
            detectedContradictions = newContradictions,
            recordedDecisions = updatedDecisions,
            collectedClues = updatedClues
        )

        _uiState.update {
            it.copy(
                progress = updatedProgress,
                latestContradictionBanner = nextNode.contradictionFound,
                interrogationFeedback = null
            )
        }
        persistCurrentProgress()
    }

    fun presentEvidenceToSuspect(clueId: String) {
        val state = _uiState.value
        val evidence = evidenceRepository.getEvidenceById(clueId) ?: return
        evidenceRepository.markEvidenceExamined(clueId)

        val suspectId = state.progress.selectedSuspect
        val outcome = InterrogationEngine.evaluateEvidencePresentation(
            suspectId = suspectId,
            evidence = evidence,
            discoveredConnections = state.progress.discoveredConnections,
            language = state.settings.language
        )

        val currentStress = state.progress.suspectStress[suspectId]
            ?: state.caseData.suspects.first { it.id == suspectId }.baseStress
        val targetNode = outcome.targetNodeId?.let { state.caseData.dialogueNodes[it] }
        val nodeStressDelta = targetNode?.stressDelta ?: 0
        val newStress = (currentStress + outcome.stressDelta + nodeStressDelta).coerceIn(5, 100)

        val updatedNodeMap = if (targetNode != null) {
            state.progress.currentDialogueBySuspect + (suspectId to targetNode.id)
        } else {
            state.progress.currentDialogueBySuspect
        }

        val updatedVisited = if (targetNode != null) {
            state.progress.visitedDialogueNodes + targetNode.id
        } else {
            state.progress.visitedDialogueNodes
        }

        val contradictionText = targetNode?.contradictionFound
        val updatedContradictions = if (contradictionText != null && targetNode != null) {
            state.progress.detectedContradictions + targetNode.id
        } else {
            state.progress.detectedContradictions
        }

        if (outcome.isContradiction || contradictionText != null) {
            soundManager.playEffect(SoundCue.CONTRADICTION)
        } else {
            soundManager.playEffect(SoundCue.PAGE_TURN)
        }

        val updatedProgress = state.progress.copy(
            currentDialogueBySuspect = updatedNodeMap,
            visitedDialogueNodes = updatedVisited,
            suspectStress = state.progress.suspectStress + (suspectId to newStress),
            detectedContradictions = updatedContradictions
        )

        _uiState.update {
            it.copy(
                progress = updatedProgress,
                latestContradictionBanner = contradictionText,
                interrogationFeedback = InterrogationFeedback(
                    title = outcome.feedbackTitle,
                    message = outcome.feedbackMessage,
                    isContradiction = outcome.isContradiction,
                    presentedEvidenceTitle = evidence.title
                )
            )
        }
        persistCurrentProgress()
    }

    fun pressCurrentStatement() {
        val state = _uiState.value
        val suspectId = state.progress.selectedSuspect
        val currentNodeId = state.progress.currentDialogueBySuspect[suspectId]
            ?: Case01SilentRoom.getInitialNodeId(suspectId)
        val currentStress = state.progress.suspectStress[suspectId]
            ?: state.caseData.suspects.first { it.id == suspectId }.baseStress

        val outcome = InterrogationEngine.pressStatement(
            suspectId = suspectId,
            currentNodeId = currentNodeId,
            currentStress = currentStress,
            language = state.settings.language
        )

        val newStress = (currentStress + outcome.stressDelta).coerceIn(5, 100)
        soundManager.playEffect(if (outcome.exposesWeakness) SoundCue.CONTRADICTION else SoundCue.HEARTBEAT)

        val updatedProgress = state.progress.copy(
            suspectStress = state.progress.suspectStress + (suspectId to newStress)
        )

        _uiState.update {
            it.copy(
                progress = updatedProgress,
                interrogationFeedback = InterrogationFeedback(
                    title = outcome.feedbackTitle,
                    message = outcome.feedbackMessage,
                    isContradiction = outcome.exposesWeakness
                )
            )
        }
        persistCurrentProgress()
    }

    fun onBoardClueTapped(clueId: String) {
        val state = _uiState.value
        val firstSelected = state.selectedBoardClueId
        if (firstSelected == null) {
            soundManager.playEffect(SoundCue.CLICK)
            _uiState.update {
                it.copy(selectedBoardClueId = clueId, boardFeedback = null)
            }
            return
        }
        if (firstSelected == clueId) {
            soundManager.playEffect(SoundCue.CLICK)
            _uiState.update {
                it.copy(selectedBoardClueId = null)
            }
            return
        }

        val connection = state.caseData.clueConnections.firstOrNull {
            (it.clueAId == firstSelected && it.clueBId == clueId) ||
                (it.clueAId == clueId && it.clueBId == firstSelected)
        }
        if (connection != null) {
            val isNew = connection.id !in state.progress.discoveredConnections
            soundManager.playEffect(SoundCue.CONNECTION_LINKED)
            val newConnections = state.progress.discoveredConnections + connection.id
            val updatedProgress = state.progress.copy(
                discoveredConnections = newConnections
            )
            evidenceRepository.syncFromProgress(
                collectedClueIds = updatedProgress.collectedClues,
                discoveredConnections = newConnections,
                caseData = state.caseData
            )
            val prefix = if (isNew) state.strings.deductionLinkedPrefix else state.strings.verifiedLinkPrefix
            _uiState.update {
                it.copy(
                    progress = updatedProgress,
                    selectedBoardClueId = null,
                    boardFeedback = BoardFeedback(
                        title = "$prefix: ${connection.title}",
                        message = "${connection.deductionSummary}\n${state.strings.leadPrefix}: ${connection.unlocksHint}",
                        isMatch = true
                    )
                )
            }
            persistCurrentProgress()
        } else {
            soundManager.playEffect(SoundCue.CLICK)
            val c1 = state.caseData.clues.firstOrNull { it.id == firstSelected }?.title ?: "Clue"
            val c2 = state.caseData.clues.firstOrNull { it.id == clueId }?.title ?: "Clue"
            _uiState.update {
                it.copy(
                    selectedBoardClueId = null,
                    boardFeedback = BoardFeedback(
                        title = state.strings.noLinkTitle,
                        message = state.caseData.noLinkReasoning(c1, c2),
                        isMatch = false
                    )
                )
            }
        }
    }

    fun selectAccusationSuspect(suspectId: SuspectId) {
        soundManager.playEffect(SoundCue.CLICK)
        _uiState.update { it.copy(accusationSuspect = suspectId) }
    }

    fun toggleAccusationEvidence(clueId: String) {
        soundManager.playEffect(SoundCue.PAGE_TURN)
        _uiState.update { state ->
            val current = state.accusationEvidenceIds
            val updated = if (clueId in current) {
                current - clueId
            } else if (current.size < 3) {
                current + clueId
            } else {
                current.drop(1) + clueId
            }
            state.copy(accusationEvidenceIds = updated)
        }
    }

    fun selectAccusationMethod(methodId: String) {
        soundManager.playEffect(SoundCue.CLICK)
        _uiState.update { it.copy(accusationMethodId = methodId) }
    }

    fun submitFinalAccusation() {
        val state = _uiState.value
        val suspect = state.accusationSuspect ?: return
        if (state.accusationEvidenceIds.size < 2) return

        soundManager.setAmbientMood(AmbientNoirMood.CONCLUSION_NOIR)
        soundManager.playEffect(SoundCue.VERDICT)
        val result = state.caseData.evaluateEnding(
            suspect,
            state.accusationEvidenceIds,
            state.accusationMethodId,
            state.progress.discoveredConnections,
            state.progress.recordedDecisions
        )

        val updatedProgress = state.progress.copy(
            currentScreen = GameScreen.ENDING,
            accusedSuspect = suspect,
            accusedEvidenceIds = state.accusationEvidenceIds,
            accusedMethodId = state.accusationMethodId,
            achievedEndingId = result.id,
            unlockedEndingsHistory = state.progress.unlockedEndingsHistory + result.id
        )

        _uiState.update {
            it.copy(
                flowPhase = InvestigationFlowPhase.CONCLUSION,
                currentScreen = GameScreen.ENDING,
                screenHistory = it.screenHistory + GameScreen.ACCUSATION,
                progress = updatedProgress,
                endingResult = result
            )
        }
        persistCurrentProgress()
    }

    fun toggleMute() {
        val next = _uiState.value.settings.copy(isMuted = !_uiState.value.settings.isMuted)
        soundManager.setMuted(next.isMuted)
        if (!next.isMuted) soundManager.playEffect(SoundCue.CLICK)
        _uiState.update { it.copy(settings = next) }
        viewModelScope.launch { repository.updateSettings(next) }
    }

    fun toggleAmbientMusic() {
        val next = _uiState.value.settings.copy(ambientMusicEnabled = !_uiState.value.settings.ambientMusicEnabled)
        soundManager.setAmbientEnabled(next.ambientMusicEnabled)
        soundManager.playEffect(SoundCue.CLICK)
        _uiState.update { it.copy(settings = next) }
        viewModelScope.launch { repository.updateSettings(next) }
    }

    fun toggleHints() {
        soundManager.playEffect(SoundCue.CLICK)
        val next = _uiState.value.settings.copy(hintsEnabled = !_uiState.value.settings.hintsEnabled)
        _uiState.update { it.copy(settings = next) }
        viewModelScope.launch { repository.updateSettings(next) }
    }

    fun toggleFastTypewriter() {
        soundManager.playEffect(SoundCue.CLICK)
        val next = _uiState.value.settings.copy(fastTypewriter = !_uiState.value.settings.fastTypewriter)
        _uiState.update { it.copy(settings = next) }
        viewModelScope.launch { repository.updateSettings(next) }
    }

    fun resetAllSavedData() {
        soundManager.playEffect(SoundCue.CLICK)
        evidenceRepository.clear()
        viewModelScope.launch {
            repository.clearCurrentInvestigation(keepHistory = false)
            _uiState.update {
                it.copy(
                    progress = InvestigationProgress(),
                    endingResult = null,
                    toastMessage = it.strings.resetButton
                )
            }
        }
    }

    fun onAppForeground() {
        soundManager.onAppForeground()
    }

    fun onAppBackground() {
        soundManager.onAppBackground()
    }

    fun clearToast() {
        _uiState.update { it.copy(toastMessage = null) }
    }

    override fun onCleared() {
        super.onCleared()
        soundManager.release()
    }

    private fun persistCurrentProgress() {
        val snapshot = _uiState.value.progress
        viewModelScope.launch {
            repository.saveProgress(snapshot)
        }
    }

    private fun phaseForScreen(screen: GameScreen): InvestigationFlowPhase = when (screen) {
        GameScreen.MAIN_MENU,
        GameScreen.CASE_FILES,
        GameScreen.SETTINGS,
        GameScreen.CREDITS -> InvestigationFlowPhase.MAIN_MENU

        GameScreen.CASE_INTRO,
        GameScreen.CRIME_SCENE,
        GameScreen.EVIDENCE_BOARD,
        GameScreen.NOTEBOOK,
        GameScreen.ACCUSATION -> InvestigationFlowPhase.INVESTIGATION

        GameScreen.SUSPECT_SELECTION,
        GameScreen.INTERROGATION -> InvestigationFlowPhase.INTERROGATION

        GameScreen.ENDING -> InvestigationFlowPhase.CONCLUSION
    }

    private fun isInvestigationScreen(screen: GameScreen): Boolean = when (screen) {
        GameScreen.CASE_INTRO,
        GameScreen.CRIME_SCENE,
        GameScreen.SUSPECT_SELECTION,
        GameScreen.INTERROGATION,
        GameScreen.EVIDENCE_BOARD,
        GameScreen.NOTEBOOK,
        GameScreen.ACCUSATION,
        GameScreen.ENDING -> true
        else -> false
    }
}
