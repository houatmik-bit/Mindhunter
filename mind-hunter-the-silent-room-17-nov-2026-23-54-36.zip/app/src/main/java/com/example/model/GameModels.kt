package com.example.model

import androidx.annotation.DrawableRes

enum class AppLanguage(
    val code: String,
    val nativeLabel: String,
    val isRtl: Boolean
) {
    ENGLISH("en", "English", false),
    FRENCH("fr", "Français", false),
    ARABIC("ar", "العربية", true);

    companion object {
        fun fromCode(code: String?): AppLanguage =
            entries.firstOrNull { it.code == code } ?: ENGLISH
    }
}

enum class GameScreen {
    MAIN_MENU,
    CASE_FILES,
    SETTINGS,
    CREDITS,
    CASE_INTRO,
    CRIME_SCENE,
    SUSPECT_SELECTION,
    INTERROGATION,
    EVIDENCE_BOARD,
    NOTEBOOK,
    ACCUSATION,
    ENDING
}

enum class InvestigationFlowPhase {
    MAIN_MENU,
    INVESTIGATION,
    INTERROGATION,
    CONCLUSION
}

enum class SuspectId(val displayName: String) {
    VICTOR("Victor Vance"),
    ELENA("Elena Thorne"),
    ADRIAN("Adrian Cole"),
    MARCUS("Marcus Sterling")
}

enum class ClueCategory(val label: String) {
    FORENSIC("FORENSIC"),
    DOCUMENT("DOCUMENT"),
    PHYSICAL("PHYSICAL"),
    DIGITAL("DIGITAL")
}

data class Clue(
    val id: String,
    val title: String,
    val category: ClueCategory,
    val zoneId: String,
    val summary: String,
    val forensicDetail: String,
    val timestampHint: String
)

data class CrimeZone(
    val id: String,
    val name: String,
    val locationLabel: String,
    val hotspotXFraction: Float,
    val hotspotYFraction: Float,
    val initialDescription: String,
    val carefulActionLabel: String,
    val quickActionLabel: String,
    val carefulOutcome: String,
    val quickOutcome: String,
    val clueIds: List<String>,
    val decisionId: String,
    val carefulDecisionTag: String,
    val quickDecisionTag: String
)

data class ClueConnection(
    val id: String,
    val clueAId: String,
    val clueBId: String,
    val title: String,
    val deductionSummary: String,
    val unlocksSuspectId: SuspectId?,
    val unlocksHint: String
)

data class SuspectProfile(
    val id: SuspectId,
    val fullName: String,
    val role: String,
    val age: Int,
    @DrawableRes val portraitRes: Int,
    val personality: String,
    val alibiSummary: String,
    val motive: String,
    val hiddenSecret: String,
    val backstory: String,
    val baselineTell: String,
    val baseStress: Int
)

data class DialogueOption(
    val id: String,
    val prompt: String,
    val nextNodeId: String,
    val requiredClueId: String? = null,
    val requiredConnectionId: String? = null,
    val decisionTag: String? = null,
    val isPsychologicalPressure: Boolean = false
)

data class DialogueNode(
    val id: String,
    val suspectId: SuspectId,
    val speakerName: String,
    val text: String,
    val reactionTell: String,
    val stressDelta: Int = 0,
    val contradictionFound: String? = null,
    val psychologicalHint: String? = null,
    val unlocksClueId: String? = null,
    val options: List<DialogueOption>
)

data class MethodTheory(
    val id: String,
    val title: String,
    val description: String
)

data class ForensicManualEntry(
    val id: String,
    val code: String,
    val title: String,
    val summary: String
)

data class EndingResult(
    val id: String,
    val title: String,
    val subtitle: String,
    val verdictBadge: String,
    val isSolvedCorrectly: Boolean,
    val narrativeSummary: String,
    val profilerRating: String
)

data class GameSettings(
    val isMuted: Boolean = false,
    val ambientMusicEnabled: Boolean = true,
    val hintsEnabled: Boolean = true,
    val fastTypewriter: Boolean = false,
    val language: AppLanguage = AppLanguage.ENGLISH
)

data class EvidenceItem(
    val id: String,
    val title: String,
    val category: ClueCategory,
    val zoneId: String,
    val summary: String,
    val forensicDetail: String,
    val timestampHint: String,
    val collectedAtMillis: Long = System.currentTimeMillis(),
    val isExamined: Boolean = false,
    val linkedConnectionIds: List<String> = emptyList()
)

enum class SuspectComposure {
    CALM,
    DEFENSIVE,
    RATTLED,
    CORNERED,
    BROKEN
}

data class InterrogationFeedback(
    val title: String,
    val message: String,
    val isContradiction: Boolean,
    val presentedEvidenceTitle: String? = null
)

enum class NoteCategory {
    GENERAL,
    SUSPECT,
    CLUE,
    THEORY
}

data class DetectiveNote(
    val id: String,
    val title: String,
    val body: String,
    val category: NoteCategory = NoteCategory.GENERAL,
    val linkedSuspectId: SuspectId? = null,
    val linkedClueId: String? = null,
    val isPinned: Boolean = false,
    val updatedAtMillis: Long = System.currentTimeMillis()
)

data class InvestigationProgress(
    val caseId: String = "CASE_MH_01",
    val hasActiveInvestigation: Boolean = false,
    val currentScreen: GameScreen = GameScreen.CRIME_SCENE,
    val inspectedZones: Set<String> = emptySet(),
    val collectedClues: Set<String> = emptySet(),
    val discoveredConnections: Set<String> = emptySet(),
    val visitedDialogueNodes: Set<String> = emptySet(),
    val detectedContradictions: Set<String> = emptySet(),
    val suspectStress: Map<SuspectId, Int> = emptyMap(),
    val currentDialogueBySuspect: Map<SuspectId, String> = emptyMap(),
    val selectedSuspect: SuspectId = SuspectId.VICTOR,
    val recordedDecisions: List<String> = emptyList(),
    val detectiveNotes: List<DetectiveNote> = emptyList(),
    val accusedSuspect: SuspectId? = null,
    val accusedEvidenceIds: List<String> = emptyList(),
    val accusedMethodId: String? = null,
    val achievedEndingId: String? = null,
    val unlockedEndingsHistory: Set<String> = emptySet()
) {
    val completionPercentage: Int
        get() {
            val cluePart = (collectedClues.size / 8f) * 45f
            val connPart = (discoveredConnections.size / 5f) * 35f
            val contraPart = (detectedContradictions.size.coerceAtMost(4) / 4f) * 20f
            return (cluePart + connPart + contraPart).toInt().coerceIn(0, 100)
        }
}
