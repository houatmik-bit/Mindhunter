package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.Case01SilentRoom
import com.example.model.GameScreen
import com.example.ui.components.AnimatedNoirBackdrop
import com.example.ui.components.InvestigationBottomBar
import com.example.ui.components.InvestigationTopBar
import com.example.ui.screens.AccusationScreen
import com.example.ui.screens.CaseFilesScreen
import com.example.ui.screens.CaseIntroScreen
import com.example.ui.screens.CreditsScreen
import com.example.ui.screens.CrimeSceneScreen
import com.example.ui.screens.EndingScreen
import com.example.ui.screens.EvidenceBoardScreen
import com.example.ui.screens.InterrogationScreen
import com.example.ui.screens.MainMenuScreen
import com.example.ui.screens.NotebookScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SuspectSelectionScreen
import com.example.ui.theme.MindHunterTheme
import com.example.ui.theme.NoirBlack
import com.example.viewmodel.GameStateViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MindHunterTheme {
                MindHunterRootApp()
            }
        }
    }
}

@Composable
fun MindHunterRootApp(
    viewModel: GameStateViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val collectedEvidence by viewModel.collectedEvidence.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val strings = uiState.strings
    val caseData = uiState.caseData
    val lifecycleOwner = LocalLifecycleOwner.current

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> viewModel.onAppForeground()
                Lifecycle.Event.ON_STOP -> viewModel.onAppBackground()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    LaunchedEffect(uiState.toastMessage) {
        uiState.toastMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearToast()
        }
    }

    val showHubChrome = uiState.currentScreen in setOf(
        GameScreen.CRIME_SCENE,
        GameScreen.SUSPECT_SELECTION,
        GameScreen.INTERROGATION,
        GameScreen.EVIDENCE_BOARD,
        GameScreen.NOTEBOOK,
        GameScreen.ACCUSATION
    )

    BackHandler(enabled = uiState.currentScreen != GameScreen.MAIN_MENU) {
        viewModel.navigateBack()
    }

    val layoutDirection = if (uiState.settings.language.isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr

    CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
        Scaffold(
            containerColor = NoirBlack,
            snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
            topBar = {
                if (showHubChrome) {
                    val title = when (uiState.currentScreen) {
                        GameScreen.CRIME_SCENE -> strings.topScene
                        GameScreen.SUSPECT_SELECTION -> strings.topSuspects
                        GameScreen.INTERROGATION -> strings.topInterrogation
                        GameScreen.EVIDENCE_BOARD -> strings.topBoard
                        GameScreen.NOTEBOOK -> strings.topNotebook
                        GameScreen.ACCUSATION -> strings.topAccuse
                        else -> caseData.caseTitle
                    }
                    InvestigationTopBar(
                        title = title,
                        subtitle = "${caseData.caseCode} · ${caseData.caseTitle}",
                        cluesCount = uiState.progress.collectedClues.size,
                        connectionsCount = uiState.progress.discoveredConnections.size,
                        cluesLabel = strings.cluesLabel,
                        linksLabel = strings.linksLabel,
                        isMuted = uiState.settings.isMuted,
                        isNotebookActive = uiState.currentScreen == GameScreen.NOTEBOOK,
                        notebookContentDesc = strings.openNotebookDesc,
                        onOpenNotebook = {
                            if (uiState.currentScreen == GameScreen.NOTEBOOK) {
                                viewModel.navigateBack()
                            } else {
                                viewModel.navigateTo(GameScreen.NOTEBOOK)
                            }
                        },
                        onBackClick = {
                            when (uiState.currentScreen) {
                                GameScreen.NOTEBOOK -> viewModel.navigateBack()
                                GameScreen.INTERROGATION -> viewModel.navigateTo(
                                    GameScreen.SUSPECT_SELECTION,
                                    recordInHistory = false
                                )
                                else -> viewModel.openMainMenu()
                            }
                        },
                        onToggleMute = { viewModel.toggleMute() }
                    )
                }
            },
            bottomBar = {
                if (showHubChrome) {
                    InvestigationBottomBar(
                        currentScreen = uiState.currentScreen,
                        navSceneLabel = strings.navScene,
                        navSuspectsLabel = strings.navSuspects,
                        navBoardLabel = strings.navBoard,
                        navAccuseLabel = strings.navAccuse,
                        onNavigate = { target -> viewModel.navigateTo(target) }
                    )
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(if (showHubChrome) innerPadding else PaddingValues())
            ) {
                if (showHubChrome) {
                    AnimatedNoirBackdrop(crimsonPulseIntensity = 0.14f)
                }

                AnimatedContent(
                    targetState = uiState.currentScreen,
                    transitionSpec = {
                        fadeIn(animationSpec = tween(240)) togetherWith fadeOut(animationSpec = tween(180))
                    },
                    label = "screen_transition"
                ) { screen ->
                    when (screen) {
                        GameScreen.MAIN_MENU -> MainMenuScreen(
                            progress = uiState.progress,
                            currentLanguage = uiState.settings.language,
                            strings = strings,
                            caseData = caseData,
                            isMuted = uiState.settings.isMuted,
                            onSelectLanguage = { viewModel.setLanguage(it) },
                            onNewInvestigation = { viewModel.startNewInvestigation() },
                            onContinueInvestigation = { viewModel.continueInvestigation() },
                            onNavigate = { viewModel.navigateTo(it) },
                            onToggleMute = { viewModel.toggleMute() }
                        )

                        GameScreen.CASE_FILES -> CaseFilesScreen(
                            progress = uiState.progress,
                            strings = strings,
                            caseData = caseData,
                            onStartOrContinue = {
                                if (uiState.progress.hasActiveInvestigation) {
                                    viewModel.continueInvestigation()
                                } else {
                                    viewModel.startNewInvestigation()
                                }
                            },
                            onBack = { viewModel.navigateBack() }
                        )

                        GameScreen.SETTINGS -> SettingsScreen(
                            settings = uiState.settings,
                            strings = strings,
                            onSelectLanguage = { viewModel.setLanguage(it) },
                            onToggleMute = { viewModel.toggleMute() },
                            onToggleAmbientMusic = { viewModel.toggleAmbientMusic() },
                            onToggleHints = { viewModel.toggleHints() },
                            onToggleFastText = { viewModel.toggleFastTypewriter() },
                            onResetSave = { viewModel.resetAllSavedData() },
                            onBack = { viewModel.navigateBack() }
                        )

                        GameScreen.CREDITS -> CreditsScreen(
                            strings = strings,
                            caseData = caseData,
                            onBack = { viewModel.navigateBack() }
                        )

                        GameScreen.CASE_INTRO -> CaseIntroScreen(
                            strings = strings,
                            caseData = caseData,
                            onEnterCrimeScene = { viewModel.enterInvestigationPhase() },
                            onBackToMenu = { viewModel.openMainMenu() }
                        )

                        GameScreen.CRIME_SCENE -> CrimeSceneScreen(
                            progress = uiState.progress,
                            strings = strings,
                            caseData = caseData,
                            activeZoneId = uiState.activeZoneId,
                            outcomeText = uiState.activeZoneOutcomeText,
                            onSelectZone = { viewModel.selectCrimeZone(it) },
                            onInspectZone = { zoneId, thorough -> viewModel.inspectCrimeZone(zoneId, thorough) },
                            onBack = { viewModel.openMainMenu() }
                        )

                        GameScreen.SUSPECT_SELECTION -> SuspectSelectionScreen(
                            progress = uiState.progress,
                            strings = strings,
                            caseData = caseData,
                            onSelectSuspect = { viewModel.enterInterrogationPhase(it) },
                            onBack = { viewModel.enterInvestigationPhase() }
                        )

                        GameScreen.INTERROGATION -> InterrogationScreen(
                            progress = uiState.progress,
                            collectedEvidence = collectedEvidence,
                            settings = uiState.settings,
                            strings = strings,
                            caseData = caseData,
                            latestContradiction = uiState.latestContradictionBanner,
                            interrogationFeedback = uiState.interrogationFeedback,
                            onSelectOption = { viewModel.selectDialogueOption(it) },
                            onPresentEvidence = { viewModel.presentEvidenceToSuspect(it) },
                            onPressStatement = { viewModel.pressCurrentStatement() },
                            onOpenEvidenceBoard = { viewModel.navigateTo(GameScreen.EVIDENCE_BOARD) },
                            onBackToSuspects = { viewModel.navigateTo(GameScreen.SUSPECT_SELECTION, recordInHistory = false) }
                        )

                        GameScreen.EVIDENCE_BOARD -> EvidenceBoardScreen(
                            progress = uiState.progress,
                            strings = strings,
                            caseData = caseData,
                            selectedClueId = uiState.selectedBoardClueId,
                            boardFeedback = uiState.boardFeedback,
                            onClueTapped = { viewModel.onBoardClueTapped(it) },
                            onGoToScene = { viewModel.navigateTo(GameScreen.CRIME_SCENE, recordInHistory = false) },
                            onBack = { viewModel.navigateTo(GameScreen.CRIME_SCENE, recordInHistory = false) }
                        )

                        GameScreen.NOTEBOOK -> NotebookScreen(
                            progress = uiState.progress,
                            collectedEvidence = collectedEvidence,
                            strings = strings,
                            caseData = caseData,
                            onSaveNote = { noteId, title, body, category, suspectId, clueId ->
                                viewModel.saveDetectiveNote(
                                    noteId = noteId,
                                    title = title,
                                    body = body,
                                    category = category,
                                    linkedSuspectId = suspectId,
                                    linkedClueId = clueId
                                )
                            },
                            onTogglePin = { viewModel.togglePinDetectiveNote(it) },
                            onDeleteNote = { viewModel.deleteDetectiveNote(it) },
                            onBack = { viewModel.navigateBack() }
                        )

                        GameScreen.ACCUSATION -> AccusationScreen(
                            progress = uiState.progress,
                            strings = strings,
                            caseData = caseData,
                            selectedSuspect = uiState.accusationSuspect,
                            selectedEvidenceIds = uiState.accusationEvidenceIds,
                            selectedMethodId = uiState.accusationMethodId,
                            onSelectSuspect = { viewModel.selectAccusationSuspect(it) },
                            onToggleEvidence = { viewModel.toggleAccusationEvidence(it) },
                            onSelectMethod = { viewModel.selectAccusationMethod(it) },
                            onSubmitAccusation = { viewModel.submitFinalAccusation() },
                            onGoToScene = { viewModel.navigateTo(GameScreen.CRIME_SCENE, recordInHistory = false) },
                            onBack = { viewModel.navigateTo(GameScreen.EVIDENCE_BOARD, recordInHistory = false) }
                        )

                        GameScreen.ENDING -> {
                            val ending = uiState.endingResult ?: caseData.evaluateEnding(
                                uiState.progress.accusedSuspect ?: Case01SilentRoom.TRUE_CULPRIT,
                                uiState.progress.accusedEvidenceIds,
                                uiState.progress.accusedMethodId ?: Case01SilentRoom.TRUE_METHOD_ID,
                                uiState.progress.discoveredConnections,
                                uiState.progress.recordedDecisions
                            )
                            EndingScreen(
                                ending = ending,
                                progress = uiState.progress,
                                strings = strings,
                                caseData = caseData,
                                onReplayCase = { viewModel.startNewInvestigation() },
                                onReturnToMenu = { viewModel.openMainMenu() }
                            )
                        }
                    }
                }
            }
        }
    }
}
