package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.LocalizedCaseData
import com.example.data.UiStrings
import com.example.model.AppLanguage
import com.example.model.GameSettings
import com.example.model.InvestigationProgress
import com.example.ui.components.AnimatedNoirBackdrop
import com.example.ui.components.ForensicBadge
import com.example.ui.components.NoirCard
import com.example.ui.components.NoirPrimaryButton
import com.example.ui.components.NoirSecondaryButton
import com.example.ui.theme.BrassGold
import com.example.ui.theme.CrimsonBright
import com.example.ui.theme.CrimsonMuted
import com.example.ui.theme.CrimsonSoft
import com.example.ui.theme.FogGray
import com.example.ui.theme.NoirBorder
import com.example.ui.theme.NoirCharcoal
import com.example.ui.theme.NoirSlate
import com.example.ui.theme.ParchmentWhite
import com.example.ui.theme.VerifiedTeal

@Composable
private fun SubScreenScaffold(
    title: String,
    badge: String,
    onBack: () -> Unit,
    content: @Composable () -> Unit
) {
    BackHandler { onBack() }
    Box(modifier = Modifier.fillMaxSize()) {
        AnimatedNoirBackdrop(crimsonPulseIntensity = 0.16f)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .widthIn(max = 720.dp)
                .align(Alignment.TopCenter)
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                IconButton(onClick = onBack, modifier = Modifier.testTag("subscreen_back")) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = ParchmentWhite)
                }
                Spacer(modifier = Modifier.width(6.dp))
                Column {
                    ForensicBadge(text = badge, color = BrassGold)
                    Text(
                        text = title,
                        style = MaterialTheme.typography.headlineMedium,
                        color = ParchmentWhite
                    )
                }
            }
            Spacer(modifier = Modifier.height(14.dp))
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                content()
                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}

@Composable
fun CaseFilesScreen(
    progress: InvestigationProgress,
    strings: UiStrings,
    caseData: LocalizedCaseData,
    onStartOrContinue: () -> Unit,
    onBack: () -> Unit
) {
    SubScreenScaffold(
        title = strings.caseFilesTitle,
        badge = strings.bureauDossier,
        onBack = onBack
    ) {
        NoirCard(borderColor = BrassGold.copy(alpha = 0.45f)) {
            Image(
                painter = painterResource(id = R.drawable.img_crime_scene),
                contentDescription = caseData.caseTitle,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp)
                    .clip(MaterialTheme.shapes.small)
            )
            Spacer(modifier = Modifier.height(14.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                ForensicBadge(text = caseData.caseCode, color = CrimsonBright)
                val statusLabel = when {
                    progress.achievedEndingId != null -> strings.statusConcluded
                    progress.hasActiveInvestigation -> strings.statusActive
                    else -> strings.statusUnopened
                }
                ForensicBadge(
                    text = statusLabel,
                    color = if (progress.achievedEndingId != null) VerifiedTeal else BrassGold
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = caseData.caseTitle,
                style = MaterialTheme.typography.headlineMedium,
                color = ParchmentWhite
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "${strings.victimPrefix}: ${caseData.victimDetails}",
                style = MaterialTheme.typography.bodyMedium,
                color = FogGray
            )
            Spacer(modifier = Modifier.height(12.dp))
            NoirPrimaryButton(
                text = if (progress.hasActiveInvestigation) strings.resumeCase else strings.openCase,
                onClick = onStartOrContinue,
                icon = Icons.Filled.PlayArrow,
                modifier = Modifier.fillMaxWidth(),
                testTag = "case_files_open_case"
            )
        }

        // Local Forensic Field Manual (local game data)
        NoirCard {
            Text(
                text = strings.forensicManualHeader,
                style = MaterialTheme.typography.labelLarge,
                color = BrassGold
            )
            Spacer(modifier = Modifier.height(10.dp))
            caseData.forensicManual.forEach { entry ->
                Surface(
                    shape = MaterialTheme.shapes.small,
                    color = NoirSlate,
                    border = BorderStroke(1.dp, NoirBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = entry.title,
                                style = MaterialTheme.typography.titleMedium,
                                color = ParchmentWhite,
                                modifier = Modifier.weight(1f)
                            )
                            ForensicBadge(text = entry.code, color = BrassGold)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = entry.summary,
                            style = MaterialTheme.typography.bodyMedium,
                            color = FogGray
                        )
                    }
                }
            }
        }

        NoirCard {
            Text(
                text = "${strings.unlockedEndingsHeader} (${progress.unlockedEndingsHistory.size}/4)",
                style = MaterialTheme.typography.labelLarge,
                color = BrassGold
            )
            Spacer(modifier = Modifier.height(10.dp))
            caseData.endingDescriptions.forEach { (id, desc) ->
                val unlocked = id in progress.unlockedEndingsHistory
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ForensicBadge(
                        text = if (unlocked) "✓" else "•••",
                        color = if (unlocked) VerifiedTeal else FogGray
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = if (unlocked) desc else strings.sealedEndingHint,
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (unlocked) ParchmentWhite else FogGray
                    )
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(
    settings: GameSettings,
    strings: UiStrings,
    onSelectLanguage: (AppLanguage) -> Unit,
    onToggleMute: () -> Unit,
    onToggleAmbientMusic: () -> Unit,
    onToggleHints: () -> Unit,
    onToggleFastText: () -> Unit,
    onResetSave: () -> Unit,
    onBack: () -> Unit
) {
    var confirmReset by remember { mutableStateOf(false) }

    SubScreenScaffold(
        title = strings.settingsTitle,
        badge = strings.systemPreferences,
        onBack = onBack
    ) {
        // Language selector card
        NoirCard(borderColor = BrassGold.copy(alpha = 0.45f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Language, contentDescription = null, tint = BrassGold)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = strings.languageTitle,
                    style = MaterialTheme.typography.titleMedium,
                    color = ParchmentWhite
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = strings.languageSubtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = FogGray
            )
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AppLanguage.entries.forEach { lang ->
                    val selected = lang == settings.language
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onSelectLanguage(lang) }
                            .testTag("settings_lang_${lang.code}"),
                        shape = MaterialTheme.shapes.small,
                        color = if (selected) CrimsonSoft else NoirSlate,
                        border = BorderStroke(1.dp, if (selected) CrimsonBright else NoirBorder)
                    ) {
                        Box(
                            modifier = Modifier.padding(vertical = 12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = lang.nativeLabel,
                                style = MaterialTheme.typography.titleMedium,
                                color = if (selected) ParchmentWhite else FogGray
                            )
                        }
                    }
                }
            }
        }

        SettingToggleRow(
            title = strings.muteTitle,
            subtitle = strings.muteSubtitle,
            checked = settings.isMuted,
            onCheckedChange = { onToggleMute() },
            testTag = "setting_mute_switch"
        )
        SettingToggleRow(
            title = strings.ambientMusicTitle,
            subtitle = strings.ambientMusicSubtitle,
            checked = settings.ambientMusicEnabled,
            onCheckedChange = { onToggleAmbientMusic() },
            testTag = "setting_ambient_switch"
        )
        SettingToggleRow(
            title = strings.hintsTitle,
            subtitle = strings.hintsSubtitle,
            checked = settings.hintsEnabled,
            onCheckedChange = { onToggleHints() },
            testTag = "setting_hints_switch"
        )
        SettingToggleRow(
            title = strings.instantTextTitle,
            subtitle = strings.instantTextSubtitle,
            checked = settings.fastTypewriter,
            onCheckedChange = { onToggleFastText() },
            testTag = "setting_fast_text_switch"
        )

        NoirCard(borderColor = CrimsonMuted.copy(alpha = 0.6f)) {
            Text(
                text = strings.resetSectionTitle,
                style = MaterialTheme.typography.labelLarge,
                color = CrimsonBright
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = strings.resetSectionBody,
                style = MaterialTheme.typography.bodyMedium,
                color = FogGray
            )
            Spacer(modifier = Modifier.height(12.dp))
            NoirSecondaryButton(
                text = strings.resetButton,
                onClick = { confirmReset = true },
                icon = Icons.Filled.DeleteForever,
                modifier = Modifier.fillMaxWidth(),
                testTag = "reset_save_button"
            )
        }
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            containerColor = NoirCharcoal,
            titleContentColor = ParchmentWhite,
            textContentColor = FogGray,
            title = { Text(strings.eraseDialogTitle) },
            text = { Text(strings.eraseDialogBody) },
            confirmButton = {
                TextButton(
                    onClick = {
                        confirmReset = false
                        onResetSave()
                    }
                ) {
                    Text(strings.eraseConfirm, color = CrimsonBright)
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmReset = false }) {
                    Text(strings.cancel, color = FogGray)
                }
            }
        )
    }
}

@Composable
private fun SettingToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: () -> Unit,
    testTag: String
) {
    NoirCard {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
                Text(text = title, style = MaterialTheme.typography.titleMedium, color = ParchmentWhite)
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = subtitle, style = MaterialTheme.typography.bodyMedium, color = FogGray)
            }
            Switch(
                checked = checked,
                onCheckedChange = { onCheckedChange() },
                modifier = Modifier.testTag(testTag),
                colors = SwitchDefaults.colors(
                    checkedThumbColor = ParchmentWhite,
                    checkedTrackColor = CrimsonMuted,
                    uncheckedThumbColor = FogGray,
                    uncheckedTrackColor = NoirSlate
                )
            )
        }
    }
}

@Composable
fun CreditsScreen(
    strings: UiStrings,
    caseData: LocalizedCaseData,
    onBack: () -> Unit
) {
    SubScreenScaffold(
        title = strings.creditsTitle,
        badge = strings.appTitle,
        onBack = onBack
    ) {
        NoirCard {
            Text(
                text = "${strings.appTitle}: ${caseData.caseTitle}",
                style = MaterialTheme.typography.titleLarge,
                color = BrassGold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = strings.creditsBody,
                style = MaterialTheme.typography.bodyMedium,
                color = ParchmentWhite
            )
            Spacer(modifier = Modifier.height(14.dp))
            Text(strings.creditsArchHeader, style = MaterialTheme.typography.labelLarge, color = BrassGold)
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = strings.creditsArchBody,
                style = MaterialTheme.typography.bodyMedium,
                color = FogGray
            )
        }
    }
}
