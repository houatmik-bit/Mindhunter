package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.data.LocalizedCaseData
import com.example.data.UiStrings
import com.example.model.InvestigationProgress
import com.example.model.SuspectId
import com.example.model.SuspectProfile
import com.example.ui.components.ForensicBadge
import com.example.ui.components.NoirCard
import com.example.ui.components.NoirPrimaryButton
import com.example.ui.theme.BrassGold
import com.example.ui.theme.CrimsonBright
import com.example.ui.theme.FogGray
import com.example.ui.theme.NoirBorder
import com.example.ui.theme.NoirSlate
import com.example.ui.theme.ParchmentWhite

@Composable
fun SuspectSelectionScreen(
    progress: InvestigationProgress,
    strings: UiStrings,
    caseData: LocalizedCaseData,
    onSelectSuspect: (SuspectId) -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        val isWide = maxWidth >= 680.dp

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = strings.suspectsHeader,
                        style = MaterialTheme.typography.labelLarge,
                        color = BrassGold
                    )
                    Text(
                        text = strings.suspectsSubtext,
                        style = MaterialTheme.typography.bodyMedium,
                        color = FogGray
                    )
                }
                ForensicBadge(
                    text = "${progress.detectedContradictions.size} ${strings.liesExposedLabel}",
                    color = CrimsonBright
                )
            }

            if (isWide) {
                caseData.suspects.chunked(2).forEach { pair ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        pair.forEach { suspect ->
                            SuspectDossierCard(
                                suspect = suspect,
                                strings = strings,
                                stress = progress.suspectStress[suspect.id] ?: suspect.baseStress,
                                onInterrogate = { onSelectSuspect(suspect.id) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            } else {
                caseData.suspects.forEach { suspect ->
                    SuspectDossierCard(
                        suspect = suspect,
                        strings = strings,
                        stress = progress.suspectStress[suspect.id] ?: suspect.baseStress,
                        onInterrogate = { onSelectSuspect(suspect.id) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}

@Composable
private fun SuspectDossierCard(
    suspect: SuspectProfile,
    strings: UiStrings,
    stress: Int,
    onInterrogate: () -> Unit,
    modifier: Modifier = Modifier
) {
    NoirCard(
        modifier = modifier,
        borderColor = if (stress >= 70) CrimsonBright.copy(alpha = 0.65f) else NoirBorder,
        onClick = onInterrogate
    ) {
        Row(verticalAlignment = Alignment.Top) {
            Surface(
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, BrassGold.copy(alpha = 0.45f)),
                modifier = Modifier.size(84.dp)
            ) {
                Image(
                    painter = painterResource(id = suspect.portraitRes),
                    contentDescription = suspect.fullName,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(RoundedCornerShape(8.dp))
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = suspect.fullName,
                    style = MaterialTheme.typography.headlineMedium,
                    color = ParchmentWhite
                )
                Text(
                    text = "${suspect.role} · ${suspect.age}",
                    style = MaterialTheme.typography.labelMedium,
                    color = BrassGold
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = suspect.personality,
                    style = MaterialTheme.typography.bodyMedium,
                    color = FogGray
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = strings.backstoryLabel,
            style = MaterialTheme.typography.labelSmall,
            color = BrassGold
        )
        Text(
            text = suspect.backstory,
            style = MaterialTheme.typography.bodyMedium,
            color = ParchmentWhite
        )

        Spacer(modifier = Modifier.height(10.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "${strings.stressIndexLabel}: $stress%",
                style = MaterialTheme.typography.labelSmall,
                color = if (stress >= 65) CrimsonBright else FogGray
            )
            Text(
                text = if (stress >= 65) strings.statusRattled else strings.statusGuarded,
                style = MaterialTheme.typography.labelSmall,
                color = if (stress >= 65) CrimsonBright else BrassGold
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { (stress / 100f).coerceIn(0f, 1f) },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp)),
            color = if (stress >= 65) CrimsonBright else BrassGold,
            trackColor = NoirSlate
        )

        Spacer(modifier = Modifier.height(12.dp))
        NoirPrimaryButton(
            text = "${strings.interrogateAction}: ${suspect.fullName.substringBefore(" ")}",
            onClick = onInterrogate,
            icon = Icons.Filled.RecordVoiceOver,
            modifier = Modifier.fillMaxWidth(),
            testTag = "interrogate_${suspect.id.name.lowercase()}"
        )
    }
}
