package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.data.LocalizedCaseData
import com.example.data.UiStrings
import com.example.model.InvestigationProgress
import com.example.model.SuspectId
import com.example.ui.components.ForensicBadge
import com.example.ui.components.NoirCard
import com.example.ui.components.NoirPrimaryButton
import com.example.ui.theme.BrassGold
import com.example.ui.theme.CrimsonBright
import com.example.ui.theme.CrimsonSoft
import com.example.ui.theme.FogGray
import com.example.ui.theme.NoirBorder
import com.example.ui.theme.NoirCharcoal
import com.example.ui.theme.NoirSlate
import com.example.ui.theme.ParchmentWhite

@Composable
fun AccusationScreen(
    progress: InvestigationProgress,
    strings: UiStrings,
    caseData: LocalizedCaseData,
    selectedSuspect: SuspectId?,
    selectedEvidenceIds: List<String>,
    selectedMethodId: String,
    onSelectSuspect: (SuspectId) -> Unit,
    onToggleEvidence: (String) -> Unit,
    onSelectMethod: (String) -> Unit,
    onSubmitAccusation: () -> Unit,
    onGoToScene: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    val collectedClues = caseData.clues.filter { it.id in progress.collectedClues }
    val canSubmit = selectedSuspect != null && selectedEvidenceIds.size >= 2

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        val isWide = maxWidth >= 680.dp

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            NoirCard(borderColor = CrimsonBright.copy(alpha = 0.5f)) {
                ForensicBadge(text = strings.accusationBadge, color = CrimsonBright)
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = strings.accusationTitle,
                    style = MaterialTheme.typography.headlineMedium,
                    color = ParchmentWhite
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = strings.accusationSubtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = FogGray
                )
            }

            if (collectedClues.size < 2) {
                NoirCard {
                    Text(
                        text = "${strings.insufficientEvidenceTitle} (${collectedClues.size}/2)",
                        style = MaterialTheme.typography.titleMedium,
                        color = BrassGold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = strings.insufficientEvidenceBody,
                        style = MaterialTheme.typography.bodyMedium,
                        color = FogGray
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    NoirPrimaryButton(
                        text = strings.returnToCrimeScene,
                        onClick = onGoToScene,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                return@BoxWithConstraints
            }

            Text(
                text = strings.step1Suspect,
                style = MaterialTheme.typography.labelLarge,
                color = BrassGold
            )

            val rows = if (isWide) caseData.suspects.chunked(2) else caseData.suspects.chunked(1)
            rows.forEach { rowSuspects ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    rowSuspects.forEach { suspect ->
                        val isChosen = suspect.id == selectedSuspect
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clickable { onSelectSuspect(suspect.id) }
                                .testTag("accuse_suspect_${suspect.id.name.lowercase()}"),
                            shape = MaterialTheme.shapes.small,
                            color = if (isChosen) CrimsonSoft else NoirCharcoal,
                            border = BorderStroke(
                                width = if (isChosen) 1.5.dp else 1.dp,
                                color = if (isChosen) CrimsonBright else NoirBorder
                            )
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Image(
                                    painter = painterResource(id = suspect.portraitRes),
                                    contentDescription = suspect.fullName,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(48.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = suspect.fullName,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = ParchmentWhite
                                    )
                                    Text(
                                        text = suspect.role,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (isChosen) CrimsonBright else FogGray
                                    )
                                }
                                if (isChosen) {
                                    Icon(
                                        imageVector = Icons.Filled.CheckCircle,
                                        contentDescription = null,
                                        tint = CrimsonBright
                                    )
                                }
                            }
                        }
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = strings.step2Evidence,
                    style = MaterialTheme.typography.labelLarge,
                    color = BrassGold
                )
                ForensicBadge(
                    text = "${selectedEvidenceIds.size}/3 ${strings.attachedBadge}",
                    color = if (selectedEvidenceIds.size >= 2) BrassGold else FogGray
                )
            }

            collectedClues.forEach { clue ->
                val isSelected = clue.id in selectedEvidenceIds
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onToggleEvidence(clue.id) }
                        .testTag("accuse_clue_${clue.id}"),
                    shape = MaterialTheme.shapes.small,
                    color = if (isSelected) NoirSlate else NoirCharcoal,
                    border = BorderStroke(
                        width = if (isSelected) 1.5.dp else 1.dp,
                        color = if (isSelected) BrassGold else NoirBorder
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = clue.title,
                                style = MaterialTheme.typography.titleMedium,
                                color = ParchmentWhite
                            )
                            Text(
                                text = clue.summary,
                                style = MaterialTheme.typography.bodyMedium,
                                color = FogGray
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        if (isSelected) {
                            Icon(
                                imageVector = Icons.Filled.CheckCircle,
                                contentDescription = null,
                                tint = BrassGold
                            )
                        }
                    }
                }
            }

            Text(
                text = strings.step3Method,
                style = MaterialTheme.typography.labelLarge,
                color = BrassGold
            )

            caseData.methodTheories.forEach { method ->
                val isChosen = method.id == selectedMethodId
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectMethod(method.id) }
                        .testTag("accuse_method_${method.id}"),
                    shape = MaterialTheme.shapes.small,
                    color = if (isChosen) NoirSlate else NoirCharcoal,
                    border = BorderStroke(
                        width = if (isChosen) 1.5.dp else 1.dp,
                        color = if (isChosen) CrimsonBright else NoirBorder
                    )
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = method.title,
                            style = MaterialTheme.typography.titleMedium,
                            color = if (isChosen) CrimsonBright else ParchmentWhite
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = method.description,
                            style = MaterialTheme.typography.bodyMedium,
                            color = FogGray
                        )
                    }
                }
            }

            NoirPrimaryButton(
                text = if (canSubmit) strings.submitWarrant else strings.selectMinimumPrompt,
                onClick = onSubmitAccusation,
                enabled = canSubmit,
                icon = Icons.Filled.Gavel,
                modifier = Modifier.fillMaxWidth(),
                testTag = "submit_accusation_button"
            )

            Spacer(modifier = Modifier.height(14.dp))
        }
    }
}
