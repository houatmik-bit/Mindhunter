package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val NoirBlack = Color(0xFF09090C)
val NoirCharcoal = Color(0xFF131318)
val NoirSlate = Color(0xFF1D1D25)
val NoirElevated = Color(0xFF252530)
val NoirBorder = Color(0xFF31313F)

val CrimsonMuted = Color(0xFF9B2628)
val CrimsonBright = Color(0xFFD14547)
val CrimsonSoft = Color(0xFF3A1517)

val BrassGold = Color(0xFFC8A05E)
val BrassSoft = Color(0xFF2E261A)

val ParchmentWhite = Color(0xFFEDE9E2)
val FogGray = Color(0xFF9D9BA6)
val DimGray = Color(0xFF6B6973)

val VerifiedTeal = Color(0xFF4C9A7F)
val VerifiedTealSoft = Color(0xFF172B24)
