package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.LocalizedCaseData
import com.example.data.UiStrings
import com.example.ui.components.AnimatedNoirBackdrop
import com.example.ui.components.ForensicBadge
import com.example.ui.components.NoirCard
import com.example.ui.components.NoirPrimaryButton
import com.example.ui.components.NoirSecondaryButton
import com.example.ui.theme.BrassGold
import com.example.ui.theme.CrimsonBright
import com.example.ui.theme.NoirBlack
import com.example.ui.theme.ParchmentWhite

@Composable
fun CaseIntroScreen(
    strings: UiStrings,
    caseData: LocalizedCaseData,
    onEnterCrimeScene: () -> Unit,
    onBackToMenu: () -> Unit
) {
    BackHandler { onBackToMenu() }

    Box(modifier = Modifier.fillMaxSize()) {
        AnimatedNoirBackdrop(crimsonPulseIntensity = 0.2f)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .widthIn(max = 760.dp)
                .align(Alignment.TopCenter)
                .padding(horizontal = 20.dp, vertical = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                ForensicBadge(text = caseData.caseCode, color = CrimsonBright)
                ForensicBadge(text = caseData.manorLocationBadge, color = BrassGold)
            }

            Text(
                text = caseData.caseTitle,
                style = MaterialTheme.typography.displayMedium,
                color = ParchmentWhite
            )

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(210.dp)
                    .clip(MaterialTheme.shapes.medium)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_crime_scene),
                    contentDescription = caseData.caseTitle,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(Color.Transparent, NoirBlack.copy(alpha = 0.85f))
                            )
                        )
                )
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(14.dp)
                ) {
                    Text(
                        text = "${strings.victimPrefix}: ${caseData.victimName}",
                        style = MaterialTheme.typography.labelLarge,
                        color = BrassGold
                    )
                    Text(
                        text = caseData.victimDetails,
                        style = MaterialTheme.typography.bodyMedium,
                        color = ParchmentWhite
                    )
                }
            }

            NoirCard {
                Text(
                    text = strings.introBriefingLabel,
                    style = MaterialTheme.typography.labelLarge,
                    color = BrassGold
                )
                Spacer(modifier = Modifier.height(10.dp))
                caseData.briefingParagraphs.forEach { para ->
                    Text(
                        text = para,
                        style = MaterialTheme.typography.bodyLarge,
                        color = ParchmentWhite,
                        modifier = Modifier.padding(bottom = 10.dp)
                    )
                }
            }

            NoirPrimaryButton(
                text = strings.introEnterScene,
                onClick = onEnterCrimeScene,
                icon = Icons.Filled.Search,
                modifier = Modifier.fillMaxWidth(),
                testTag = "enter_crime_scene_button"
            )

            NoirSecondaryButton(
                text = strings.introBackMenu,
                onClick = onBackToMenu,
                modifier = Modifier.fillMaxWidth(),
                testTag = "intro_back_menu_button"
            )

            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}
