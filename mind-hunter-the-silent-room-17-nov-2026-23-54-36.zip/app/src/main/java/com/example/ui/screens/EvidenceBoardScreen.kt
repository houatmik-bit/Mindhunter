package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.LocalizedCaseData
import com.example.data.UiStrings
import com.example.model.Clue
import com.example.model.ClueConnection
import com.example.model.InvestigationProgress
import com.example.ui.components.ForensicBadge
import com.example.ui.components.NoirCard
import com.example.ui.components.NoirPrimaryButton
import com.example.ui.theme.BrassGold
import com.example.ui.theme.CrimsonBright
import com.example.ui.theme.CrimsonSoft
import com.example.ui.theme.FogGray
import com.example.ui.theme.NoirBlack
import com.example.ui.theme.NoirBorder
import com.example.ui.theme.NoirCharcoal
import com.example.ui.theme.NoirSlate
import com.example.ui.theme.ParchmentWhite
import com.example.ui.theme.VerifiedTeal
import com.example.ui.theme.VerifiedTealSoft
import com.example.viewmodel.BoardFeedback

@Composable
fun EvidenceBoardScreen(
    progress: InvestigationProgress,
    strings: UiStrings,
    caseData: LocalizedCaseData,
    selectedClueId: String?,
    boardFeedback: BoardFeedback?,
    onClueTapped: (String) -> Unit,
    onGoToScene: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    val collectedClues = caseData.clues.filter { it.id in progress.collectedClues }
    val discoveredConnections = caseData.clueConnections.filter { it.id in progress.discoveredConnections }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        val isWide = maxWidth >= 680.dp

        if (collectedClues.isEmpty()) {
            NoirCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.Center)
            ) {
                Icon(
                    imageVector = Icons.Filled.Search,
                    contentDescription = null,
                    tint = BrassGold,
                    modifier = Modifier.size(36.dp)
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = strings.boardEmptyTitle,
                    style = MaterialTheme.typography.headlineMedium,
                    color = ParchmentWhite
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = strings.boardEmptyBody,
                    style = MaterialTheme.typography.bodyMedium,
                    color = FogGray
                )
                Spacer(modifier = Modifier.height(14.dp))
                NoirPrimaryButton(
                    text = strings.investigateCrimeScene,
                    onClick = onGoToScene,
                    icon = Icons.Filled.Search,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            return@BoxWithConstraints
        }

        if (isWide) {
            Row(
                modifier = Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .weight(1.1f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    BoardCluesSection(
                        collectedClues = collectedClues,
                        strings = strings,
                        selectedClueId = selectedClueId,
                        boardFeedback = boardFeedback,
                        onClueTapped = onClueTapped
                    )
                }
                Column(
                    modifier = Modifier
                        .weight(0.9f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    DeductionThreadGraph(
                        collectedClues = collectedClues,
                        caseData = caseData,
                        strings = strings,
                        discoveredConnectionIds = progress.discoveredConnections
                    )
                    VerifiedDeductionsList(
                        discoveredConnections = discoveredConnections,
                        strings = strings
                    )
                }
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                DeductionThreadGraph(
                    collectedClues = collectedClues,
                    caseData = caseData,
                    strings = strings,
                    discoveredConnectionIds = progress.discoveredConnections
                )
                BoardCluesSection(
                    collectedClues = collectedClues,
                    strings = strings,
                    selectedClueId = selectedClueId,
                    boardFeedback = boardFeedback,
                    onClueTapped = onClueTapped
                )
                VerifiedDeductionsList(
                    discoveredConnections = discoveredConnections,
                    strings = strings
                )
                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }
}

@Composable
private fun BoardCluesSection(
    collectedClues: List<Clue>,
    strings: UiStrings,
    selectedClueId: String?,
    boardFeedback: BoardFeedback?,
    onClueTapped: (String) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "${strings.collectedCluesHeader} (${collectedClues.size}/8)",
            style = MaterialTheme.typography.labelLarge,
            color = BrassGold
        )
        Text(
            text = if (selectedClueId == null) strings.tapTwoToLink else strings.selectSecondClue,
            style = MaterialTheme.typography.labelSmall,
            color = if (selectedClueId != null) CrimsonBright else FogGray
        )
    }

    AnimatedVisibility(visible = boardFeedback != null) {
        boardFeedback?.let { fb ->
            Surface(
                shape = MaterialTheme.shapes.small,
                color = if (fb.isMatch) VerifiedTealSoft else CrimsonSoft,
                border = BorderStroke(1.dp, if (fb.isMatch) VerifiedTeal else CrimsonBright),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = fb.title,
                        style = MaterialTheme.typography.labelLarge,
                        color = if (fb.isMatch) VerifiedTeal else CrimsonBright
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = fb.message,
                        style = MaterialTheme.typography.bodyMedium,
                        color = ParchmentWhite
                    )
                }
            }
        }
    }

    collectedClues.forEach { clue ->
        val isSelected = clue.id == selectedClueId
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onClueTapped(clue.id) }
                .testTag("board_clue_${clue.id}"),
            shape = MaterialTheme.shapes.small,
            color = if (isSelected) CrimsonSoft.copy(alpha = 0.7f) else NoirCharcoal,
            border = BorderStroke(
                width = if (isSelected) 1.5.dp else 1.dp,
                color = if (isSelected) CrimsonBright else NoirBorder
            )
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = clue.title,
                        style = MaterialTheme.typography.titleMedium,
                        color = ParchmentWhite,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    ForensicBadge(
                        text = if (isSelected) strings.selectedBadge else clue.category.label,
                        color = if (isSelected) CrimsonBright else BrassGold
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = clue.summary,
                    style = MaterialTheme.typography.bodyMedium,
                    color = FogGray
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = clue.timestampHint,
                    style = MaterialTheme.typography.labelSmall,
                    color = BrassGold
                )
            }
        }
    }
}

@Composable
private fun DeductionThreadGraph(
    collectedClues: List<Clue>,
    caseData: LocalizedCaseData,
    strings: UiStrings,
    discoveredConnectionIds: Set<String>
) {
    NoirCard(borderColor = BrassGold.copy(alpha = 0.4f)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Hub, contentDescription = null, tint = CrimsonBright, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = strings.redThreadMap,
                    style = MaterialTheme.typography.labelLarge,
                    color = BrassGold
                )
            }
            ForensicBadge(
                text = "${discoveredConnectionIds.size}/5 ${strings.linksLabel}",
                color = VerifiedTeal
            )
        }
        Spacer(modifier = Modifier.height(10.dp))

        val slotPositions = mapOf(
            "clue_toxic_espresso" to Offset(0.18f, 0.25f),
            "clue_lab_requisition" to Offset(0.52f, 0.22f),
            "clue_door_threshold" to Offset(0.84f, 0.30f),
            "clue_security_log" to Offset(0.75f, 0.72f),
            "clue_cufflink" to Offset(0.16f, 0.74f),
            "clue_audit_ledger" to Offset(0.38f, 0.80f),
            "clue_guard_flask" to Offset(0.56f, 0.68f),
            "clue_shredded_note" to Offset(0.35f, 0.48f)
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp)
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                drawRect(color = NoirBlack.copy(alpha = 0.75f))

                caseData.clueConnections.filter { it.id in discoveredConnectionIds }.forEach { conn ->
                    val p1 = slotPositions[conn.clueAId]
                    val p2 = slotPositions[conn.clueBId]
                    if (p1 != null && p2 != null) {
                        drawLine(
                            color = CrimsonBright,
                            start = Offset(p1.x * size.width, p1.y * size.height),
                            end = Offset(p2.x * size.width, p2.y * size.height),
                            strokeWidth = 3.5f,
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 8f), 0f)
                        )
                    }
                }

                collectedClues.forEach { clue ->
                    val pos = slotPositions[clue.id] ?: Offset(0.5f, 0.5f)
                    val center = Offset(pos.x * size.width, pos.y * size.height)
                    val isLinked = caseData.clueConnections.any {
                        it.id in discoveredConnectionIds && (it.clueAId == clue.id || it.clueBId == clue.id)
                    }
                    drawCircle(
                        color = if (isLinked) CrimsonBright else BrassGold,
                        radius = 11f,
                        center = center
                    )
                    drawCircle(
                        color = NoirBlack,
                        radius = 5f,
                        center = center
                    )
                }
            }
        }
    }
}

@Composable
private fun VerifiedDeductionsList(
    discoveredConnections: List<ClueConnection>,
    strings: UiStrings
) {
    Text(
        text = "${strings.verifiedDeductionsHeader} (${discoveredConnections.size}/5)",
        style = MaterialTheme.typography.labelLarge,
        color = VerifiedTeal
    )
    if (discoveredConnections.isEmpty()) {
        NoirCard {
            Text(
                text = strings.noDeductionsYet,
                style = MaterialTheme.typography.bodyMedium,
                color = FogGray
            )
        }
    } else {
        discoveredConnections.forEach { conn ->
            Surface(
                shape = MaterialTheme.shapes.small,
                color = NoirSlate,
                border = BorderStroke(1.dp, VerifiedTeal.copy(alpha = 0.6f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.Link,
                            contentDescription = null,
                            tint = VerifiedTeal,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = conn.title,
                            style = MaterialTheme.typography.titleMedium,
                            color = ParchmentWhite
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = conn.deductionSummary,
                        style = MaterialTheme.typography.bodyMedium,
                        color = FogGray
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "${strings.leadPrefix}: ${conn.unlocksHint}",
                        style = MaterialTheme.typography.labelSmall,
                        color = BrassGold
                    )
                }
            }
        }
    }
}
