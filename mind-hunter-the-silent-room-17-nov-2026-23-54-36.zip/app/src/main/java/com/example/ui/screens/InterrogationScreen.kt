package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.example.data.Case01SilentRoom
import com.example.data.InterrogationEngine
import com.example.data.LocalizedCaseData
import com.example.data.UiStrings
import com.example.model.DialogueNode
import com.example.model.DialogueOption
import com.example.model.EvidenceItem
import com.example.model.GameSettings
import com.example.model.InterrogationFeedback
import com.example.model.InvestigationProgress
import com.example.model.SuspectComposure
import com.example.model.SuspectProfile
import com.example.ui.components.ForensicBadge
import com.example.ui.components.NoirCard
import com.example.ui.components.NoirPrimaryButton
import com.example.ui.components.NoirSecondaryButton
import com.example.ui.components.TypewriterText
import com.example.ui.theme.BrassGold
import com.example.ui.theme.CrimsonBright
import com.example.ui.theme.CrimsonSoft
import com.example.ui.theme.FogGray
import com.example.ui.theme.NoirBlack
import com.example.ui.theme.NoirBorder
import com.example.ui.theme.NoirCharcoal
import com.example.ui.theme.NoirSlate
import com.example.ui.theme.ParchmentWhite
import com.example.ui.theme.VerifiedTeal
import com.example.ui.theme.VerifiedTealSoft

@Composable
fun InterrogationScreen(
    progress: InvestigationProgress,
    collectedEvidence: List<EvidenceItem>,
    settings: GameSettings,
    strings: UiStrings,
    caseData: LocalizedCaseData,
    latestContradiction: String?,
    interrogationFeedback: InterrogationFeedback?,
    onSelectOption: (String) -> Unit,
    onPresentEvidence: (String) -> Unit,
    onPressStatement: () -> Unit,
    onOpenEvidenceBoard: () -> Unit,
    onBackToSuspects: () -> Unit
) {
    BackHandler { onBackToSuspects() }

    var showEvidenceTray by remember { mutableStateOf(false) }

    val suspectId = progress.selectedSuspect
    val suspect = caseData.suspects.first { it.id == suspectId }
    val nodeId = progress.currentDialogueBySuspect[suspectId]
        ?: Case01SilentRoom.getInitialNodeId(suspectId)
    val node = caseData.dialogueNodes[nodeId]
        ?: caseData.dialogueNodes[Case01SilentRoom.getInitialNodeId(suspectId)]!!
    val stress = progress.suspectStress[suspectId] ?: suspect.baseStress

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        val isWide = maxWidth >= 680.dp

        if (isWide) {
            Row(
                modifier = Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .weight(0.88f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    PsychologicalProfileCard(
                        suspect = suspect,
                        stress = stress,
                        node = node,
                        strings = strings,
                        hintsEnabled = settings.hintsEnabled,
                        contradictionsCount = progress.detectedContradictions.size
                    )
                    NoirSecondaryButton(
                        text = strings.openEvidenceBoard,
                        onClick = onOpenEvidenceBoard,
                        icon = Icons.Filled.Dashboard,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                Column(
                    modifier = Modifier
                        .weight(1.12f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    DialoguePanel(
                        node = node,
                        progress = progress,
                        settings = settings,
                        strings = strings,
                        collectedCount = collectedEvidence.size,
                        latestContradiction = latestContradiction,
                        interrogationFeedback = interrogationFeedback,
                        onSelectOption = onSelectOption,
                        onOpenEvidenceTray = { showEvidenceTray = true },
                        onPressStatement = onPressStatement,
                        onBackToSuspects = onBackToSuspects
                    )
                }
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                PsychologicalProfileCard(
                    suspect = suspect,
                    stress = stress,
                    node = node,
                    strings = strings,
                    hintsEnabled = settings.hintsEnabled,
                    contradictionsCount = progress.detectedContradictions.size
                )
                DialoguePanel(
                    node = node,
                    progress = progress,
                    settings = settings,
                    strings = strings,
                    collectedCount = collectedEvidence.size,
                    latestContradiction = latestContradiction,
                    interrogationFeedback = interrogationFeedback,
                    onSelectOption = onSelectOption,
                    onOpenEvidenceTray = { showEvidenceTray = true },
                    onPressStatement = onPressStatement,
                    onBackToSuspects = onBackToSuspects
                )
                NoirSecondaryButton(
                    text = strings.crossRefBoard,
                    onClick = onOpenEvidenceBoard,
                    icon = Icons.Filled.Dashboard,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }

    if (showEvidenceTray) {
        AlertDialog(
            onDismissRequest = { showEvidenceTray = false },
            containerColor = NoirCharcoal,
            titleContentColor = ParchmentWhite,
            title = {
                Text(
                    text = strings.evidenceTrayTitle,
                    style = MaterialTheme.typography.labelLarge,
                    color = BrassGold
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 360.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (collectedEvidence.isEmpty()) {
                        Text(
                            text = strings.evidenceTrayEmpty,
                            style = MaterialTheme.typography.bodyMedium,
                            color = FogGray
                        )
                    } else {
                        collectedEvidence.forEach { item ->
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        showEvidenceTray = false
                                        onPresentEvidence(item.id)
                                    }
                                    .testTag("present_evidence_${item.id}"),
                                shape = MaterialTheme.shapes.small,
                                color = NoirSlate,
                                border = BorderStroke(1.dp, BrassGold.copy(alpha = 0.45f))
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = item.title,
                                            style = MaterialTheme.typography.titleMedium,
                                            color = ParchmentWhite,
                                            modifier = Modifier.weight(1f)
                                        )
                                        if (item.isExamined) {
                                            ForensicBadge(text = strings.examinedTag, color = VerifiedTeal)
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = item.summary,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = FogGray
                                    )
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showEvidenceTray = false }) {
                    Text(strings.closeLabel, color = BrassGold)
                }
            }
        )
    }
}

@Composable
private fun PsychologicalProfileCard(
    suspect: SuspectProfile,
    stress: Int,
    node: DialogueNode,
    strings: UiStrings,
    hintsEnabled: Boolean,
    contradictionsCount: Int
) {
    val composure = InterrogationEngine.evaluateComposure(stress)
    val composureLabel = when (composure) {
        SuspectComposure.CALM -> strings.composureCalm
        SuspectComposure.DEFENSIVE -> strings.composureDefensive
        SuspectComposure.RATTLED -> strings.composureRattled
        SuspectComposure.CORNERED -> strings.composureCornered
        SuspectComposure.BROKEN -> strings.composureBroken
    }
    val composureColor = when (composure) {
        SuspectComposure.CALM -> VerifiedTeal
        SuspectComposure.DEFENSIVE -> BrassGold
        SuspectComposure.RATTLED,
        SuspectComposure.CORNERED,
        SuspectComposure.BROKEN -> CrimsonBright
    }

    NoirCard(borderColor = if (stress >= 70) CrimsonBright.copy(alpha = 0.7f) else NoirBorder) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.5.dp, if (stress >= 70) CrimsonBright else BrassGold.copy(alpha = 0.6f)),
                modifier = Modifier.size(78.dp)
            ) {
                Image(
                    painter = painterResource(id = suspect.portraitRes),
                    contentDescription = suspect.fullName,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(RoundedCornerShape(10.dp))
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = suspect.fullName,
                    style = MaterialTheme.typography.headlineMedium,
                    color = ParchmentWhite
                )
                Text(
                    text = suspect.role,
                    style = MaterialTheme.typography.labelMedium,
                    color = BrassGold
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ForensicBadge(
                        text = "$composureLabel · $stress%",
                        color = composureColor
                    )
                    ForensicBadge(
                        text = "$contradictionsCount ${strings.liesExposedLabel}",
                        color = CrimsonBright
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))
        LinearProgressIndicator(
            progress = { (stress / 100f).coerceIn(0f, 1f) },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp)),
            color = composureColor,
            trackColor = NoirSlate
        )

        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = strings.microExpressionLabel,
            style = MaterialTheme.typography.labelSmall,
            color = BrassGold
        )
        Text(
            text = node.reactionTell,
            style = MaterialTheme.typography.bodyMedium,
            color = ParchmentWhite
        )

        if (hintsEnabled && node.psychologicalHint != null) {
            Spacer(modifier = Modifier.height(10.dp))
            Surface(
                shape = MaterialTheme.shapes.small,
                color = NoirSlate,
                border = BorderStroke(1.dp, VerifiedTeal.copy(alpha = 0.45f))
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Icon(
                        imageVector = Icons.Filled.Psychology,
                        contentDescription = strings.profilerInsightLabel,
                        tint = VerifiedTeal,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = strings.profilerInsightLabel,
                            style = MaterialTheme.typography.labelSmall,
                            color = VerifiedTeal
                        )
                        Text(
                            text = node.psychologicalHint,
                            style = MaterialTheme.typography.bodyMedium,
                            color = FogGray
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DialoguePanel(
    node: DialogueNode,
    progress: InvestigationProgress,
    settings: GameSettings,
    strings: UiStrings,
    collectedCount: Int,
    latestContradiction: String?,
    interrogationFeedback: InterrogationFeedback?,
    onSelectOption: (String) -> Unit,
    onOpenEvidenceTray: () -> Unit,
    onPressStatement: () -> Unit,
    onBackToSuspects: () -> Unit
) {
    AnimatedVisibility(visible = interrogationFeedback != null) {
        interrogationFeedback?.let { fb ->
            Surface(
                shape = MaterialTheme.shapes.small,
                color = if (fb.isContradiction) CrimsonSoft else VerifiedTealSoft,
                border = BorderStroke(1.dp, if (fb.isContradiction) CrimsonBright else BrassGold),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = if (fb.presentedEvidenceTitle != null) {
                            "${fb.title} · ${fb.presentedEvidenceTitle}"
                        } else {
                            fb.title
                        },
                        style = MaterialTheme.typography.labelLarge,
                        color = if (fb.isContradiction) CrimsonBright else BrassGold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = fb.message,
                        style = MaterialTheme.typography.bodyMedium,
                        color = ParchmentWhite
                    )
                }
            }
        }
    }

    AnimatedVisibility(visible = latestContradiction != null || node.contradictionFound != null) {
        val text = latestContradiction ?: node.contradictionFound.orEmpty()
        Surface(
            shape = MaterialTheme.shapes.small,
            color = CrimsonSoft,
            border = BorderStroke(1.dp, CrimsonBright),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Filled.Warning,
                    contentDescription = strings.contradictionDetected,
                    tint = CrimsonBright,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = strings.contradictionDetected,
                        style = MaterialTheme.typography.labelLarge,
                        color = CrimsonBright
                    )
                    Text(
                        text = text,
                        style = MaterialTheme.typography.bodyMedium,
                        color = ParchmentWhite
                    )
                }
            }
        }
    }

    NoirCard(borderColor = BrassGold.copy(alpha = 0.45f)) {
        Text(
            text = node.speakerName.uppercase(),
            style = MaterialTheme.typography.labelLarge,
            color = BrassGold
        )
        Spacer(modifier = Modifier.height(8.dp))
        TypewriterText(
            fullText = "« ${node.text} »",
            fastMode = settings.fastTypewriter,
            style = MaterialTheme.typography.bodyLarge,
            color = ParchmentWhite
        )
    }

    // Tactical Actions: Press Statement & Present Evidence
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        NoirSecondaryButton(
            text = strings.pressStatementAction,
            onClick = onPressStatement,
            icon = Icons.Filled.Gavel,
            modifier = Modifier.weight(1f),
            testTag = "press_statement_button"
        )
        NoirPrimaryButton(
            text = "${strings.presentEvidenceAction} ($collectedCount)",
            onClick = onOpenEvidenceTray,
            icon = Icons.Filled.Badge,
            modifier = Modifier.weight(1f),
            testTag = "present_evidence_button"
        )
    }

    Text(
        text = strings.interrogationResponses,
        style = MaterialTheme.typography.labelLarge,
        color = BrassGold
    )

    node.options.forEach { option ->
        val hasClue = option.requiredClueId == null || option.requiredClueId in progress.collectedClues
        val hasConn = option.requiredConnectionId == null || option.requiredConnectionId in progress.discoveredConnections
        val unlocked = hasClue && hasConn
        val isSpecial = option.requiredClueId != null || option.requiredConnectionId != null

        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .then(
                    if (unlocked) Modifier.clickable { onSelectOption(option.id) }
                    else Modifier
                )
                .testTag("dialogue_option_${option.id}"),
            shape = MaterialTheme.shapes.small,
            color = when {
                !unlocked -> NoirBlack.copy(alpha = 0.55f)
                isSpecial -> CrimsonSoft.copy(alpha = 0.65f)
                else -> NoirCharcoal
            },
            border = BorderStroke(
                width = 1.dp,
                color = when {
                    !unlocked -> NoirBorder.copy(alpha = 0.4f)
                    isSpecial -> CrimsonBright.copy(alpha = 0.75f)
                    option.isPsychologicalPressure -> BrassGold.copy(alpha = 0.6f)
                    else -> NoirBorder
                }
            )
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (!unlocked) {
                    Icon(
                        imageVector = Icons.Filled.Lock,
                        contentDescription = null,
                        tint = FogGray,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (unlocked) option.prompt else buildLockedLabel(option, strings),
                        style = MaterialTheme.typography.bodyMedium,
                        color = if (unlocked) ParchmentWhite else FogGray
                    )
                }
            }
        }
    }

    NoirSecondaryButton(
        text = strings.switchSuspect,
        onClick = onBackToSuspects,
        modifier = Modifier.fillMaxWidth()
    )
}

private fun buildLockedLabel(option: DialogueOption, strings: UiStrings): String {
    return when {
        option.requiredConnectionId != null -> strings.lockedConfrontation
        option.requiredClueId != null -> strings.lockedEvidencePrompt
        else -> option.prompt
    }
}
