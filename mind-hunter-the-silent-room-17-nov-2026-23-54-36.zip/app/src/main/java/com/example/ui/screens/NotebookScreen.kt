package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.LocalizedCaseData
import com.example.data.UiStrings
import com.example.model.DetectiveNote
import com.example.model.EvidenceItem
import com.example.model.InvestigationProgress
import com.example.model.NoteCategory
import com.example.model.SuspectId
import com.example.ui.components.ForensicBadge
import com.example.ui.components.NoirCard
import com.example.ui.components.NoirPrimaryButton
import com.example.ui.components.NoirSecondaryButton
import com.example.ui.theme.BrassGold
import com.example.ui.theme.CrimsonBright
import com.example.ui.theme.CrimsonSoft
import com.example.ui.theme.FogGray
import com.example.ui.theme.NoirBlack
import com.example.ui.theme.NoirBorder
import com.example.ui.theme.NoirCharcoal
import com.example.ui.theme.NoirSlate
import com.example.ui.theme.ParchmentWhite
import com.example.ui.theme.VerifiedTeal
import com.example.ui.theme.VerifiedTealSoft
import java.text.DateFormat
import java.util.Date

private enum class NotebookFilter {
    ALL,
    PINNED,
    SUSPECT,
    CLUE,
    THEORY
}

@Composable
fun NotebookScreen(
    progress: InvestigationProgress,
    collectedEvidence: List<EvidenceItem>,
    strings: UiStrings,
    caseData: LocalizedCaseData,
    onSaveNote: (
        noteId: String?,
        title: String,
        body: String,
        category: NoteCategory,
        linkedSuspectId: SuspectId?,
        linkedClueId: String?
    ) -> Unit,
    onTogglePin: (String) -> Unit,
    onDeleteNote: (String) -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    var editingNoteId by remember { mutableStateOf<String?>(null) }
    var draftTitle by remember { mutableStateOf("") }
    var draftBody by remember { mutableStateOf("") }
    var draftCategory by remember { mutableStateOf(NoteCategory.GENERAL) }
    var draftSuspectId by remember { mutableStateOf<SuspectId?>(null) }
    var draftClueId by remember { mutableStateOf<String?>(null) }

    var activeFilter by remember { mutableStateOf(NotebookFilter.ALL) }
    var searchQuery by remember { mutableStateOf("") }

    fun resetComposer() {
        editingNoteId = null
        draftTitle = ""
        draftBody = ""
        draftCategory = NoteCategory.GENERAL
        draftSuspectId = null
        draftClueId = null
    }

    fun startEdit(note: DetectiveNote) {
        editingNoteId = note.id
        draftTitle = note.title
        draftBody = note.body
        draftCategory = note.category
        draftSuspectId = note.linkedSuspectId
        draftClueId = note.linkedClueId
    }

    val sortedAndFilteredNotes = remember(
        progress.detectiveNotes,
        activeFilter,
        searchQuery
    ) {
        val q = searchQuery.trim().lowercase()
        progress.detectiveNotes
            .filter { note ->
                val matchesFilter = when (activeFilter) {
                    NotebookFilter.ALL -> true
                    NotebookFilter.PINNED -> note.isPinned
                    NotebookFilter.SUSPECT -> note.category == NoteCategory.SUSPECT || note.linkedSuspectId != null
                    NotebookFilter.CLUE -> note.category == NoteCategory.CLUE || note.linkedClueId != null
                    NotebookFilter.THEORY -> note.category == NoteCategory.THEORY
                }
                val matchesQuery = q.isEmpty() ||
                    note.title.lowercase().contains(q) ||
                    note.body.lowercase().contains(q)
                matchesFilter && matchesQuery
            }
            .sortedWith(
                compareByDescending<DetectiveNote> { it.isPinned }
                    .thenByDescending { it.updatedAtMillis }
            )
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        val isWide = maxWidth >= 680.dp

        if (isWide) {
            Row(
                modifier = Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .weight(0.95f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    NotebookComposerCard(
                        isEditing = editingNoteId != null,
                        title = draftTitle,
                        body = draftBody,
                        category = draftCategory,
                        linkedSuspectId = draftSuspectId,
                        linkedClueId = draftClueId,
                        collectedEvidence = collectedEvidence,
                        caseData = caseData,
                        strings = strings,
                        onTitleChange = { draftTitle = it },
                        onBodyChange = { draftBody = it },
                        onCategoryChange = { draftCategory = it },
                        onSuspectChange = { draftSuspectId = it },
                        onClueChange = { draftClueId = it },
                        onSubmit = {
                            if (draftBody.isNotBlank()) {
                                onSaveNote(
                                    editingNoteId,
                                    draftTitle,
                                    draftBody,
                                    draftCategory,
                                    draftSuspectId,
                                    draftClueId
                                )
                                resetComposer()
                            }
                        },
                        onCancelEdit = { resetComposer() }
                    )
                }
                Column(
                    modifier = Modifier
                        .weight(1.05f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    NotebookEntriesSection(
                        notes = sortedAndFilteredNotes,
                        totalNotesCount = progress.detectiveNotes.size,
                        activeFilter = activeFilter,
                        searchQuery = searchQuery,
                        caseData = caseData,
                        strings = strings,
                        onFilterChange = { activeFilter = it },
                        onSearchQueryChange = { searchQuery = it },
                        onTogglePin = onTogglePin,
                        onEditNote = { startEdit(it) },
                        onDeleteNote = { id ->
                            if (editingNoteId == id) resetComposer()
                            onDeleteNote(id)
                        }
                    )
                }
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                NotebookComposerCard(
                    isEditing = editingNoteId != null,
                    title = draftTitle,
                    body = draftBody,
                    category = draftCategory,
                    linkedSuspectId = draftSuspectId,
                    linkedClueId = draftClueId,
                    collectedEvidence = collectedEvidence,
                    caseData = caseData,
                    strings = strings,
                    onTitleChange = { draftTitle = it },
                    onBodyChange = { draftBody = it },
                    onCategoryChange = { draftCategory = it },
                    onSuspectChange = { draftSuspectId = it },
                    onClueChange = { draftClueId = it },
                    onSubmit = {
                        if (draftBody.isNotBlank()) {
                            onSaveNote(
                                editingNoteId,
                                draftTitle,
                                draftBody,
                                draftCategory,
                                draftSuspectId,
                                draftClueId
                            )
                            resetComposer()
                        }
                    },
                    onCancelEdit = { resetComposer() }
                )

                NotebookEntriesSection(
                    notes = sortedAndFilteredNotes,
                    totalNotesCount = progress.detectiveNotes.size,
                    activeFilter = activeFilter,
                    searchQuery = searchQuery,
                    caseData = caseData,
                    strings = strings,
                    onFilterChange = { activeFilter = it },
                    onSearchQueryChange = { searchQuery = it },
                    onTogglePin = onTogglePin,
                    onEditNote = { startEdit(it) },
                    onDeleteNote = { id ->
                        if (editingNoteId == id) resetComposer()
                        onDeleteNote(id)
                    }
                )
                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }
}

@Composable
private fun NotebookComposerCard(
    isEditing: Boolean,
    title: String,
    body: String,
    category: NoteCategory,
    linkedSuspectId: SuspectId?,
    linkedClueId: String?,
    collectedEvidence: List<EvidenceItem>,
    caseData: LocalizedCaseData,
    strings: UiStrings,
    onTitleChange: (String) -> Unit,
    onBodyChange: (String) -> Unit,
    onCategoryChange: (NoteCategory) -> Unit,
    onSuspectChange: (SuspectId?) -> Unit,
    onClueChange: (String?) -> Unit,
    onSubmit: () -> Unit,
    onCancelEdit: () -> Unit
) {
    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedTextColor = ParchmentWhite,
        unfocusedTextColor = ParchmentWhite,
        focusedBorderColor = BrassGold,
        unfocusedBorderColor = NoirBorder,
        focusedContainerColor = NoirBlack.copy(alpha = 0.6f),
        unfocusedContainerColor = NoirBlack.copy(alpha = 0.45f),
        focusedLabelColor = BrassGold,
        unfocusedLabelColor = FogGray,
        cursorColor = BrassGold
    )

    NoirCard(borderColor = if (isEditing) CrimsonBright else BrassGold.copy(alpha = 0.5f)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.MenuBook,
                    contentDescription = null,
                    tint = BrassGold,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isEditing) strings.notebookEditHeader else strings.notebookComposeHeader,
                    style = MaterialTheme.typography.labelLarge,
                    color = if (isEditing) CrimsonBright else BrassGold
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = title,
            onValueChange = onTitleChange,
            label = { Text(strings.noteTitleLabel) },
            placeholder = { Text(strings.noteTitleHint, color = FogGray.copy(alpha = 0.6f)) },
            singleLine = true,
            colors = fieldColors,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("note_title_input")
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = body,
            onValueChange = onBodyChange,
            label = { Text(strings.noteBodyLabel) },
            placeholder = { Text(strings.noteBodyHint, color = FogGray.copy(alpha = 0.6f)) },
            minLines = 3,
            maxLines = 6,
            colors = fieldColors,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("note_body_input")
        )

        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = strings.noteCategoryLabel,
            style = MaterialTheme.typography.labelSmall,
            color = BrassGold
        )
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            NoteCategory.entries.forEach { cat ->
                val selected = cat == category
                NotebookTagChip(
                    label = categoryLabel(cat, strings),
                    selected = selected,
                    onClick = { onCategoryChange(cat) },
                    testTag = "note_cat_${cat.name.lowercase()}"
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = strings.noteLinkSuspectLabel,
            style = MaterialTheme.typography.labelSmall,
            color = BrassGold
        )
        Spacer(modifier = Modifier.height(6.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            NotebookTagChip(
                label = strings.noteNoneOption,
                selected = linkedSuspectId == null,
                onClick = { onSuspectChange(null) },
                testTag = "note_suspect_none"
            )
            caseData.suspects.forEach { suspect ->
                val selected = linkedSuspectId == suspect.id
                NotebookTagChip(
                    label = suspect.fullName.substringBefore(" "),
                    selected = selected,
                    onClick = { onSuspectChange(if (selected) null else suspect.id) },
                    testTag = "note_suspect_${suspect.id.name.lowercase()}"
                )
            }
        }

        if (collectedEvidence.isNotEmpty()) {
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = strings.noteLinkClueLabel,
                style = MaterialTheme.typography.labelSmall,
                color = BrassGold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                NotebookTagChip(
                    label = strings.noteNoneOption,
                    selected = linkedClueId == null,
                    onClick = { onClueChange(null) },
                    testTag = "note_clue_none"
                )
                collectedEvidence.forEach { item ->
                    val selected = linkedClueId == item.id
                    NotebookTagChip(
                        label = item.title,
                        selected = selected,
                        onClick = { onClueChange(if (selected) null else item.id) },
                        testTag = "note_clue_${item.id}"
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (isEditing) {
                NoirSecondaryButton(
                    text = strings.noteCancelEdit,
                    onClick = onCancelEdit,
                    icon = Icons.Filled.Close,
                    modifier = Modifier.weight(0.9f),
                    testTag = "cancel_edit_note_button"
                )
            }
            NoirPrimaryButton(
                text = if (isEditing) strings.noteUpdateButton else strings.noteSaveButton,
                onClick = onSubmit,
                enabled = body.isNotBlank(),
                icon = Icons.Filled.Save,
                modifier = Modifier.weight(1.1f),
                testTag = "save_note_button"
            )
        }
    }
}

@Composable
private fun NotebookEntriesSection(
    notes: List<DetectiveNote>,
    totalNotesCount: Int,
    activeFilter: NotebookFilter,
    searchQuery: String,
    caseData: LocalizedCaseData,
    strings: UiStrings,
    onFilterChange: (NotebookFilter) -> Unit,
    onSearchQueryChange: (String) -> Unit,
    onTogglePin: (String) -> Unit,
    onEditNote: (DetectiveNote) -> Unit,
    onDeleteNote: (String) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "${strings.notebookSavedHeader} ($totalNotesCount)",
            style = MaterialTheme.typography.labelLarge,
            color = BrassGold
        )
    }

    AnimatedVisibility(visible = totalNotesCount > 0) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchQueryChange,
                placeholder = { Text(strings.noteSearchHint, color = FogGray.copy(alpha = 0.65f)) },
                leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = BrassGold) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchQueryChange("") }) {
                            Icon(Icons.Filled.Close, contentDescription = strings.closeLabel, tint = FogGray)
                        }
                    }
                },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = ParchmentWhite,
                    unfocusedTextColor = ParchmentWhite,
                    focusedBorderColor = BrassGold,
                    unfocusedBorderColor = NoirBorder,
                    focusedContainerColor = NoirCharcoal,
                    unfocusedContainerColor = NoirCharcoal,
                    cursorColor = BrassGold
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("note_search_input")
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                NotebookTagChip(
                    label = strings.noteFilterAll,
                    selected = activeFilter == NotebookFilter.ALL,
                    onClick = { onFilterChange(NotebookFilter.ALL) },
                    testTag = "note_filter_all"
                )
                NotebookTagChip(
                    label = strings.noteFilterPinned,
                    selected = activeFilter == NotebookFilter.PINNED,
                    onClick = { onFilterChange(NotebookFilter.PINNED) },
                    testTag = "note_filter_pinned"
                )
                NotebookTagChip(
                    label = strings.noteCatSuspect,
                    selected = activeFilter == NotebookFilter.SUSPECT,
                    onClick = { onFilterChange(NotebookFilter.SUSPECT) },
                    testTag = "note_filter_suspect"
                )
                NotebookTagChip(
                    label = strings.noteCatClue,
                    selected = activeFilter == NotebookFilter.CLUE,
                    onClick = { onFilterChange(NotebookFilter.CLUE) },
                    testTag = "note_filter_clue"
                )
                NotebookTagChip(
                    label = strings.noteCatTheory,
                    selected = activeFilter == NotebookFilter.THEORY,
                    onClick = { onFilterChange(NotebookFilter.THEORY) },
                    testTag = "note_filter_theory"
                )
            }
        }
    }

    if (notes.isEmpty()) {
        NoirCard {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.MenuBook,
                contentDescription = null,
                tint = BrassGold,
                modifier = Modifier.size(34.dp)
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = strings.notebookEmptyTitle,
                style = MaterialTheme.typography.headlineMedium,
                color = ParchmentWhite
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = strings.notebookEmptyBody,
                style = MaterialTheme.typography.bodyMedium,
                color = FogGray
            )
        }
    } else {
        val dateFormat = remember { DateFormat.getTimeInstance(DateFormat.SHORT) }
        notes.forEach { note ->
            val suspectName = note.linkedSuspectId?.let { sId ->
                caseData.suspects.firstOrNull { it.id == sId }?.fullName
            }
            val clueName = note.linkedClueId?.let { cId ->
                caseData.clues.firstOrNull { it.id == cId }?.title
            }
            NoirCard(
                borderColor = if (note.isPinned) BrassGold else NoirBorder,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("note_card_${note.id}")
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        ForensicBadge(
                            text = categoryLabel(note.category, strings).uppercase(),
                            color = when (note.category) {
                                NoteCategory.SUSPECT -> CrimsonBright
                                NoteCategory.CLUE -> VerifiedTeal
                                NoteCategory.THEORY -> BrassGold
                                NoteCategory.GENERAL -> FogGray
                            }
                        )
                        if (note.isPinned) {
                            ForensicBadge(
                                text = strings.notePinnedBadge,
                                color = BrassGold,
                                containerColor = CrimsonSoft
                            )
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = { onTogglePin(note.id) },
                            modifier = Modifier.testTag("note_pin_${note.id}")
                        ) {
                            Icon(
                                imageVector = if (note.isPinned) Icons.Filled.PushPin else Icons.Outlined.PushPin,
                                contentDescription = strings.notePinDesc,
                                tint = if (note.isPinned) BrassGold else FogGray
                            )
                        }
                        IconButton(
                            onClick = { onEditNote(note) },
                            modifier = Modifier.testTag("note_edit_${note.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Edit,
                                contentDescription = strings.noteEditDesc,
                                tint = ParchmentWhite
                            )
                        }
                        IconButton(
                            onClick = { onDeleteNote(note.id) },
                            modifier = Modifier.testTag("note_delete_${note.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.DeleteOutline,
                                contentDescription = strings.noteDeleteDesc,
                                tint = CrimsonBright
                            )
                        }
                    }
                }

                if (note.title.isNotBlank()) {
                    Text(
                        text = note.title,
                        style = MaterialTheme.typography.titleMedium,
                        color = ParchmentWhite
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                }

                Text(
                    text = note.body,
                    style = MaterialTheme.typography.bodyMedium,
                    color = ParchmentWhite.copy(alpha = 0.92f)
                )

                if (suspectName != null || clueName != null || note.updatedAtMillis > 0L) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        suspectName?.let {
                            ForensicBadge(
                                text = it,
                                color = CrimsonBright,
                                containerColor = CrimsonSoft
                            )
                        }
                        clueName?.let {
                            ForensicBadge(
                                text = it,
                                color = VerifiedTeal,
                                containerColor = VerifiedTealSoft
                            )
                        }
                        if (note.updatedAtMillis > 0L) {
                            Text(
                                text = dateFormat.format(Date(note.updatedAtMillis)),
                                style = MaterialTheme.typography.labelSmall,
                                color = FogGray
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NotebookTagChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    Surface(
        modifier = Modifier
            .clickable(onClick = onClick)
            .testTag(testTag),
        shape = MaterialTheme.shapes.small,
        color = if (selected) CrimsonSoft else NoirSlate,
        border = BorderStroke(1.dp, if (selected) BrassGold else NoirBorder)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = if (selected) ParchmentWhite else FogGray,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
        )
    }
}

private fun categoryLabel(category: NoteCategory, strings: UiStrings): String = when (category) {
    NoteCategory.GENERAL -> strings.noteCatGeneral
    NoteCategory.SUSPECT -> strings.noteCatSuspect
    NoteCategory.CLUE -> strings.noteCatClue
    NoteCategory.THEORY -> strings.noteCatTheory
}
