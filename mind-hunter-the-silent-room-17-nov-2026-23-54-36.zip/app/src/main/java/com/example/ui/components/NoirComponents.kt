package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.GameScreen
import com.example.ui.theme.BrassGold
import com.example.ui.theme.CrimsonBright
import com.example.ui.theme.CrimsonMuted
import com.example.ui.theme.CrimsonSoft
import com.example.ui.theme.FogGray
import com.example.ui.theme.NoirBlack
import com.example.ui.theme.NoirBorder
import com.example.ui.theme.NoirCharcoal
import com.example.ui.theme.NoirSlate
import com.example.ui.theme.ParchmentWhite
import kotlinx.coroutines.delay

@Composable
fun AnimatedNoirBackdrop(
    modifier: Modifier = Modifier,
    crimsonPulseIntensity: Float = 0.22f
) {
    val infiniteTransition = rememberInfiniteTransition(label = "noir_atmosphere")
    val rainOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rain_progress"
    )
    val glowPulse by infiniteTransition.animateFloat(
        initialValue = 0.7f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 4200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "crimson_glow"
    )

    val streaks = remember {
        List(28) { idx ->
            Triple(
                ((idx * 37) % 100) / 100f,
                ((idx * 53) % 100) / 100f,
                0.04f + ((idx % 4) * 0.025f)
            )
        }
    }

    Canvas(modifier = modifier.fillMaxSize()) {
        drawRect(color = NoirBlack)

        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    CrimsonMuted.copy(alpha = crimsonPulseIntensity * glowPulse),
                    Color.Transparent
                ),
                center = Offset(size.width * 0.82f, size.height * 0.16f),
                radius = size.maxDimension * 0.65f
            )
        )

        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    BrassGold.copy(alpha = 0.06f),
                    Color.Transparent
                ),
                center = Offset(size.width * 0.18f, size.height * 0.85f),
                radius = size.maxDimension * 0.5f
            )
        )

        streaks.forEach { (xFrac, ySeed, lenFrac) ->
            val yFrac = (ySeed + rainOffset) % 1f
            val startX = xFrac * size.width
            val startY = yFrac * size.height
            val endX = startX - size.width * 0.018f
            val endY = startY + size.height * lenFrac
            drawLine(
                color = ParchmentWhite.copy(alpha = 0.06f),
                start = Offset(startX, startY),
                end = Offset(endX, endY),
                strokeWidth = 1.2f
            )
        }
    }
}

@Composable
fun NoirCard(
    modifier: Modifier = Modifier,
    borderColor: Color = NoirBorder,
    containerColor: Color = NoirCharcoal.copy(alpha = 0.92f),
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val cardModifier = if (onClick != null) {
        modifier.clickable(onClick = onClick)
    } else {
        modifier
    }
    Surface(
        modifier = cardModifier,
        shape = MaterialTheme.shapes.medium,
        color = containerColor,
        border = BorderStroke(1.dp, borderColor),
        tonalElevation = 2.dp
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            content = content
        )
    }
}

@Composable
fun NoirPrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    icon: ImageVector? = null,
    testTag: String? = null
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = (if (testTag != null) modifier.testTag(testTag) else modifier)
            .height(50.dp),
        shape = MaterialTheme.shapes.small,
        colors = ButtonDefaults.buttonColors(
            containerColor = CrimsonMuted,
            contentColor = ParchmentWhite,
            disabledContainerColor = NoirSlate,
            disabledContentColor = FogGray.copy(alpha = 0.5f)
        ),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp)
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
        }
        Text(
            text = text,
            style = MaterialTheme.typography.titleMedium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun NoirSecondaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    icon: ImageVector? = null,
    testTag: String? = null
) {
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        modifier = (if (testTag != null) modifier.testTag(testTag) else modifier)
            .height(48.dp),
        shape = MaterialTheme.shapes.small,
        border = BorderStroke(1.dp, if (enabled) NoirBorder else NoirBorder.copy(alpha = 0.4f)),
        colors = ButtonDefaults.outlinedButtonColors(
            containerColor = NoirSlate.copy(alpha = 0.65f),
            contentColor = ParchmentWhite,
            disabledContentColor = FogGray.copy(alpha = 0.4f)
        ),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp)
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(18.dp), tint = BrassGold)
            Spacer(modifier = Modifier.width(8.dp))
        }
        Text(
            text = text,
            style = MaterialTheme.typography.titleMedium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun ForensicBadge(
    text: String,
    color: Color = BrassGold,
    containerColor: Color = NoirSlate,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(4.dp),
        color = containerColor,
        border = BorderStroke(1.dp, color.copy(alpha = 0.5f))
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall,
            color = color,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun TypewriterText(
    fullText: String,
    fastMode: Boolean,
    style: TextStyle = MaterialTheme.typography.bodyLarge,
    color: Color = ParchmentWhite,
    modifier: Modifier = Modifier
) {
    var visibleChars by remember(fullText) { mutableIntStateOf(if (fastMode) fullText.length else 0) }

    LaunchedEffect(fullText, fastMode) {
        if (fastMode) {
            visibleChars = fullText.length
            return@LaunchedEffect
        }
        visibleChars = 0
        while (visibleChars < fullText.length) {
            val step = (visibleChars + 2).coerceAtMost(fullText.length)
            visibleChars = step
            delay(14L)
        }
    }

    Text(
        text = fullText.take(visibleChars),
        style = style,
        color = color,
        modifier = modifier.clickable { visibleChars = fullText.length }
    )
}

@Composable
fun InvestigationTopBar(
    title: String,
    subtitle: String,
    cluesCount: Int,
    connectionsCount: Int,
    cluesLabel: String,
    linksLabel: String,
    isMuted: Boolean,
    isNotebookActive: Boolean = false,
    notebookContentDesc: String = "Detective's Notebook",
    onOpenNotebook: () -> Unit = {},
    onBackClick: () -> Unit,
    onToggleMute: () -> Unit
) {
    Surface(
        color = NoirCharcoal.copy(alpha = 0.96f),
        border = BorderStroke(0.dp, Color.Transparent),
        tonalElevation = 4.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .windowInsetsPadding(WindowInsets.statusBars)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier.testTag("top_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = ParchmentWhite
                    )
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium,
                        color = ParchmentWhite,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.labelSmall,
                        color = BrassGold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                ForensicBadge(
                    text = "$cluesCount/8 $cluesLabel · $connectionsCount/5 $linksLabel",
                    color = BrassGold,
                    containerColor = NoirSlate
                )
                Spacer(modifier = Modifier.width(2.dp))
                IconButton(
                    onClick = onOpenNotebook,
                    modifier = Modifier.testTag("top_notebook_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.MenuBook,
                        contentDescription = notebookContentDesc,
                        tint = if (isNotebookActive) BrassGold else ParchmentWhite
                    )
                }
                IconButton(
                    onClick = onToggleMute,
                    modifier = Modifier.testTag("mute_toggle_button")
                ) {
                    Icon(
                        imageVector = if (isMuted) Icons.AutoMirrored.Filled.VolumeOff else Icons.AutoMirrored.Filled.VolumeUp,
                        contentDescription = if (isMuted) "Unmute audio" else "Mute audio",
                        tint = if (isMuted) FogGray else ParchmentWhite
                    )
                }
            }
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .padding(horizontal = 12.dp)
            ) {
                Surface(modifier = Modifier.fillMaxSize(), color = NoirBorder) {}
            }
        }
    }
}

@Composable
fun InvestigationBottomBar(
    currentScreen: GameScreen,
    navSceneLabel: String,
    navSuspectsLabel: String,
    navBoardLabel: String,
    navAccuseLabel: String,
    onNavigate: (GameScreen) -> Unit
) {
    NavigationBar(
        containerColor = NoirCharcoal,
        contentColor = ParchmentWhite,
        windowInsets = WindowInsets.navigationBars,
        tonalElevation = 6.dp
    ) {
        val items = listOf(
            Triple(GameScreen.CRIME_SCENE, navSceneLabel, Icons.Filled.Search),
            Triple(GameScreen.SUSPECT_SELECTION, navSuspectsLabel, Icons.Filled.Group),
            Triple(GameScreen.EVIDENCE_BOARD, navBoardLabel, Icons.Filled.Dashboard),
            Triple(GameScreen.ACCUSATION, navAccuseLabel, Icons.Filled.Gavel)
        )
        items.forEachIndexed { idx, (screen, label, icon) ->
            val tagKey = listOf("scene", "suspects", "board", "accuse")[idx]
            val selected = currentScreen == screen ||
                (screen == GameScreen.SUSPECT_SELECTION && currentScreen == GameScreen.INTERROGATION)
            NavigationBarItem(
                selected = selected,
                onClick = { onNavigate(screen) },
                icon = { Icon(icon, contentDescription = label) },
                label = {
                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1
                    )
                },
                modifier = Modifier.testTag("nav_$tagKey"),
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = ParchmentWhite,
                    selectedTextColor = CrimsonBright,
                    indicatorColor = CrimsonSoft,
                    unselectedIconColor = FogGray,
                    unselectedTextColor = FogGray
                )
            )
        }
    }
}
