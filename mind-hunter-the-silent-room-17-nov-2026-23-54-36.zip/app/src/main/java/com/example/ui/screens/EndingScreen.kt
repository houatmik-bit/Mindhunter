package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.data.LocalizedCaseData
import com.example.data.UiStrings
import com.example.model.EndingResult
import com.example.model.InvestigationProgress
import com.example.ui.components.AnimatedNoirBackdrop
import com.example.ui.components.ForensicBadge
import com.example.ui.components.NoirCard
import com.example.ui.components.NoirPrimaryButton
import com.example.ui.components.NoirSecondaryButton
import com.example.ui.theme.BrassGold
import com.example.ui.theme.CrimsonBright
import com.example.ui.theme.FogGray
import com.example.ui.theme.NoirBorder
import com.example.ui.theme.NoirSlate
import com.example.ui.theme.ParchmentWhite
import com.example.ui.theme.VerifiedTeal

@Composable
fun EndingScreen(
    ending: EndingResult,
    progress: InvestigationProgress,
    strings: UiStrings,
    caseData: LocalizedCaseData,
    onReplayCase: () -> Unit,
    onReturnToMenu: () -> Unit
) {
    BackHandler { onReturnToMenu() }

    val accentColor = if (ending.isSolvedCorrectly) VerifiedTeal else CrimsonBright

    Box(modifier = Modifier.fillMaxSize()) {
        AnimatedNoirBackdrop(crimsonPulseIntensity = if (ending.isSolvedCorrectly) 0.14f else 0.28f)
        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .widthIn(max = 760.dp)
                .align(Alignment.TopCenter)
                .padding(horizontal = 20.dp, vertical = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                ForensicBadge(text = ending.verdictBadge, color = accentColor)
                ForensicBadge(text = ending.profilerRating, color = BrassGold)
            }

            Text(
                text = ending.title,
                style = MaterialTheme.typography.displayMedium,
                color = ParchmentWhite
            )
            Text(
                text = ending.subtitle,
                style = MaterialTheme.typography.titleMedium,
                color = accentColor
            )

            NoirCard(borderColor = accentColor.copy(alpha = 0.65f)) {
                Text(
                    text = strings.verdictAftermathHeader,
                    style = MaterialTheme.typography.labelLarge,
                    color = BrassGold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = ending.narrativeSummary,
                    style = MaterialTheme.typography.bodyLarge,
                    color = ParchmentWhite
                )
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ForensicBadge(text = "${strings.cluesLabel} ${progress.collectedClues.size}/8", color = BrassGold)
                    ForensicBadge(text = "${strings.linksLabel} ${progress.discoveredConnections.size}/5", color = VerifiedTeal)
                    ForensicBadge(text = "${strings.liesExposedLabel} ${progress.detectedContradictions.size}", color = CrimsonBright)
                }
            }

            if (progress.recordedDecisions.isNotEmpty()) {
                NoirCard {
                    Text(
                        text = strings.keyDecisionsHeader,
                        style = MaterialTheme.typography.labelLarge,
                        color = BrassGold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    progress.recordedDecisions.forEach { decision ->
                        Text(
                            text = "• $decision",
                            style = MaterialTheme.typography.bodyMedium,
                            color = FogGray,
                            modifier = Modifier.padding(vertical = 2.dp)
                        )
                    }
                }
            }

            NoirCard(borderColor = BrassGold.copy(alpha = 0.55f)) {
                Text(
                    text = strings.completeSolutionHeader,
                    style = MaterialTheme.typography.labelLarge,
                    color = BrassGold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = strings.trueCulpritHeader,
                    style = MaterialTheme.typography.titleLarge,
                    color = CrimsonBright
                )
                Spacer(modifier = Modifier.height(10.dp))
                caseData.fullSolutionSteps.forEach { step ->
                    Surface(
                        shape = MaterialTheme.shapes.small,
                        color = NoirSlate,
                        border = BorderStroke(1.dp, NoirBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp)
                    ) {
                        Text(
                            text = step,
                            style = MaterialTheme.typography.bodyMedium,
                            color = ParchmentWhite,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }
            }

            NoirPrimaryButton(
                text = strings.replayInvestigation,
                onClick = onReplayCase,
                icon = Icons.Filled.Refresh,
                modifier = Modifier.fillMaxWidth(),
                testTag = "ending_replay_button"
            )
            NoirSecondaryButton(
                text = strings.returnToMainMenu,
                onClick = onReturnToMenu,
                icon = Icons.Filled.Home,
                modifier = Modifier.fillMaxWidth(),
                testTag = "ending_menu_button"
            )

            Spacer(modifier = Modifier.height(14.dp))
        }
    }
}
