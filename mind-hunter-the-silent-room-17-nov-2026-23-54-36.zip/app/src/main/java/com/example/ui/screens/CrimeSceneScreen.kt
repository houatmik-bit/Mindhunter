package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FactCheck
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.LocalizedCaseData
import com.example.data.UiStrings
import com.example.model.CrimeZone
import com.example.model.InvestigationProgress
import com.example.ui.components.ForensicBadge
import com.example.ui.components.NoirCard
import com.example.ui.components.NoirPrimaryButton
import com.example.ui.components.NoirSecondaryButton
import com.example.ui.theme.BrassGold
import com.example.ui.theme.CrimsonBright
import com.example.ui.theme.CrimsonMuted
import com.example.ui.theme.FogGray
import com.example.ui.theme.NoirBlack
import com.example.ui.theme.NoirBorder
import com.example.ui.theme.NoirCharcoal
import com.example.ui.theme.NoirSlate
import com.example.ui.theme.ParchmentWhite
import com.example.ui.theme.VerifiedTeal
import kotlin.math.roundToInt

@Composable
fun CrimeSceneScreen(
    progress: InvestigationProgress,
    strings: UiStrings,
    caseData: LocalizedCaseData,
    activeZoneId: String?,
    outcomeText: String?,
    onSelectZone: (String) -> Unit,
    onInspectZone: (String, Boolean) -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    val selectedZone = caseData.crimeZones.firstOrNull { it.id == activeZoneId }
        ?: caseData.crimeZones.first()

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        val isWide = maxWidth >= 680.dp

        if (isWide) {
            Row(
                modifier = Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .weight(1.05f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    CrimeSceneInteractiveMap(
                        caseData = caseData,
                        strings = strings,
                        selectedZoneId = selectedZone.id,
                        inspectedZones = progress.inspectedZones,
                        onSelectZone = onSelectZone
                    )
                    ZoneSelectorChips(
                        zones = caseData.crimeZones,
                        selectedZoneId = selectedZone.id,
                        inspectedZones = progress.inspectedZones,
                        onSelectZone = onSelectZone
                    )
                }
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    ZoneInspectionPanel(
                        zone = selectedZone,
                        caseData = caseData,
                        strings = strings,
                        progress = progress,
                        outcomeText = outcomeText,
                        onInspectZone = onInspectZone
                    )
                }
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                CrimeSceneInteractiveMap(
                    caseData = caseData,
                    strings = strings,
                    selectedZoneId = selectedZone.id,
                    inspectedZones = progress.inspectedZones,
                    onSelectZone = onSelectZone
                )
                ZoneSelectorChips(
                    zones = caseData.crimeZones,
                    selectedZoneId = selectedZone.id,
                    inspectedZones = progress.inspectedZones,
                    onSelectZone = onSelectZone
                )
                ZoneInspectionPanel(
                    zone = selectedZone,
                    caseData = caseData,
                    strings = strings,
                    progress = progress,
                    outcomeText = outcomeText,
                    onInspectZone = onInspectZone
                )
                Spacer(modifier = Modifier.height(12.dp))
            }
        }
    }
}

@Composable
private fun CrimeSceneInteractiveMap(
    caseData: LocalizedCaseData,
    strings: UiStrings,
    selectedZoneId: String,
    inspectedZones: Set<String>,
    onSelectZone: (String) -> Unit
) {
    val pulseTransition = rememberInfiniteTransition(label = "hotspot_pulse")
    val pulseScale by pulseTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = strings.sceneHotspotsHeader,
                style = MaterialTheme.typography.labelLarge,
                color = BrassGold
            )
            ForensicBadge(
                text = "${inspectedZones.size}/${caseData.crimeZones.size} ${strings.sweptBadge}",
                color = if (inspectedZones.size == caseData.crimeZones.size) VerifiedTeal else BrassGold
            )
        }
        Spacer(modifier = Modifier.height(8.dp))

        BoxWithConstraints(
            modifier = Modifier
                .fillMaxWidth()
                .height(215.dp)
                .clip(MaterialTheme.shapes.medium)
        ) {
            val mapWidthPx = constraints.maxWidth.toFloat()
            val mapHeightPx = constraints.maxHeight.toFloat()
            val density = LocalDensity.current.density

            Image(
                painter = painterResource(id = R.drawable.img_crime_scene),
                contentDescription = caseData.caseTitle,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color.Transparent, NoirBlack.copy(alpha = 0.55f))
                        )
                    )
            )

            caseData.crimeZones.forEachIndexed { index, zone ->
                val isSelected = zone.id == selectedZoneId
                val isInspected = zone.id in inspectedZones
                val markerPx = 48.dp.value * density
                val xOffset = ((zone.hotspotXFraction * mapWidthPx) - markerPx / 2f).roundToInt()
                    .coerceIn(0, (mapWidthPx - markerPx).roundToInt().coerceAtLeast(0))
                val yOffset = ((zone.hotspotYFraction * mapHeightPx) - markerPx / 2f).roundToInt()
                    .coerceIn(0, (mapHeightPx - markerPx).roundToInt().coerceAtLeast(0))

                Box(
                    modifier = Modifier
                        .offset { IntOffset(xOffset, yOffset) }
                        .size(48.dp)
                        .clip(CircleShape)
                        .clickable { onSelectZone(zone.id) }
                        .testTag("hotspot_${zone.id}"),
                    contentAlignment = Alignment.Center
                ) {
                    if (!isInspected) {
                        Box(
                            modifier = Modifier
                                .size((32 * pulseScale).dp)
                                .background(
                                    color = (if (isSelected) CrimsonBright else BrassGold).copy(alpha = 0.28f),
                                    shape = CircleShape
                                )
                        )
                    }
                    Surface(
                        shape = CircleShape,
                        color = when {
                            isSelected -> CrimsonMuted
                            isInspected -> VerifiedTeal.copy(alpha = 0.9f)
                            else -> NoirCharcoal.copy(alpha = 0.9f)
                        },
                        border = BorderStroke(
                            width = if (isSelected) 2.dp else 1.5.dp,
                            color = if (isSelected) ParchmentWhite else BrassGold
                        ),
                        modifier = Modifier.size(30.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            if (isInspected) {
                                Icon(
                                    imageVector = Icons.Filled.CheckCircle,
                                    contentDescription = zone.name,
                                    tint = ParchmentWhite,
                                    modifier = Modifier.size(16.dp)
                                )
                            } else {
                                Text(
                                    text = "${index + 1}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = ParchmentWhite
                                )
                            }
                        }
                    }
                }
            }

            Text(
                text = strings.tapMarkerHint,
                style = MaterialTheme.typography.labelSmall,
                color = ParchmentWhite.copy(alpha = 0.85f),
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(10.dp)
            )
        }
    }
}

@Composable
private fun ZoneSelectorChips(
    zones: List<CrimeZone>,
    selectedZoneId: String,
    inspectedZones: Set<String>,
    onSelectZone: (String) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        zones.chunked(2).forEach { pair ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                pair.forEach { zone ->
                    val selected = zone.id == selectedZoneId
                    val inspected = zone.id in inspectedZones
                    Surface(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onSelectZone(zone.id) }
                            .testTag("zone_chip_${zone.id}"),
                        shape = MaterialTheme.shapes.small,
                        color = if (selected) NoirSlate else NoirCharcoal,
                        border = BorderStroke(
                            1.dp,
                            when {
                                selected -> CrimsonBright
                                inspected -> VerifiedTeal.copy(alpha = 0.6f)
                                else -> NoirBorder
                            }
                        )
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (inspected) Icons.Filled.CheckCircle else Icons.Filled.Search,
                                contentDescription = null,
                                tint = if (inspected) VerifiedTeal else BrassGold,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = zone.name,
                                style = MaterialTheme.typography.labelMedium,
                                color = ParchmentWhite,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ZoneInspectionPanel(
    zone: CrimeZone,
    caseData: LocalizedCaseData,
    strings: UiStrings,
    progress: InvestigationProgress,
    outcomeText: String?,
    onInspectZone: (String, Boolean) -> Unit
) {
    val isInspected = zone.id in progress.inspectedZones
    val zoneClues = caseData.clues.filter { it.id in zone.clueIds }

    NoirCard(borderColor = if (isInspected) VerifiedTeal.copy(alpha = 0.55f) else BrassGold.copy(alpha = 0.45f)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            ForensicBadge(text = zone.locationLabel, color = BrassGold)
            if (isInspected) {
                ForensicBadge(text = strings.evidenceLoggedBadge, color = VerifiedTeal)
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = zone.name,
            style = MaterialTheme.typography.headlineMedium,
            color = ParchmentWhite
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = zone.initialDescription,
            style = MaterialTheme.typography.bodyMedium,
            color = FogGray
        )
        Spacer(modifier = Modifier.height(14.dp))

        NoirPrimaryButton(
            text = if (isInspected) strings.reverifyForensics else zone.carefulActionLabel,
            onClick = { onInspectZone(zone.id, true) },
            icon = Icons.Filled.FactCheck,
            modifier = Modifier.fillMaxWidth(),
            testTag = "inspect_careful_${zone.id}"
        )

        if (!isInspected) {
            Spacer(modifier = Modifier.height(8.dp))
            NoirSecondaryButton(
                text = zone.quickActionLabel,
                onClick = { onInspectZone(zone.id, false) },
                icon = Icons.Filled.FlashOn,
                modifier = Modifier.fillMaxWidth(),
                testTag = "inspect_quick_${zone.id}"
            )
        }

        AnimatedVisibility(visible = outcomeText != null) {
            Column {
                Spacer(modifier = Modifier.height(12.dp))
                Surface(
                    shape = MaterialTheme.shapes.small,
                    color = NoirBlack.copy(alpha = 0.65f),
                    border = BorderStroke(1.dp, BrassGold.copy(alpha = 0.5f))
                ) {
                    Text(
                        text = outcomeText.orEmpty(),
                        style = MaterialTheme.typography.bodyMedium,
                        color = ParchmentWhite,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }
        }

        if (isInspected) {
            Spacer(modifier = Modifier.height(14.dp))
            Text(
                text = strings.recoveredCluesHeader,
                style = MaterialTheme.typography.labelLarge,
                color = BrassGold
            )
            Spacer(modifier = Modifier.height(8.dp))
            zoneClues.forEach { clue ->
                Surface(
                    shape = MaterialTheme.shapes.small,
                    color = NoirSlate,
                    border = BorderStroke(1.dp, NoirBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = clue.title,
                                style = MaterialTheme.typography.titleMedium,
                                color = ParchmentWhite,
                                modifier = Modifier.weight(1f)
                            )
                            ForensicBadge(text = clue.category.label, color = BrassGold)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = clue.forensicDetail,
                            style = MaterialTheme.typography.bodyMedium,
                            color = FogGray
                        )
                    }
                }
            }
        }
    }
}
