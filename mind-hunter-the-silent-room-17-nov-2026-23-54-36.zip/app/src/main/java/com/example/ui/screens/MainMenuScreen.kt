package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.LocalizedCaseData
import com.example.data.UiStrings
import com.example.model.AppLanguage
import com.example.model.GameScreen
import com.example.model.InvestigationProgress
import com.example.ui.components.AnimatedNoirBackdrop
import com.example.ui.components.ForensicBadge
import com.example.ui.components.NoirCard
import com.example.ui.components.NoirPrimaryButton
import com.example.ui.components.NoirSecondaryButton
import com.example.ui.theme.BrassGold
import com.example.ui.theme.CrimsonBright
import com.example.ui.theme.CrimsonMuted
import com.example.ui.theme.CrimsonSoft
import com.example.ui.theme.FogGray
import com.example.ui.theme.NoirBlack
import com.example.ui.theme.NoirBorder
import com.example.ui.theme.NoirCharcoal
import com.example.ui.theme.NoirSlate
import com.example.ui.theme.ParchmentWhite

@Composable
fun MainMenuScreen(
    progress: InvestigationProgress,
    currentLanguage: AppLanguage,
    strings: UiStrings,
    caseData: LocalizedCaseData,
    isMuted: Boolean,
    onSelectLanguage: (AppLanguage) -> Unit,
    onNewInvestigation: () -> Unit,
    onContinueInvestigation: () -> Unit,
    onNavigate: (GameScreen) -> Unit,
    onToggleMute: () -> Unit
) {
    var confirmOverwrite by remember { mutableStateOf(false) }

    Box(modifier = Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(id = R.drawable.img_crime_scene),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxSize()
                .alpha(0.24f)
        )
        AnimatedNoirBackdrop(
            modifier = Modifier.alpha(0.82f),
            crimsonPulseIntensity = 0.25f
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            NoirBlack.copy(alpha = 0.55f),
                            NoirBlack.copy(alpha = 0.85f),
                            NoirBlack.copy(alpha = 0.96f)
                        )
                    )
                )
        )

        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .padding(horizontal = 24.dp, vertical = 16.dp)
        ) {
            val isWide = maxWidth >= 660.dp

            // Top bar: Language switcher + mute toggle
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.TopCenter),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                LanguagePillBar(
                    currentLanguage = currentLanguage,
                    onSelectLanguage = onSelectLanguage
                )
                IconButton(
                    onClick = onToggleMute,
                    modifier = Modifier.testTag("menu_mute_button")
                ) {
                    Icon(
                        imageVector = if (isMuted) Icons.AutoMirrored.Filled.VolumeOff else Icons.AutoMirrored.Filled.VolumeUp,
                        contentDescription = if (isMuted) "Unmute sound" else "Mute sound",
                        tint = ParchmentWhite
                    )
                }
            }

            if (isWide) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(top = 56.dp),
                    horizontalArrangement = Arrangement.spacedBy(28.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.Center
                    ) {
                        MainMenuHeader(strings = strings)
                    }
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .widthIn(max = 420.dp)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.Center
                    ) {
                        MainMenuActions(
                            progress = progress,
                            strings = strings,
                            caseData = caseData,
                            onNewInvestigationClick = {
                                if (progress.hasActiveInvestigation && progress.achievedEndingId == null) {
                                    confirmOverwrite = true
                                } else {
                                    onNewInvestigation()
                                }
                            },
                            onContinueInvestigation = onContinueInvestigation,
                            onNavigate = onNavigate
                        )
                    }
                }
            } else {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .widthIn(max = 520.dp)
                        .align(Alignment.Center)
                        .padding(top = 52.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Spacer(modifier = Modifier.height(16.dp))
                    MainMenuHeader(strings = strings)
                    Spacer(modifier = Modifier.height(24.dp))
                    MainMenuActions(
                        progress = progress,
                        strings = strings,
                        caseData = caseData,
                        onNewInvestigationClick = {
                            if (progress.hasActiveInvestigation && progress.achievedEndingId == null) {
                                confirmOverwrite = true
                            } else {
                                onNewInvestigation()
                            }
                        },
                        onContinueInvestigation = onContinueInvestigation,
                        onNavigate = onNavigate
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                }
            }
        }
    }

    if (confirmOverwrite) {
        AlertDialog(
            onDismissRequest = { confirmOverwrite = false },
            containerColor = NoirCharcoal,
            titleContentColor = ParchmentWhite,
            textContentColor = FogGray,
            title = { Text(strings.startFreshTitle) },
            text = { Text(strings.startFreshBody) },
            confirmButton = {
                TextButton(
                    onClick = {
                        confirmOverwrite = false
                        onNewInvestigation()
                    }
                ) {
                    Text(strings.startFreshConfirm, color = CrimsonBright)
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmOverwrite = false }) {
                    Text(strings.cancel, color = FogGray)
                }
            }
        )
    }
}

@Composable
private fun LanguagePillBar(
    currentLanguage: AppLanguage,
    onSelectLanguage: (AppLanguage) -> Unit
) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = NoirCharcoal.copy(alpha = 0.9f),
        border = BorderStroke(1.dp, NoirBorder)
    ) {
        Row(
            modifier = Modifier.padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AppLanguage.entries.forEach { lang ->
                val selected = lang == currentLanguage
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (selected) CrimsonSoft else NoirSlate.copy(alpha = 0.5f),
                    border = BorderStroke(1.dp, if (selected) CrimsonBright else NoirBorder.copy(alpha = 0.4f)),
                    modifier = Modifier
                        .clickable { onSelectLanguage(lang) }
                        .testTag("lang_pill_${lang.code}")
                ) {
                    Text(
                        text = lang.nativeLabel,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (selected) ParchmentWhite else FogGray,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun MainMenuHeader(strings: UiStrings) {
    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Surface(
                shape = CircleShape,
                border = BorderStroke(1.5.dp, CrimsonMuted),
                color = NoirBlack,
                modifier = Modifier.size(52.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.ic_mindhunter_symbol),
                    contentDescription = "Mind Hunter emblem",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(CircleShape)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            ForensicBadge(
                text = strings.divisionBadge,
                color = BrassGold
            )
        }

        Spacer(modifier = Modifier.height(18.dp))

        Text(
            text = strings.appTitle,
            style = MaterialTheme.typography.displayLarge.copy(
                fontSize = 40.sp,
                letterSpacing = 2.5.sp
            ),
            color = ParchmentWhite
        )

        Box(
            modifier = Modifier
                .padding(vertical = 10.dp)
                .width(72.dp)
                .height(2.dp)
                .background(CrimsonBright)
        )

        Text(
            text = strings.menuTagline,
            style = MaterialTheme.typography.bodyLarge,
            color = FogGray
        )
    }
}

@Composable
private fun MainMenuActions(
    progress: InvestigationProgress,
    strings: UiStrings,
    caseData: LocalizedCaseData,
    onNewInvestigationClick: () -> Unit,
    onContinueInvestigation: () -> Unit,
    onNavigate: (GameScreen) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        if (progress.hasActiveInvestigation) {
            NoirCard(borderColor = BrassGold.copy(alpha = 0.5f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${caseData.caseCode} · ${caseData.caseTitle}",
                            style = MaterialTheme.typography.labelMedium,
                            color = BrassGold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${progress.collectedClues.size}/8 ${strings.cluesLabel} · ${progress.discoveredConnections.size}/5 ${strings.linksLabel} · ${progress.detectedContradictions.size} ${strings.liesExposedLabel}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = ParchmentWhite
                        )
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
                NoirPrimaryButton(
                    text = if (progress.achievedEndingId != null) strings.reviewFinalVerdict else strings.continueInvestigation,
                    onClick = onContinueInvestigation,
                    icon = Icons.Filled.PlayArrow,
                    modifier = Modifier.fillMaxWidth(),
                    testTag = "continue_investigation_button"
                )
            }
        }

        if (progress.hasActiveInvestigation) {
            NoirSecondaryButton(
                text = strings.newInvestigation,
                onClick = onNewInvestigationClick,
                icon = Icons.Filled.Refresh,
                modifier = Modifier.fillMaxWidth(),
                testTag = "new_investigation_button"
            )
        } else {
            NoirPrimaryButton(
                text = strings.newInvestigation,
                onClick = onNewInvestigationClick,
                icon = Icons.Filled.PlayArrow,
                modifier = Modifier.fillMaxWidth(),
                testTag = "new_investigation_button"
            )
        }

        NoirSecondaryButton(
            text = strings.caseFiles,
            onClick = { onNavigate(GameScreen.CASE_FILES) },
            icon = Icons.Filled.FolderOpen,
            modifier = Modifier.fillMaxWidth(),
            testTag = "case_files_button"
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            NoirSecondaryButton(
                text = strings.settings,
                onClick = { onNavigate(GameScreen.SETTINGS) },
                icon = Icons.Filled.Settings,
                modifier = Modifier.weight(1f),
                testTag = "settings_button"
            )
            NoirSecondaryButton(
                text = strings.credits,
                onClick = { onNavigate(GameScreen.CREDITS) },
                icon = Icons.Filled.Info,
                modifier = Modifier.weight(1f),
                testTag = "credits_button"
            )
        }
    }
}
