package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val MindHunterDarkColorScheme = darkColorScheme(
    primary = CrimsonBright,
    onPrimary = ParchmentWhite,
    primaryContainer = CrimsonSoft,
    onPrimaryContainer = ParchmentWhite,
    secondary = BrassGold,
    onSecondary = NoirBlack,
    secondaryContainer = BrassSoft,
    onSecondaryContainer = BrassGold,
    tertiary = VerifiedTeal,
    onTertiary = NoirBlack,
    tertiaryContainer = VerifiedTealSoft,
    onTertiaryContainer = VerifiedTeal,
    background = NoirBlack,
    onBackground = ParchmentWhite,
    surface = NoirCharcoal,
    onSurface = ParchmentWhite,
    surfaceVariant = NoirSlate,
    onSurfaceVariant = FogGray,
    outline = NoirBorder,
    outlineVariant = DimGray,
    error = CrimsonBright,
    onError = ParchmentWhite
)

private val MindHunterShapes = Shapes(
    small = RoundedCornerShape(6.dp),
    medium = RoundedCornerShape(10.dp),
    large = RoundedCornerShape(14.dp),
    extraLarge = RoundedCornerShape(18.dp)
)

@Composable
fun MindHunterTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = MindHunterDarkColorScheme,
        typography = MindHunterTypography,
        shapes = MindHunterShapes,
        content = content
    )
}
