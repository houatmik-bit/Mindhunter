package com.example.data

import com.example.model.AppLanguage
import com.example.model.Clue
import com.example.model.ClueConnection
import com.example.model.CrimeZone
import com.example.model.DialogueNode
import com.example.model.EndingResult
import com.example.model.ForensicManualEntry
import com.example.model.MethodTheory
import com.example.model.SuspectId
import com.example.model.SuspectProfile

data class LocalizedCaseData(
    val caseCode: String,
    val caseTitle: String,
    val victimName: String,
    val victimDetails: String,
    val manorLocationBadge: String,
    val briefingParagraphs: List<String>,
    val crimeZones: List<CrimeZone>,
    val clues: List<Clue>,
    val clueConnections: List<ClueConnection>,
    val suspects: List<SuspectProfile>,
    val methodTheories: List<MethodTheory>,
    val dialogueNodes: Map<String, DialogueNode>,
    val fullSolutionSteps: List<String>,
    val forensicManual: List<ForensicManualEntry>,
    val endingDescriptions: List<Pair<String, String>>,
    val noLinkReasoning: (String, String) -> String,
    val evaluateEnding: (
        accusedSuspect: SuspectId,
        selectedEvidenceIds: List<String>,
        selectedMethodId: String,
        discoveredConnections: Set<String>,
        recordedDecisions: List<String>
    ) -> EndingResult
)

object LocalGameData {

    fun getCase(language: AppLanguage): LocalizedCaseData = when (language) {
        AppLanguage.ENGLISH -> englishCaseData
        AppLanguage.FRENCH -> CaseDataFrench.data
        AppLanguage.ARABIC -> CaseDataArabic.data
    }

    private val englishCaseData: LocalizedCaseData by lazy {
        LocalizedCaseData(
            caseCode = Case01SilentRoom.CASE_CODE,
            caseTitle = Case01SilentRoom.CASE_TITLE,
            victimName = Case01SilentRoom.VICTIM_NAME,
            victimDetails = Case01SilentRoom.VICTIM_DETAILS,
            manorLocationBadge = "BLACKWOOD MANOR · 11:45 PM",
            briefingParagraphs = Case01SilentRoom.BRIEFING_PARAGRAPHS,
            crimeZones = Case01SilentRoom.CRIME_ZONES,
            clues = Case01SilentRoom.CLUES,
            clueConnections = Case01SilentRoom.CLUE_CONNECTIONS,
            suspects = Case01SilentRoom.SUSPECTS,
            methodTheories = Case01SilentRoom.METHOD_THEORIES,
            dialogueNodes = SuspectId.entries.flatMap { suspectId ->
                collectNodesForSuspect(suspectId)
            }.associateBy { it.id },
            fullSolutionSteps = Case01SilentRoom.FULL_SOLUTION_STEPS,
            forensicManual = listOf(
                ForensicManualEntry(
                    id = "fm_cyanide",
                    code = "TOX-04",
                    title = "Potassium Cyanide Kinetics",
                    summary = "Rapid cellular asphyxiant. Leaves faint bitter-almond volatility in warm dark liquids and takes effect within 60–120 seconds."
                ),
                ForensicManualEntry(
                    id = "fm_threshold",
                    code = "PHY-11",
                    title = "Threshold Displacement Illusion",
                    summary = "When a brass key is found far inside a locked room with parallel underside scratches, examine the door gap for stiff card push-tracks."
                ),
                ForensicManualEntry(
                    id = "fm_deception",
                    code = "PSY-07",
                    title = "Over-Precise Alibi Markers",
                    summary = "Deceptive suspects frequently over-specify exact timestamps and steer investigators toward physical impossibility ('locked from inside')."
                ),
                ForensicManualEntry(
                    id = "fm_logs",
                    code = "DIG-02",
                    title = "Executive Terminal Overrides",
                    summary = "Local motion sensor wipes always stamp the originating credential ID—separating guardhouse terminals from upstairs executive suites."
                )
            ),
            endingDescriptions = listOf(
                "ending_ironclad" to "Ending I: Ironclad Justice — True culprit, airtight proof, ethical profiling.",
                "ending_pyrrhic" to "Ending II: Pyrrhic Conviction — True culprit convicted via ruthless interrogation.",
                "ending_doubt" to "Ending III: Reasonable Doubt — True culprit named without decisive physical proof.",
                "ending_wrong_shadow" to "Ending IV: The Wrong Shadow — Framed by red herrings while the killer walks."
            ),
            noLinkReasoning = { c1, c2 ->
                "\"$c1\" and \"$c2\" belong to separate timelines or mechanisms. Look for shared timestamps, Suite B routing, or matching physical mechanisms."
            },
            evaluateEnding = { accused, evidence, method, connections, decisions ->
                Case01SilentRoom.evaluateAccusation(
                    accusedSuspect = accused,
                    selectedEvidenceIds = evidence,
                    selectedMethodId = method,
                    discoveredConnections = connections,
                    recordedDecisions = decisions
                )
            }
        )
    }

    private fun collectNodesForSuspect(suspectId: SuspectId): List<DialogueNode> {
        val startId = Case01SilentRoom.getInitialNodeId(suspectId)
        val visited = mutableSetOf<String>()
        val result = mutableListOf<DialogueNode>()
        val queue = ArrayDeque<String>()
        queue.add(startId)
        while (queue.isNotEmpty()) {
            val id = queue.removeFirst()
            if (!visited.add(id)) continue
            val node = Case01SilentRoom.getNode(id) ?: continue
            result.add(node)
            node.options.forEach { queue.add(it.nextNodeId) }
        }
        return result
    }
}
