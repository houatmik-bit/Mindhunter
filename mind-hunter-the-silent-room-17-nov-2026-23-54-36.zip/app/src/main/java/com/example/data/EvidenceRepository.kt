package com.example.data

import com.example.model.ClueCategory
import com.example.model.EvidenceItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class EvidenceRepository {

    private val _evidenceItems = MutableStateFlow<List<EvidenceItem>>(emptyList())
    val evidenceItems: StateFlow<List<EvidenceItem>> = _evidenceItems.asStateFlow()

    private val collectedTimestamps = mutableMapOf<String, Long>()
    private val examinedIds = mutableSetOf<String>()

    fun syncFromProgress(
        collectedClueIds: Set<String>,
        discoveredConnections: Set<String>,
        caseData: LocalizedCaseData
    ) {
        val now = System.currentTimeMillis()
        val items = caseData.clues
            .filter { it.id in collectedClueIds }
            .map { clue ->
                val ts = collectedTimestamps.getOrPut(clue.id) { now }
                val linkedConns = caseData.clueConnections
                    .filter { it.id in discoveredConnections && (it.clueAId == clue.id || it.clueBId == clue.id) }
                    .map { it.id }
                EvidenceItem(
                    id = clue.id,
                    title = clue.title,
                    category = clue.category,
                    zoneId = clue.zoneId,
                    summary = clue.summary,
                    forensicDetail = clue.forensicDetail,
                    timestampHint = clue.timestampHint,
                    collectedAtMillis = ts,
                    isExamined = clue.id in examinedIds,
                    linkedConnectionIds = linkedConns
                )
            }
        _evidenceItems.value = items
    }

    fun addEvidence(
        clueId: String,
        caseData: LocalizedCaseData,
        discoveredConnections: Set<String>
    ): EvidenceItem? {
        val clue = caseData.clues.firstOrNull { it.id == clueId } ?: return null
        val timestamp = collectedTimestamps.getOrPut(clueId) { System.currentTimeMillis() }
        val linkedConns = caseData.clueConnections
            .filter { it.id in discoveredConnections && (it.clueAId == clue.id || it.clueBId == clue.id) }
            .map { it.id }

        val newItem = EvidenceItem(
            id = clue.id,
            title = clue.title,
            category = clue.category,
            zoneId = clue.zoneId,
            summary = clue.summary,
            forensicDetail = clue.forensicDetail,
            timestampHint = clue.timestampHint,
            collectedAtMillis = timestamp,
            isExamined = clue.id in examinedIds,
            linkedConnectionIds = linkedConns
        )

        _evidenceItems.update { existing ->
            if (existing.any { it.id == clueId }) {
                existing.map { if (it.id == clueId) newItem else it }
            } else {
                existing + newItem
            }
        }
        return newItem
    }

    fun addEvidenceBatch(
        clueIds: Collection<String>,
        caseData: LocalizedCaseData,
        discoveredConnections: Set<String>
    ): List<EvidenceItem> {
        return clueIds.mapNotNull { addEvidence(it, caseData, discoveredConnections) }
    }

    fun listEvidence(categoryFilter: ClueCategory? = null): List<EvidenceItem> {
        val all = _evidenceItems.value
        return if (categoryFilter == null) all else all.filter { it.category == categoryFilter }
    }

    fun getEvidenceById(clueId: String): EvidenceItem? {
        return _evidenceItems.value.firstOrNull { it.id == clueId }
    }

    fun markEvidenceExamined(clueId: String) {
        examinedIds.add(clueId)
        _evidenceItems.update { list ->
            list.map { if (it.id == clueId) it.copy(isExamined = true) else it }
        }
    }

    fun clear() {
        collectedTimestamps.clear()
        examinedIds.clear()
        _evidenceItems.value = emptyList()
    }
}
