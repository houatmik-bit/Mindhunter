package com.example.data

import com.example.R
import com.example.model.Clue
import com.example.model.ClueCategory
import com.example.model.ClueConnection
import com.example.model.CrimeZone
import com.example.model.DialogueNode
import com.example.model.DialogueOption
import com.example.model.EndingResult
import com.example.model.ForensicManualEntry
import com.example.model.MethodTheory
import com.example.model.SuspectId
import com.example.model.SuspectProfile

object CaseDataArabic {
    val data: LocalizedCaseData by lazy {
        LocalizedCaseData(
            caseCode = "القضية #MH-01",
            caseTitle = "الغرفة الصامتة",
            victimName = "آرثر ثورن",
            victimDetails = "58 عاماً · مؤسس شركة ثورن للتقنية الحيوية · عُثر عليه ميتاً الساعة 11:45 مساءً داخل مكتبه الماهوغاني المغلق.",
            manorLocationBadge = "قصر بلاكوود · 11:45 م",
            briefingParagraphs = listOf(
                "يضرب المطر زجاج قصر بلاكوود المعشق. عند الساعة 11:45 مساءً، يكسر رئيس الأمن ماركوس ستيرلنغ باب المكتب البلوطي بعد توقف آرثر ثورن عن الرد على الاتصال الداخلي.",
                "في الداخل، يجلس ثورن منكفئاً على مكتبه — بلا طلق ناري، بلا عراك، وبلا نافذة مكسورة. والأغرب من ذلك: المفتاح النحاسي الوحيد ملقى على السجادة داخل الغرفة.",
                "أربعة أشخاص فقط لا يزالون داخل القصر المغلق الليلة. لكل منهم دافع لإسكات آرثر ثورن قبل الفجر، لكن شخصاً واحداً فقط هندس وهم الغرفة المغلقة."
            ),
            crimeZones = listOf(
                CrimeZone(
                    id = "zone_desk",
                    name = "المكتب الماهوغاني وطقم الإسبريسو",
                    locationLabel = "وسط المكتب · محيط الضحية",
                    hotspotXFraction = 0.48f,
                    hotspotYFraction = 0.58f,
                    initialDescription = "كأس كريستالي مقلوب بجانب فنجان إسبريسو خزفي نصف فارغ. وتحت النشاف الجلدي يبرز طرف إيصال مخبري مطوي.",
                    carefulActionLabel = "فحص حافة الفنجان وتفتيش النشاف",
                    quickActionLabel = "تحريز الفنجان ومسح السطح سريعاً",
                    carefulOutcome = "تلتقط رائحة لوز مر خفيفة من بقايا الإسبريسو وتسحب إذن طلب مواد مخبرية مزوراً مخفياً تحت النشاف الجلدي.",
                    quickOutcome = "تقوم بتحريز فنجان الإسبريسو مع ملاحظة بقايا مريبة، وتلمح طرف الوثيقة المخفية أسفل النشاف.",
                    clueIds = listOf("clue_toxic_espresso", "clue_lab_requisition"),
                    decisionId = "dec_desk_forensics",
                    carefulDecisionTag = "فحص سمّي دقيق للمكتب",
                    quickDecisionTag = "مسح سطحي متسرع"
                ),
                CrimeZone(
                    id = "zone_door",
                    name = "الباب البلوطي والعتبة النحاسية",
                    locationLabel = "المخرج الشرقي · نقطة الإغلاق",
                    hotspotXFraction = 0.78f,
                    hotspotYFraction = 0.45f,
                    initialDescription = "الباب البلوطي سليم باستثناء الكسر الذي أحدثه ماركوس عند القفل. المفتاح النحاسي يستقر على بعد 40 سم داخل الغرفة — بعيداً بشكل مريب عن كرسي الضحية.",
                    carefulActionLabel = "قياس فراغ أسفل الباب ومسارات الغبار",
                    quickActionLabel = "تصوير موضع المفتاح",
                    carefulOutcome = "تحت الضوء المائل، يكشف الفراغ البالغ 1.5 سم أسفل الباب عن مسار غبار ممسوح للداخل وخدوش متوازية جديدة أسفل المفتاح النحاسي.",
                    quickOutcome = "توثق موقع المفتاح على بعد 40 سم من العتبة وتلاحظ آثار انزلاق خفيفة في الغبار أسفل الباب.",
                    clueIds = listOf("clue_door_threshold"),
                    decisionId = "dec_door_measure",
                    carefulDecisionTag = "قياس دقيق لفراغ العتبة",
                    quickDecisionTag = "توثيق تقليدي للمفتاح"
                ),
                CrimeZone(
                    id = "zone_safe",
                    name = "الخزنة الجدارية ومكتبة الجوز",
                    locationLabel = "الجدار الغربي · الخزنة المالية",
                    hotspotXFraction = 0.22f,
                    hotspotYFraction = 0.50f,
                    initialDescription = "الخزنة المخفية مواربة بمقدار نصف بوصة، وقرصها ممسوح بعجلة. وميض معدني يلمع أسفل حافة المكتبة السفلية.",
                    carefulActionLabel = "فحص بصمات الخزنة واستخراج الجسم",
                    quickActionLabel = "مراجعة دفتر التدقيق المفتوح",
                    carefulOutcome = "تستخرج زر كم فضي منقوش عليه «V.V.» عالقاً تحت الرف، وتصوّر دفتر تدقيق منقحاً يحدد جلسة طرد عند الثامنة صباحاً.",
                    quickOutcome = "تستخرج دفتر التدقيق من الخزنة وتلتقط زر كم فضياً يحمل الأحرف «V.V.» بالقرب منه.",
                    clueIds = listOf("clue_cufflink", "clue_audit_ledger"),
                    decisionId = "dec_safe_audit",
                    carefulDecisionTag = "جرد جنائي كامل للخزنة",
                    quickDecisionTag = "مراجعة سريعة للأرقام"
                ),
                CrimeZone(
                    id = "zone_corridor",
                    name = "تجويف الممر ومحطة الأمن",
                    locationLabel = "الجناح الخارجي · سجل الوصول",
                    hotspotXFraction = 0.62f,
                    hotspotYFraction = 0.28f,
                    initialDescription = "تتحكم محطة في الممر بحساسات الحركة خارج المكتب. وبجوارها منفضة نحاسية وتجويف خدمي خلف ستائر مخملية ثقيلة.",
                    carefulActionLabel = "تدقيق سجلات المحطة وتفتيش التجويف",
                    quickActionLabel = "سحب ملخص حساسات الحركة",
                    carefulOutcome = "تكشف ثلاثة شواذ: مسح يدوي للفترة 11:08–11:15 م عبر الاعتماد التنفيذي، وورق محترق برائحة الياسمين، وقارورة حارس مثلومة.",
                    quickOutcome = "تسحب السجل الذي يظهر فجوة محذوفة بين 11:08 و11:15 م، مع أوراق محترقة وقارورة متروكة في التجويف.",
                    clueIds = listOf("clue_security_log", "clue_shredded_note", "clue_guard_flask"),
                    decisionId = "dec_corridor_audit",
                    carefulDecisionTag = "تدقيق شامل لبيانات الجناح",
                    quickDecisionTag = "سحب جزئي للسجلات"
                )
            ),
            clues = listOf(
                Clue(
                    id = "clue_toxic_espresso",
                    title = "فنجان إسبريسو مسموم",
                    category = ClueCategory.FORENSIC,
                    zoneId = "zone_desk",
                    summary = "فنجان خزفي نصف فارغ على مكتب آرثر تفوح منه رائحة لوز مر وبقايا بلورية على الحافة.",
                    forensicDetail = "الفحص الكيميائي يؤكد وجود سيانيد البوتاسيوم سريع المفعول مذاباً في القهوة. وقع الابتلاع بين 11:05 و11:15 مساءً.",
                    timestampHint = "الابتلاع المقدر: 11:05–11:15 م"
                ),
                Clue(
                    id = "clue_lab_requisition",
                    title = "إذن مخبري مزور",
                    category = ClueCategory.DOCUMENT,
                    zoneId = "zone_desk",
                    summary = "طلب مواد لسيانيد البوتاسيوم 99% موقّع الساعة 4:15 عصراً وموجّه إلى الجناح التنفيذي B.",
                    forensicDetail = "موقّع بختم آرثر الرقمي أثناء وجوده في لندن. يوجّه الشحنة — مع بطاقة توصيل بلاستيكية صلبة — إلى الجناح B (مقر أدريان).",
                    timestampHint = "التسليم: 4:15 م · الجناح B"
                ),
                Clue(
                    id = "clue_door_threshold",
                    title = "مفتاح مخدوش وأثر غبار",
                    category = ClueCategory.PHYSICAL,
                    zoneId = "zone_door",
                    summary = "المفتاح النحاسي عُثر عليه على بعد 40 سم داخل الغرفة بخدوش متوازية؛ والغبار تحت فتحة 1.5 سم ممسوح للداخل.",
                    forensicDetail = "أُقفل الباب من الخارج، ثم دُفع المفتاح المسطح عبر الفراغ السفلي البالغ 1.5 سم باستخدام بطاقة بلاستيكية صلبة.",
                    timestampHint = "القفل: مُرتّب ومزوّر"
                ),
                Clue(
                    id = "clue_cufflink",
                    title = "زر كم فضي («V.V.»)",
                    category = ClueCategory.PHYSICAL,
                    zoneId = "zone_safe",
                    summary = "زر فضي ثقيل منقوش عليه «V.V.» عالق أسفل المكتبة بجوار الخزنة مباشرة.",
                    forensicDetail = "يطابق الزر المفقود من كم فيكتور فانس الأيسر. آثار الاحتكاك على القرص تشير لمحاولة فتح فاشلة في وقت سابق.",
                    timestampHint = "عُثر عليه قرب الخزنة"
                ),
                Clue(
                    id = "clue_audit_ledger",
                    title = "دفتر التدقيق المنقح",
                    category = ClueCategory.DOCUMENT,
                    zoneId = "zone_safe",
                    summary = "ملف محاسبي يثبت اختلاس 14 مليون دولار عبر شركات وهمية بتوقيع فيكتور فانس.",
                    forensicDetail = "مذكرة مرفقة تدعو لاجتماع طارئ لمجلس الإدارة الساعة 8:00 صباحاً لعزل فيكتور وإبلاغ المدعي الفيدرالي.",
                    timestampHint = "اجتماع الطرد: 8:00 ص"
                ),
                Clue(
                    id = "clue_security_log",
                    title = "سجل حركة الممر الممسوح",
                    category = ClueCategory.DIGITAL,
                    zoneId = "zone_corridor",
                    summary = "تسجل الحساسات حركة عند 10:22 م و10:48 م، يليها مقطع ممسوح بين 11:08 و11:15 م.",
                    forensicDetail = "يثبت تدقيق النظام أن مسح 11:08–11:15 م لم يتم من غرفة الحراسة، بل من المحطة التنفيذية بالطابق العلوي عبر الاعتماد #02.",
                    timestampHint = "ممسوح: 11:08–11:15 م"
                ),
                Clue(
                    id = "clue_shredded_note",
                    title = "عقد محترق وعطر ياسمين",
                    category = ClueCategory.PHYSICAL,
                    zoneId = "zone_corridor",
                    summary = "قصاصة محترقة من تعديل حرمان من الميراث تفوح منها رائحة عطر الياسمين الفاخر.",
                    forensicDetail = "مؤرخة بصباح يوم الجريمة. الرماد في منفضة الممر يحمل العطر المميز لإيلينا ثورن.",
                    timestampHint = "منفضة الممر العلوي"
                ),
                Clue(
                    id = "clue_guard_flask",
                    title = "قارورة الحارس وإشعار الدين",
                    category = ClueCategory.PHYSICAL,
                    zoneId = "zone_corridor",
                    summary = "قارورة ويسكي تخص ماركوس ستيرلنغ وإنذار نهائي بدفع 40,000 دولار مخبآن في التجويف.",
                    forensicDetail = "القارورة شبه فارغة. كاميرات المدخل تُظهر ماركوس فاقداً للوعي في البهو الأرضي من 11:00 م إلى 11:28 م.",
                    timestampHint = "غياب الحارس: 11:00–11:28 م"
                )
            ),
            clueConnections = listOf(
                ClueConnection(
                    id = "conn_poison_source",
                    clueAId = "clue_toxic_espresso",
                    clueBId = "clue_lab_requisition",
                    title = "تخليق السيانيد الموجّه",
                    deductionSummary = "السيانيد الموجود في إسبريسو الساعة 11:05 يطابق طلبية الساعة 4:15 المزورة والموجهة مباشرة إلى الجناح B الخاص بأدريان.",
                    unlocksSuspectId = SuspectId.ADRIAN,
                    unlocksHint = "واجه أدريان بطلبية السيانيد المزورة للجناح B."
                ),
                ClueConnection(
                    id = "conn_locked_room_trick",
                    clueAId = "clue_door_threshold",
                    clueBId = "clue_lab_requisition",
                    title = "خدعة البطاقة المنزلقة",
                    deductionSummary = "البطاقة البلاستيكية الصلبة المرفقة بطرد الجناح B تفسر كيف أُدخل المفتاح النحاسي تحت فراغ الـ 1.5 سم بعد القفل من الخارج.",
                    unlocksSuspectId = SuspectId.ADRIAN,
                    unlocksHint = "اضغط على أدريان لتفسير وجود المفتاح على بعد 40 سم بالداخل."
                ),
                ClueConnection(
                    id = "conn_executive_wipe",
                    clueAId = "clue_door_threshold",
                    clueBId = "clue_security_log",
                    title = "نافذة الخروج المدبّرة (11:08–11:15 م)",
                    deductionSummary = "من رتب خدعة الباب المغلق هو نفسه من مسح سجل الممر بين 11:08 و11:15 م باستخدام الاعتماد التنفيذي #02.",
                    unlocksSuspectId = SuspectId.ADRIAN,
                    unlocksHint = "اسأل أدريان عن سبب استخدام الاعتماد #02 لمسح سجل 11:08 م."
                ),
                ClueConnection(
                    id = "conn_victor_theft",
                    clueAId = "clue_cufflink",
                    clueBId = "clue_audit_ledger",
                    title = "اقتحام فيكتور الساعة 10:22 م",
                    deductionSummary = "تسلل فيكتور للمكتب عند 10:22 م لإتلاف دفتر الـ 14 مليوناً — وفقد زر كمه قرب الخزنة — قبل ساعة كاملة من تقديم السم.",
                    unlocksSuspectId = SuspectId.VICTOR,
                    unlocksHint = "حطّم حجة غياب فيكتور باستخدام زر الكم ودفتر التدقيق."
                ),
                ClueConnection(
                    id = "conn_marcus_alibi",
                    clueAId = "clue_guard_flask",
                    clueBId = "clue_security_log",
                    title = "ممر بلا مراقبة وتضليل الحراسة",
                    deductionSummary = "كان ماركوس ثملاً وغائباً عن وعيه بين 11:00 و11:28 م — لكن مسح السجل نُفذ من الطابق العلوي وليس من غرفة الحراسة.",
                    unlocksSuspectId = SuspectId.MARCUS,
                    unlocksHint = "أجبر ماركوس على الاعتراف بغيابه عند 11:10 م، مما يبرئه من المسح العلوي."
                )
            ),
            suspects = listOf(
                SuspectProfile(
                    id = SuspectId.VICTOR,
                    fullName = "فيكتور فانس",
                    role = "الشريك الإداري",
                    age = 49,
                    portraitRes = R.drawable.img_suspect_victor,
                    personality = "متحكم، حاد اللسان، يخفي توتره خلف غطرسة رجال الأعمال.",
                    alibiSummary = "يدّعي بقاءه في غرفة الاستقبال السفلية لمراجعة تقارير الربع الرابع من 10:00 م حتى لحظة الإنذار.",
                    motive = "اكتشف آرثر اختلاسه 14 مليون دولار وحدد جلسة عزل وملاحقة قضائية الساعة 8:00 صباحاً.",
                    hiddenSecret = "تسلل للمكتب الساعة 10:22 م لسرقة دفتر التدقيق وفشل في فتح الخزنة وفقد زر كمه.",
                    backstory = "شارك في تأسيس الشركة قبل عشرين عاماً. بينما بنى آرثر براءات الاختراع، تلاعب فيكتور بالحسابات حتى استعان آرثر بمدققين خارجيين.",
                    baselineTell = "يعدل كمّه الأيسر لا إرادياً كلما ذُكرت الخزنة الجدارية.",
                    baseStress = 32
                ),
                SuspectProfile(
                    id = SuspectId.ELENA,
                    fullName = "إيلينا ثورن",
                    role = "زوجة الضحية",
                    age = 38,
                    portraitRes = R.drawable.img_suspect_elena,
                    personality = "هادئة كالبرسلان، حذرة، تتحدث بأنصاف حقائق محسوبة بدقة.",
                    alibiSummary = "تزعم أنها تناولت دواء الصداع النصفي وبقيت في الجناح الرئيسي منذ 9:30 مساءً.",
                    motive = "أعد آرثر تعديلاً لعقد الزواج يحرمها من الميراث بالكامل بعد كشف خطة هروبها.",
                    hiddenSecret = "تسللت للممر الساعة 10:48 م، أحرقت المسودة، ورأت شخصاً يحمل صينية فضية الساعة 11:04 م.",
                    backstory = "تزوجت آرثر قبل ست سنوات لإنقاذ أملاك عائلتها. محاصرة في قفص مراقب بالكاميرات، وأعدت جوازاً مزوراً للفرار إلى لشبونة.",
                    baselineTell = "تتوقف نصف ثانية قبل الإجابة عن التوقيت؛ وتلمس عقدها الفضي.",
                    baseStress = 26
                ),
                SuspectProfile(
                    id = SuspectId.ADRIAN,
                    fullName = "أدريان كول",
                    role = "المساعد الشخصي وأمين الأرشيف",
                    age = 29,
                    portraitRes = R.drawable.img_suspect_adrian,
                    personality = "هادئ الصوت، شديد الملاحظة، دقيق بشكل مفرط في التوقيت؛ برود مخيف تحت الضغط.",
                    alibiSummary = "يدّعي أنه أنهى مراسلات 10:30 م في الجناح B وخلد للنوم عند 10:55 م.",
                    motive = "دمّر آرثر والد أدريان في قضية براءة اختراع قبل خمس سنوات — واكتشف للتو تسريب أدريان لصيغ سرية.",
                    hiddenSecret = "طلب السيانيد بإذن مزور، دسّه في إسبريسو 11:05 م، مسح سجل 11:08 م، وأدخل المفتاح تحت الباب.",
                    backstory = "خريج كيمياء نابغ اشترت الشركة أطروحته ودفنتها. أمضى ثلاث سنوات يكسب ثقة آرثر المطلقة كسكرتير مقيم.",
                    baselineTell = "يفرط في شرح فيزياء الأقفال؛ يتجمد تنفسه عند ذكر الاعتماد #02.",
                    baseStress = 18
                ),
                SuspectProfile(
                    id = SuspectId.MARCUS,
                    fullName = "ماركوس ستيرلنغ",
                    role = "رئيس أمن القصر",
                    age = 54,
                    portraitRes = R.drawable.img_suspect_marcus,
                    personality = "فظ، دفاعي، بهيئة عسكرية؛ يغضب سريعاً عند التشكيك في كفاءته.",
                    alibiSummary = "يدّعي مراقبة الشاشات دون انقطاع قبل تحطيم باب المكتب الساعة 11:45 م.",
                    motive = "مدين بمبلغ 40,000 دولار لمقرضين؛ وقد رفض آرثر منحه سلفة طارئة قبل يومين.",
                    hiddenSecret = "ترك موقعه للشرب في البهو الأرضي وغاب عن الوعي من 11:00 م إلى 11:28 م، وزوّر سجل الدورية.",
                    backstory = "اثنان وعشرون عاماً في الأمن العسكري الخاص قبل عمله في بلاكوود. فخور بنفسه ويخشى فقدان معاشه التقاعدي.",
                    baselineTell = "يشد فكه ويشتت الانتباه كلما فُحصت الفترة 11:00–11:30 م.",
                    baseStress = 40
                )
            ),
            methodTheories = listOf(
                MethodTheory(
                    id = Case01SilentRoom.TRUE_METHOD_ID,
                    title = "إسبريسو بالسيانيد + دفع المفتاح تحت الباب",
                    description = "قدّم القاتل قهوة مسمومة الساعة 11:05 م، ومسح سجل الممر، وأقفل الباب من الخارج ثم دفع المفتاح للداخل تحت فراغ 1.5 سم."
                ),
                MethodTheory(
                    id = "method_safe_struggle",
                    title = "شجار عند الخزنة وإغلاق داخلي",
                    description = "أُجبر آرثر على تجرع السم أثناء شجار حول الخزنة وهرب القاتل عبر ممر شرفة غير مسجل."
                ),
                MethodTheory(
                    id = "method_guard_override",
                    title = "مفتاح الحرس العمومي ومسح من غرفة الأمن",
                    description = "استخدم الأمن نسخة مفتاح رئيسية ومسح تسجيل الممر من وحدة الحراسة."
                )
            ),
            dialogueNodes = arabicDialogueNodes.associateBy { it.id },
            fullSolutionSteps = listOf(
                "1. الدافع: قبل خمس سنوات حطّم آرثر ثورن عائلة أدريان كول في نزاع براءة اختراع، ومؤخراً اكتشف تسريب أدريان للصيغ وواجهه الساعة 10:00 م.",
                "2. الأداة: عند 4:15 عصراً، زوّر أدريان ختم آرثر الرقمي لطلب سيانيد بوتاسيوم 99% إلى الجناح B — مرفقاً ببطاقة توصيل بلاستيكية صلبة.",
                "3. التشتيت: عند 10:22 م تسلل فيكتور لسرقة دفتر الـ 14 مليوناً وفقد زره. عند 10:48 م أحرقت إيلينا التعديل في الممر. وعند 11:00 م غاب ماركوس عن الوعي ثملاً.",
                "4. الجريمة (11:05 م): قدّم أدريان لآرثر فنجان الإسبريسو الليلي الممزوج بالسيانيد، فانهار آرثر خلال تسعين ثانية.",
                "5. وهم الغرفة المغلقة (11:08–11:15 م): خرج أدريان، ومسح سجل الممر بالاعتماد #02، وأقفل الباب من الخارج ثم استخدم البطاقة الصلبة لدفع المفتاح 40 سم للداخل أسفل فراغ 1.5 سم."
            ),
            forensicManual = listOf(
                ForensicManualEntry(
                    id = "fm_cyanide",
                    code = "TOX-04",
                    title = "حركية سيانيد البوتاسيوم",
                    summary = "سم خلوي خاطف. يترك أثراً خفيفاً لرائحة اللوز المر في المشروبات الساخنة ويؤدي للوفاة خلال 60–120 ثانية."
                ),
                ForensicManualEntry(
                    id = "fm_threshold",
                    code = "PHY-11",
                    title = "وهم إزاحة العتبة",
                    summary = "العثور على مفتاح بعيداً داخل غرفة مغلقة مع خدوش متوازية أسفله يدل على دفعه من أسفل الباب ببطاقة صلبة."
                ),
                ForensicManualEntry(
                    id = "fm_deception",
                    code = "PSY-07",
                    title = "مؤشرات الحجة المفرطة الدقة",
                    summary = "يميل الجاني المراوغ إلى ترديد أوقات دقيقة جداً وتوجيه المحقق نحو «استحالة» اختراق الغرفة المغلقة."
                ),
                ForensicManualEntry(
                    id = "fm_logs",
                    code = "DIG-02",
                    title = "تواقيع تجاوز النظام",
                    summary = "توثق سجلات الحساسات رقم الطرفية المنفذة للحذف — مما يميز محطة الحراسة عن المحطات التنفيذية العلوية."
                )
            ),
            endingDescriptions = listOf(
                "ending_ironclad" to "النهاية الأولى: عدالة محكمة — الجاني الحقيقي، أدلة قاطعة، وتحقيق منضبط.",
                "ending_pyrrhic" to "النهاية الثانية: إدانة مكلفة — إدانة القاتل الحقيقي بأساليب قاسية.",
                "ending_doubt" to "النهاية الثالثة: شك معقول — تسمية الجاني الحقيقي دون إرفاق أدلة كافية.",
                "ending_wrong_shadow" to "النهاية الرابعة: الظل الخاطئ — الانخداع بالتضليل وهروب القاتل الحقيقي."
            ),
            noLinkReasoning = { c1, c2 ->
                "«$c1» و«$c2» ينتميان إلى خطين زمنيين أو آليتين مختلفتين. ابحث عن أوقات متقاطعة أو الجناح B أو آلية الباب."
            },
            evaluateEnding = { accused, evidence, method, connections, decisions ->
                evaluateArabic(accused, evidence, method, connections, decisions)
            }
        )
    }

    private fun evaluateArabic(
        accusedSuspect: SuspectId,
        selectedEvidenceIds: List<String>,
        selectedMethodId: String,
        discoveredConnections: Set<String>,
        recordedDecisions: List<String>
    ): EndingResult {
        val decisiveMatches = selectedEvidenceIds.count { it in Case01SilentRoom.DECISIVE_CLUES }
        val hasMethodCorrect = selectedMethodId == Case01SilentRoom.TRUE_METHOD_ID
        val hasStrongCase = decisiveMatches >= 2 && (hasMethodCorrect || discoveredConnections.size >= 2)
        val harshDecisions = recordedDecisions.count {
            it.contains("متسرع") || it.contains("هدّدت") || it.contains("Rushed") || it.contains("Threatened")
        }

        return when {
            accusedSuspect == Case01SilentRoom.TRUE_CULPRIT && hasStrongCase && harshDecisions == 0 -> EndingResult(
                id = "ending_ironclad",
                title = "عدالة محكمة",
                subtitle = "أُغلقت القضية · إدانة الجاني الحقيقي",
                verdictBadge = "محلل بارع",
                isSolvedCorrectly = true,
                profilerRating = "التصنيف S · دقة جنائية 100%",
                narrativeSummary = "بفضل تحليل السموم وفيزياء العتبة وسجل الاعتماد التنفيذي #02، فككت وهم الغرفة المغلقة الذي صنعه أدريان كول قطعةً قطعة. وبملف لا ثغرة فيه، يصدر المدعي العام أمراً بتوقيفه دون كفالة قبل الفجر."
            )
            accusedSuspect == Case01SilentRoom.TRUE_CULPRIT && hasStrongCase -> EndingResult(
                id = "ending_pyrrhic",
                title = "إدانة مكلفة",
                subtitle = "أُغلقت القضية · تحقيق قاسٍ",
                verdictBadge = "حل مع ندوب",
                isSolvedCorrectly = true,
                profilerRating = "التصنيف A · استنتاج صارم",
                narrativeSummary = "حددت القاتل الحقيقي أدريان كول مدعوماً بأدلة دامغة، لكن تسرعك أو ضغطك القاسي ترك الشهود محطمين. انتصرت العدالة الليلة، وإن دفع التحقيق ثمناً أخلاقياً ثقيلاً."
            )
            accusedSuspect == Case01SilentRoom.TRUE_CULPRIT -> EndingResult(
                id = "ending_doubt",
                title = "شك معقول",
                subtitle = "المشتبه الصحيح · أدلة غير كافية",
                verdictBadge = "خطر البراءة",
                isSolvedCorrectly = false,
                profilerRating = "التصنيف B · حدس بلا برهان",
                narrativeSummary = "أصاب حدسك الجاني الحقيقي أدريان كول — لكن دون إرفاق الأدلة الحاسمة (المفتاح المخدوش، طلبية الجناح B، أو سجل الاعتماد #02)، يمزق محاموه لائحة الاتهام ويخرج حراً تحت المطر."
            )
            else -> EndingResult(
                id = "ending_wrong_shadow",
                title = "الظل الخاطئ",
                subtitle = "توقيف خاطئ · فرار القاتل الحقيقي",
                verdictBadge = "قضية مخترقة",
                isSolvedCorrectly = false,
                profilerRating = "التصنيف C · تضليل بالمسارات الوهمية",
                narrativeSummary = "تُغلق الأصفاد على معصم ${accusedSuspect.displayName} بينما يغسل المطر ساحة القصر. ومن خلف الزجاج يراقب أدريان كول سقوط البريء بدلاً منه قبل أن يتوارى مع خيوط الصباح."
            )
        }
    }

    private val arabicDialogueNodes: List<DialogueNode> = listOf(
        // VICTOR
        DialogueNode(
            id = "victor_start",
            suspectId = SuspectId.VICTOR,
            speakerName = "فيكتور فانس",
            text = "لنختصر الأمر أيها المحقق. كان قلب آرثر عليلاً وأعداؤه كثراً، لكنني بقيت في القاعة السفلية أراجع هوامش الربع الرابع طوال المساء.",
            reactionTell = "يخفي معصمه الأيسر تحت الكم؛ وقفة متصلبة.",
            stressDelta = 0,
            psychologicalHint = "قدم ذريعة غيابه قبل أن تسأله. لاحظ تجنبه ذكر الطابق العلوي.",
            options = listOf(
                DialogueOption("v_opt_relation", "كيف كانت علاقتك بآرثر هذه الليلة؟", "victor_business"),
                DialogueOption("v_opt_pressure", "[ضغط] روايتك تبدو محفوظة بإتقان لشريك مفجوع.", "victor_pressured", isPsychologicalPressure = true, decisionTag = "ضغط مبكر على فيكتور"),
                DialogueOption("v_opt_cufflink", "[دليل] فسّر وجود زر كمّك «V.V.» تحت خزنته.", "victor_cufflink_break", requiredClueId = "clue_cufflink"),
                DialogueOption("v_opt_conn_theft", "[استنتاج] ربطنا زر كمّك بدفتر اختلاس الـ 14 مليوناً.", "victor_confesses_theft", requiredConnectionId = "conn_victor_theft")
            )
        ),
        DialogueNode(
            id = "victor_business",
            suspectId = SuspectId.VICTOR,
            speakerName = "فيكتور فانس",
            text = "الشركاء يختلفون أحياناً. كان آرثر مهووساً بالريبة — يستدعي مدققين ويغلق على نفسه في ذلك المكتب الخانق. لم أصعد للطابق العلوي بعد التاسعة.",
            reactionTell = "يبتلع ريقه بصعوبة؛ يختلس النظر نحو باب الممر.",
            stressDelta = 8,
            psychologicalHint = "النفي القاطع («لم أصعد بعد التاسعة») ينهار سريعاً أمام الدليل المادي.",
            options = listOf(
                DialogueOption("v_opt_b_cufflink", "[دليل] إذاً كيف وصل زر كمّك الفضي إلى جوار خزنته؟", "victor_cufflink_break", requiredClueId = "clue_cufflink"),
                DialogueOption("v_opt_b_audit", "[دليل] كانت هناك جلسة عند الثامنة صباحاً لملاحقتك بتهمة 14 مليوناً.", "victor_audit_dodge", requiredClueId = "clue_audit_ledger"),
                DialogueOption("v_opt_b_back", "لنعد إلى تسلسل وقتك منذ البداية.", "victor_start")
            )
        ),
        DialogueNode(
            id = "victor_pressured",
            suspectId = SuspectId.VICTOR,
            speakerName = "فيكتور فانس",
            text = "انتبه لكلامك أيها المحقق. عشرون عاماً من بناء الشركة لا تتبخر باستعراضاتك. قدّم دليلاً على صعودي أو دعني أتصل بمحاميّ.",
            reactionTell = "ينقبض فكه؛ عدوانية دفاعية تخفي ذعر الفضيحة المالية.",
            stressDelta = 16,
            psychologicalHint = "الغضب درع يخفي جريمة مالية، لا يعني بالضرورة أنه القاتل.",
            options = listOf(
                DialogueOption("v_opt_p_conn", "[استنتاج] زر الكم ودفتر التدقيق يثبتان اقتحامك للمكتب الساعة 10:22 م.", "victor_confesses_theft", requiredConnectionId = "conn_victor_theft"),
                DialogueOption("v_opt_p_back", "سنعود لروايتك لاحقاً.", "victor_start")
            )
        ),
        DialogueNode(
            id = "victor_audit_dodge",
            suspectId = SuspectId.VICTOR,
            speakerName = "فيكتور فانس",
            text = "تقع أخطاء محاسبية في الأبحاث! وحتى لو أراد طردي، قتله داخل غرفة مغلقة لن يمحو ملف تدقيق صار بيد جهات خارجية!",
            reactionTell = "يتصبب عرقاً عند صدغه، لكن منطقه حول التدقيق متماسك.",
            stressDelta = 18,
            psychologicalHint = "هو مرعوب من تهمة الاحتيال — لكنه محق: قتل آرثر لم يكن ليوقف المدققين.",
            options = listOf(
                DialogueOption("v_opt_ad_conn", "[استنتاج] ولهذا حاولت سرقة الدفتر بنفسك الساعة 10:22 م.", "victor_confesses_theft", requiredConnectionId = "conn_victor_theft"),
                DialogueOption("v_opt_ad_back", "العودة للاستجواب السابق.", "victor_start")
            )
        ),
        DialogueNode(
            id = "victor_cufflink_break",
            suspectId = SuspectId.VICTOR,
            speakerName = "فيكتور فانس",
            text = "مهلاً — هذا الزر؟ لقد... سقط مني عصراً! لا — ربما سقط عندما استدعاني ماركوس منتصف الليل؟ لا يمكنك إثبات متى سقط!",
            reactionTell = "يرتجف صوته؛ يختلق عذرين متناقضين في ثلاث ثوانٍ.",
            stressDelta = 24,
            contradictionFound = "كذب فيكتور بشأن عدم صعوده — فادّعى العصر ثم منتصف الليل.",
            psychologicalHint = "انكشف التناقض! اربط الزر بدفتر التدقيق على لوحة الأدلة لمحاصرته تماماً.",
            options = listOf(
                DialogueOption("v_opt_cb_conn", "[استنتاج] كفى كذباً. اقتحمت المكتب الساعة 10:22 م لحرق دفتر الـ 14 مليوناً.", "victor_confesses_theft", requiredConnectionId = "conn_victor_theft"),
                DialogueOption("v_opt_cb_back", "لنحتفظ بهذا التناقض لحظة.", "victor_start")
            )
        ),
        DialogueNode(
            id = "victor_confesses_theft",
            suspectId = SuspectId.VICTOR,
            speakerName = "فيكتور فانس",
            text = "تباً — حسناً! نعم، تسللت للمكتب الساعة 10:22 م! كان آرثر يتشاجر هاتفياً بالأسفل. فشلت في فتح الخزنة، انكسر زري وهربت قبل 10:35 م! كان آرثر حياً — ولم يكن هناك فنجان إسبريسو على مكتبه أصلاً!",
            reactionTell = "ينهار على الكرسي؛ ارتياح متوتر ممتزج بخوف الملاحقة المالية.",
            stressDelta = 30,
            contradictionFound = "يعترف فيكتور باقتحام 10:22 م — مؤكداً أن آرثر كان حياً وبلا قهوة عند 10:35 م.",
            psychologicalHint = "نقطة زمنية حاسمة: غادر فيكتور قبل إعداد الإسبريسو المسموم.",
            options = listOf(
                DialogueOption("v_opt_ct_deal", "هل رأيت أحداً قرب ممر المكتب أثناء مغادرتك؟", "victor_corridor_tip", decisionTag = "استثمار شهادة فيكتور"),
                DialogueOption("v_opt_ct_back", "ابقَ في مكانك يا فيكتور.", "victor_start")
            )
        ),
        DialogueNode(
            id = "victor_corridor_tip",
            suspectId = SuspectId.VICTOR,
            speakerName = "فيكتور فانس",
            text = "مجرد ظلال — انتظر. أثناء هبوطي سلم الخدمة قرابة 10:35 م سمعت طنين آلة الإسبريسو في المطبخ بالأسفل. كان أدريان يعد فنجان آرثر المعتاد عند الحادية عشرة.",
            reactionTell = "يزفر بارتجاف؛ استرجاع صادق غير متصنع.",
            stressDelta = -5,
            psychologicalHint = "يربط تحضير إسبريسو الحادية عشرة بأدريان.",
            options = listOf(
                DialogueOption("v_opt_tip_back", "العودة لملف فيكتور.", "victor_start")
            )
        ),

        // ELENA
        DialogueNode(
            id = "elena_start",
            suspectId = SuspectId.ELENA,
            speakerName = "إيلينا ثورن",
            text = "عاش آرثر بين الأرقام والأقفال أيها المحقق. تناولت حبوب الصداع عند التاسعة والنصف ولم أغادر جناحي إلا على الصراخ.",
            reactionTell = "يدان مطويتان بهدوء؛ عيناها تراقبان المطر خلف الزجاج.",
            stressDelta = 0,
            psychologicalHint = "هدوء مصطنع كالمسرح. ابحث عن أثر مادي تركته في الممر.",
            options = listOf(
                DialogueOption("e_opt_marriage", "هل كانت هناك خلافات بينكما هذا الأسبوع؟", "elena_marriage"),
                DialogueOption("e_opt_empathy", "[تعاطف] العيش تحت مراقبة دائمة يرهق أي إنسان. يمكنكِ الصدق معي.", "elena_softens", decisionTag = "التعاطف مع إيلينا"),
                DialogueOption("e_opt_note", "[دليل] وُجد تعديل عقد محترق برائحة عطر الياسمين في الممر.", "elena_note_confront", requiredClueId = "clue_shredded_note"),
                DialogueOption("e_opt_log", "[دليل] حساسات الممر رصدت حركة أمام المكتب الساعة 10:48 م.", "elena_log_confront", requiredClueId = "clue_security_log")
            )
        ),
        DialogueNode(
            id = "elena_marriage",
            suspectId = SuspectId.ELENA,
            speakerName = "إيلينا ثورن",
            text = "لم يقتنِ آرثر زوجة، بل أصلَاً مالياً. نعم، كان زواجنا جليدياً، لكن ذلك لا يجعلني ساذجة لأسممه داخل حصنه.",
            reactionTell = "ترفع ذقنها؛ رباطة جأش باردة.",
            stressDelta = 5,
            psychologicalHint = "تعترف بتعاسة زواجها بسهولة — غالباً لأنها تخفي فعلاً محدداً في الممر.",
            options = listOf(
                DialogueOption("e_opt_m_note", "[دليل] إذاً لماذا أحرقتِ ملحق الحرمان من الميراث خارج مكتبه؟", "elena_note_confront", requiredClueId = "clue_shredded_note"),
                DialogueOption("e_opt_m_back", "لنعد إلى تسلسل مسائكِ.", "elena_start")
            )
        ),
        DialogueNode(
            id = "elena_softens",
            suspectId = SuspectId.ELENA,
            speakerName = "إيلينا ثورن",
            text = "أنت أذكى من الشرطة المحلية... في الحقيقة لم أكن نائمة الساعة 10:45. كنت أجمع حقائبي للسفر إلى لشبونة فجراً، ولو رآني آرثر لاحتجزني.",
            reactionTell = "ترتخي كتفاها قليلاً؛ ينخفض صوتها لهمس.",
            stressDelta = 12,
            psychologicalHint = "اعترفت بوجودها في الممر — اسألها عمّن شاهدته قرابة الحادية عشرة.",
            options = listOf(
                DialogueOption("e_opt_s_witness", "هل رأيتِ أحداً يقترب من المكتب وأنتِ في الممر؟", "elena_witness_account"),
                DialogueOption("e_opt_s_back", "شكراً لصراحتكِ.", "elena_start")
            )
        ),
        DialogueNode(
            id = "elena_note_confront",
            suspectId = SuspectId.ELENA,
            speakerName = "إيلينا ثورن",
            text = "وجدتموه... حسناً. ذهبت إلى المكتب الساعة 10:48 م لأتوسل إليه ألا يتركني بلا شيء. وعندما صفق الباب في وجهي، أحرقت المسودة في منفضة الممر!",
            reactionTell = "تلمع عيناها بغضب مهان؛ أصابعها تشد على العقد.",
            stressDelta = 24,
            contradictionFound = "كذبت إيلينا بشأن بقائها في غرفتها — فقد واجهت آرثر عند 10:48 م.",
            psychologicalHint = "انهارت ذريعتها، لكن حرق ورقة لا يفسر سيانيد الساعة 11:05 م. اسألها عمن جاء بعدها.",
            options = listOf(
                DialogueOption("e_opt_nc_witness", "بما أنكِ بقيتِ في الممر، من صعد بعدكِ مباشرة؟", "elena_witness_account"),
                DialogueOption("e_opt_nc_back", "لنعد خطوة للوراء.", "elena_start")
            )
        ),
        DialogueNode(
            id = "elena_log_confront",
            suspectId = SuspectId.ELENA,
            speakerName = "إيلينا ثورن",
            text = "حساس 10:48؟ نعم، كنت أتسلل بمحاذاة الجدار بحقيبة السفر. لن أضيف حرفاً دون دليل ملموس.",
            reactionTell = "وقفة دفاعية تحاول تقليل شأن وجودها.",
            stressDelta = 16,
            contradictionFound = "تعترف إيلينا بتفعيل حساس الطابق العلوي الساعة 10:48 م.",
            psychologicalHint = "واجهها بالورق المحترق أو التعاطف لتروي ما حدث الساعة 11:04 م.",
            options = listOf(
                DialogueOption("e_opt_lc_note", "[دليل] لم تحملي حقيبة فقط — بل أحرقتِ تعديل العقد.", "elena_note_confront", requiredClueId = "clue_shredded_note"),
                DialogueOption("e_opt_lc_back", "سنواصل بعد لحظة.", "elena_start")
            )
        ),
        DialogueNode(
            id = "elena_witness_account",
            suspectId = SuspectId.ELENA,
            speakerName = "إيلينا ثورن",
            text = "الساعة 11:04 م اختبأت خلف الستارة المخملية. سمعت خطوات خفيفة لشخص يحمل فنجاناً خزفياً على صينية فضية. وبعد دقائق رنّت محطة الممر العلوية بصوت خافت، ثم سمعت كشطاً دقيقاً أسفل الباب البلوطي.",
            reactionTell = "استرجاع حسي دقيق بلا تصنّع.",
            stressDelta = -6,
            psychologicalHint = "شهادة حاسمة: صينية الساعة 11:04 م + رنين المحطة العلوية + كشط تحت الباب!",
            options = listOf(
                DialogueOption("e_opt_wa_back", "هذا التفصيل يغيّر كل شيء. ابقي قريبة يا إيلينا.", "elena_start")
            )
        ),

        // MARCUS
        DialogueNode(
            id = "marcus_start",
            suspectId = SuspectId.MARCUS,
            speakerName = "ماركوس ستيرلنغ",
            text = "أدرت أمن جنرالات أيها المحقق. راقبت الشاشات حتى غاب اتصال آرثر عند 11:30 م. وعندما حطمت الباب عند 11:45 م، كان المفتاح ملقى بالداخل والباب مقفلاً.",
            reactionTell = "وقفة عسكرية متصلبة؛ يتجنب الاقتراب.",
            stressDelta = 0,
            psychologicalHint = "مبالغة في الصرامة العسكرية. تحقق إن كان مستيقظاً فعلاً بين 11:00 و11:30 م.",
            options = listOf(
                DialogueOption("m_opt_door", "صف لي بدقة حالة الباب وموضع المفتاح.", "marcus_door_details"),
                DialogueOption("m_opt_flask", "[دليل] عثرنا على قارورتك وإشعار دين بـ 40,000 دولار في التجويف.", "marcus_flask_break", requiredClueId = "clue_guard_flask"),
                DialogueOption("m_opt_conn", "[استنتاج] غبتَ عن الوعي من 11:00 إلى 11:28 — لكن مسح 11:08 تم من الطابق العلوي.", "marcus_full_truth", requiredConnectionId = "conn_marcus_alibi")
            )
        ),
        DialogueNode(
            id = "marcus_door_details",
            suspectId = SuspectId.MARCUS,
            speakerName = "ماركوس ستيرلنغ",
            text = "المزلاج مغلق ولا مفتاح في الخارج، فحطمت الإطار — والمفتاح الوحيد على السجادة بالداخل! لا أحد يعبر باباً من البلوط الصلب.",
            reactionTell = "يهز رأسه بصدق — حائر فعلاً من لغز الغرفة.",
            stressDelta = 4,
            psychologicalHint = "حيرته تبدو حقيقية، فهو يجهل إمكانية دفع المفتاح تحت العتبة.",
            options = listOf(
                DialogueOption("m_opt_dd_flask", "[دليل] إذاً لماذا كنت تشرب في التجويف بدلاً من مراقبة الشاشات؟", "marcus_flask_break", requiredClueId = "clue_guard_flask"),
                DialogueOption("m_opt_dd_back", "العودة لجدول دوريتك.", "marcus_start")
            )
        ),
        DialogueNode(
            id = "marcus_flask_break",
            suspectId = SuspectId.MARCUS,
            speakerName = "ماركوس ستيرلنغ",
            text = "اخفض صوتك... هدّد المرابون شقة ابنتي ورفض آرثر إقراضي. تجرعت ثلاث رشفات في البهو عند الحادية عشرة وغبت عن الوعي حتى 11:28 م. زوّرت الدفتر لأحمي معاشي!",
            reactionTell = "ينهار التماسك العسكري؛ مفاصل أصابعه تبيضّ على ركبتيه.",
            stressDelta = 26,
            contradictionFound = "يعترف ماركوس بتزوير سجل الدورية — كان غائباً عن الوعي من 11:00 إلى 11:28 م.",
            psychologicalHint = "إن كان نائماً بالأسفل، فمن مسح السجل الساعة 11:08 م؟ اربط قارورته بسجل الحركة على اللوحة!",
            options = listOf(
                DialogueOption("m_opt_fb_conn", "[استنتاج] إذا كنتَ نائماً بالأسفل، فمن استخدم الاعتماد #02 في الأعلى؟", "marcus_full_truth", requiredConnectionId = "conn_marcus_alibi"),
                DialogueOption("m_opt_fb_back", "ابقَ هنا ريثما أراجع السجلات.", "marcus_start")
            )
        ),
        DialogueNode(
            id = "marcus_full_truth",
            suspectId = SuspectId.MARCUS,
            speakerName = "ماركوس ستيرلنغ",
            text = "الاعتماد التنفيذي #02؟! شخصان فقط يملكانه: آرثر نفسه وفتاه المدلل أدريان كول! رقم شارتي #04. من مسح سجل 11:08 م كان يقف أمام باب المكتب مباشرة!",
            reactionTell = "تتسع عيناه بإدراك غاضب.",
            stressDelta = -8,
            psychologicalHint = "اختراق حاسم: الاعتماد #02 يحصر المسح الرقمي في آرثر أو أدريان كول.",
            options = listOf(
                DialogueOption("m_opt_ft_deal", "[قرار] سلّمني سجلات دخول الجناح B وسأسجل تعاونك.", "marcus_suite_clue", decisionTag = "ضمان تعاون ماركوس"),
                DialogueOption("m_opt_ft_harsh", "[قرار] ما زلت تواجه تهمة التضليل. سلّم السجلات فوراً.", "marcus_suite_clue", isPsychologicalPressure = true, decisionTag = "هدّدت ماركوس بعرقلة العدالة")
            )
        ),
        DialogueNode(
            id = "marcus_suite_clue",
            suspectId = SuspectId.MARCUS,
            speakerName = "ماركوس ستيرلنغ",
            text = "الجناح B له صندوق تسليم مخبري خاص. والآن أتذكر: حين حطمت الباب كان المفتاح قريباً جداً من العتبة — وليس عند المكتب حيث اعتاد آرثر رميه.",
            reactionTell = "يؤدي تحية متصلبة — حريص على التكفير عن خطئه.",
            stressDelta = -4,
            psychologicalHint = "يعزز شذوذ العتبة: لم يسقط المفتاح من يد الضحية.",
            options = listOf(
                DialogueOption("m_opt_sc_back", "العودة لملف ماركوس.", "marcus_start")
            )
        ),

        // ADRIAN (CULPRIT)
        DialogueNode(
            id = "adrian_start",
            suspectId = SuspectId.ADRIAN,
            speakerName = "أدريان كول",
            text = "ما زلت أرتجف أيها المحقق. كان آرثر صارماً لكنه وثق بي تماماً. أنهيت بريد 10:30 م في الجناح B ونمت عند 10:55 م. الباب كان مقفلاً من الداخل — الأمر لا يُصدق.",
            reactionTell = "يدان ثابتتان، نبرة هادئة ودقيقة؛ يعدل نظارته مرة واحدة.",
            stressDelta = 0,
            psychologicalHint = "هدوء مبالغ فيه. لاحظ كيف يبادر فوراً بتثبيت فكرة «مقفل من الداخل».",
            options = listOf(
                DialogueOption("a_opt_routine", "ألم تكن تحضر له إسبريسو متأخراً قرابة الحادية عشرة عادةً؟", "adrian_espresso_lie"),
                DialogueOption("a_opt_thesis", "أخبرني عن أبحاثك في الكيمياء قبل انضمامك للشركة.", "adrian_past_probe", isPsychologicalPressure = true, decisionTag = "استجواب أدريان حول براءة الاختراع"),
                DialogueOption("a_opt_conn_poison", "[استنتاج] السيانيد في فنجان 11:05 يعود مباشرة لطلبية الجناح B.", "adrian_poison_corner", requiredConnectionId = "conn_poison_source"),
                DialogueOption("a_opt_conn_door", "[استنتاج] دفعتَ المفتاح تحت فراغ 1.5 سم ببطاقة صلبة.", "adrian_door_corner", requiredConnectionId = "conn_locked_room_trick"),
                DialogueOption("a_opt_conn_wipe", "[استنتاج] الاعتماد التنفيذي #02 مسح سجل الممر بين 11:08 و11:15 م.", "adrian_wipe_corner", requiredConnectionId = "conn_executive_wipe")
            )
        ),
        DialogueNode(
            id = "adrian_espresso_lie",
            suspectId = SuspectId.ADRIAN,
            speakerName = "أدريان كول",
            text = "عادةً نعم — الحادية عشرة تماماً. لكنه أبلغني عند 10:15 م ألا أزعجه الليلة. إن وُجد فنجان على مكتبه فلابد أنه أعدّه لنفسه مبكراً.",
            reactionTell = "يرمش مرتين سريعاً؛ كتفاه جامدتان على نحو غير طبيعي.",
            stressDelta = 10,
            psychologicalHint = "فيكتور أقسم بعدم وجود فنجان عند 10:30 م، وإيلينا سمعت صينية عند 11:04 م!",
            options = listOf(
                DialogueOption("a_opt_el_cup", "[دليل] الطب الشرعي يقدر إعداد وتسميم القهوة بين 11:05 و11:15 م.", "adrian_espresso_contradiction", requiredClueId = "clue_toxic_espresso"),
                DialogueOption("a_opt_el_back", "لنفحص زاوية أخرى.", "adrian_start")
            )
        ),
        DialogueNode(
            id = "adrian_espresso_contradiction",
            suspectId = SuspectId.ADRIAN,
            speakerName = "أدريان كول",
            text = "تقديرات الطب الشرعي تخطئ دائماً في التوقيت. وحتى لو شرب عند 11:05 م، الباب كان مقفلاً من الداخل — لم يكن بإمكان أحد الخروج بعد تقديمه.",
            reactionTell = "يخفي ابتسامة خفيفة؛ يتحصن خلف لغز الباب المغلق.",
            stressDelta = 15,
            contradictionFound = "يتهرب أدريان من توقيت 11:05 م بالاحتماء خلف الباب المغلق.",
            psychologicalHint = "اربط المفتاح المخدوش بالإذن المخبري والسجل على اللوحة لتحطيم درعه.",
            options = listOf(
                DialogueOption("a_opt_ec_conn", "[استنتاج] إلا أننا نعرف كيف عبر المفتاح الباب المغلق.", "adrian_door_corner", requiredConnectionId = "conn_locked_room_trick"),
                DialogueOption("a_opt_ec_back", "سنختبر فرضية الباب المغلق قريباً.", "adrian_start")
            )
        ),
        DialogueNode(
            id = "adrian_past_probe",
            suspectId = SuspectId.ADRIAN,
            speakerName = "أدريان كول",
            text = "نزاع أكاديمي قديم. سحق محامو آرثر مختبر والدي حين كنت في الرابعة والعشرين. لكنني صفحت — عملي هنا كان طريقي للمضي قدماً.",
            reactionTell = "يحبس أنفاسه ثانيتين ثم يزفر ببطء؛ اتساع طفيف في الحدقتين.",
            stressDelta = 18,
            psychologicalHint = "كبت عاطفي مخيف. لا أحد يخدم في منتصف الليل الرجل الذي أفلس والده دون غاية.",
            options = listOf(
                DialogueOption("a_opt_pp_poison", "[استنتاج] تمضي قدماً بطلب سيانيد 99% إلى الجناح B؟", "adrian_poison_corner", requiredConnectionId = "conn_poison_source"),
                DialogueOption("a_opt_pp_back", "ضبط نفس لافت يا أدريان.", "adrian_start")
            )
        ),
        DialogueNode(
            id = "adrian_poison_corner",
            suspectId = SuspectId.ADRIAN,
            speakerName = "أدريان كول",
            text = "تلك الطلبية تحمل ختم آرثر الرقمي نفسه! أي شخص استطاع توريطي — وحتى مع وجود مواد في الجناح B، كيف عبرت باباً بلوطياً موصداً؟",
            reactionTell = "يسقط القناع — نبرة حادة، تحليلية، شبه متعالية.",
            stressDelta = 26,
            contradictionFound = "ينكر أدريان طلب السيانيد ويلجأ مجدداً لدفاع الغرفة المغلقة.",
            psychologicalHint = "لقد اهتز أخيراً. اضربه الآن ببطاقة العتبة أو الاعتماد التنفيذي #02!",
            options = listOf(
                DialogueOption("a_opt_pc_door", "[استنتاج] بالبطاقة الصلبة التي تركت آثاراً تحت فراغ الـ 1.5 سم.", "adrian_door_corner", requiredConnectionId = "conn_locked_room_trick"),
                DialogueOption("a_opt_pc_wipe", "[استنتاج] بعد مسح سجل 11:08–11:15 م بالاعتماد التنفيذي #02.", "adrian_wipe_corner", requiredConnectionId = "conn_executive_wipe"),
                DialogueOption("a_opt_pc_back", "واصل الحديث يا أدريان.", "adrian_start")
            )
        ),
        DialogueNode(
            id = "adrian_door_corner",
            suspectId = SuspectId.ADRIAN,
            speakerName = "أدريان كول",
            text = "بطاقة... بلاستيكية؟ تحت العتبة؟ محض تخمين! الفراغ أسفل الباب لا يكاد يتجاوز — أقصد أنه بلوط غير مستوٍ! لا يمكنك إثبات مرور المفتاح ولا وجودي في الممر عند 11:10!",
            reactionTell = "ضباب خفيف على نظارته؛ يده تقبض على حافة الطاولة بقوة.",
            stressDelta = 32,
            contradictionFound = "ينهار أدريان توتراً عند كشف خدعة الـ 1.5 سم أسفل الباب.",
            psychologicalHint = "لقد جادل للتو في أبعاد الفراغ من ذاكرته! ضربة أخيرة بالاعتماد #02 ستسقطه.",
            options = listOf(
                DialogueOption("a_opt_dc_wipe", "[استنتاج] بلى نستطيع: الاعتماد #02 مسح 11:08–11:15 م من الممر نفسه.", "adrian_wipe_corner", requiredConnectionId = "conn_executive_wipe"),
                DialogueOption("a_opt_dc_back", "انتهت مبرراتك يا أدريان. حان وقت الاتهام النهائي.", "adrian_start")
            )
        ),
        DialogueNode(
            id = "adrian_wipe_corner",
            suspectId = SuspectId.ADRIAN,
            speakerName = "أدريان كول",
            text = "...لم يكن يفترض أن يراجع آرثر سجلات البراءات قبل الإثنين. حين استدعاني العاشرة مساءً ليحطمني كما حطّم والدي، أدركت أن أمامي ليلة واحدة فقط. السيانيد يعمل خلال تسعين ثانية، وثلاثون ثانية ببطاقة صلبة كانت كافية لتُغلق الغرفة على سرها.",
            reactionTell = "يسقط القناع البارد بالكامل؛ هدوء خاوٍ ومخيف.",
            stressDelta = 40,
            contradictionFound = "اعتراف كامل: يقر أدريان بالسيانيد والاعتماد #02 وخدعة دفع المفتاح.",
            psychologicalHint = "حُلّت القضية بالكامل. توجه إلى الاتهام النهائي وأرفق أدلتك الحاسمة!",
            options = listOf(
                DialogueOption("a_opt_wc_back", "اعترافك مسجل رسمياً. انتظر لائحة الاتهام.", "adrian_start")
            )
        )
    )
}
