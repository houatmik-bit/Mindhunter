package com.example.data

import com.example.R
import com.example.model.Clue
import com.example.model.ClueCategory
import com.example.model.ClueConnection
import com.example.model.CrimeZone
import com.example.model.DialogueNode
import com.example.model.DialogueOption
import com.example.model.EndingResult
import com.example.model.MethodTheory
import com.example.model.SuspectId
import com.example.model.SuspectProfile

object Case01SilentRoom {

    const val CASE_CODE = "CASE #MH-01"
    const val CASE_TITLE = "The Silent Room"
    const val VICTIM_NAME = "Arthur Thorne"
    const val VICTIM_DETAILS = "Age 58 · Founder of Thorne Bio-Dynamics · Found dead at 11:45 PM inside his second-floor mahogany study."

    val TRUE_CULPRIT = SuspectId.ADRIAN
    const val TRUE_METHOD_ID = "method_cyanide_key_slide"

    val DECISIVE_CLUES = setOf(
        "clue_toxic_espresso",
        "clue_door_threshold",
        "clue_security_log",
        "clue_lab_requisition"
    )

    val BRIEFING_PARAGRAPHS = listOf(
        "Rain lashes the leaded glass of Blackwood Manor. At 11:45 PM, head of security Marcus Sterling forces open the oak study door after Arthur Thorne stops answering the intercom.",
        "Inside, Thorne sits slumped over his blotter—no gunshot, no struggle, no forced window. Even stranger: the only heavy brass key to the mortise deadbolt lies on the Persian rug inside the room.",
        "Four people remain inside the locked estate tonight. Everyone had a reason to silence Arthur Thorne before dawn. Only one engineered the illusion of a locked room."
    )

    val CRIME_ZONES = listOf(
        CrimeZone(
            id = "zone_desk",
            name = "Mahogany Desk & Espresso Set",
            locationLabel = "Center Study · Victim Area",
            hotspotXFraction = 0.48f,
            hotspotYFraction = 0.58f,
            initialDescription = "A crystal tumbler lies tipped beside a half-finished silver-rimmed porcelain espresso cup. Underneath the leather blotter, an edge of folded lab stationery protrudes.",
            carefulActionLabel = "Swab Espresso Rim & Inspect Blotter",
            quickActionLabel = "Bag Cup & Scan Surface Briefly",
            carefulOutcome = "You note a faint bitter-almond odor from the espresso dregs and pull a falsified lab requisition slip hidden beneath the leather blotter.",
            quickOutcome = "You bag the espresso cup and notice unusual residue, though a hasty sweep overlooks the blotter slip—wait, your forensic light catches its corner just in time.",
            clueIds = listOf("clue_toxic_espresso", "clue_lab_requisition"),
            decisionId = "dec_desk_forensics",
            carefulDecisionTag = "Thorough Desk Toxicology",
            quickDecisionTag = "Rushed Surface Sweep"
        ),
        CrimeZone(
            id = "zone_door",
            name = "Oak Door & Brass Threshold",
            locationLabel = "East Exit · Locked Point",
            hotspotXFraction = 0.78f,
            hotspotYFraction = 0.45f,
            initialDescription = "The heavy oak door shows splintering only where Marcus forced the latch frame. The brass key rests 40 centimeters inside on the rug—oddly far from Thorne's chair.",
            carefulActionLabel = "Measure Door Gap & Dust Tracks",
            quickActionLabel = "Photograph Key Position",
            carefulOutcome = "Under UV angle, the 1.5 cm gap beneath the door reveals freshly swept dust tracks and fine parallel scratches along the flat belly of the brass key.",
            quickOutcome = "You log the brass key's position 40 cm inside the threshold, noticing faint drag marks in the hallway dust beneath the oak door.",
            clueIds = listOf("clue_door_threshold"),
            decisionId = "dec_door_measure",
            carefulDecisionTag = "Micro-Measured Threshold Gap",
            quickDecisionTag = "Standard Key Log"
        ),
        CrimeZone(
            id = "zone_safe",
            name = "Wall Safe & Walnut Bookshelf",
            locationLabel = "West Wall · Financial Vault",
            hotspotXFraction = 0.22f,
            hotspotYFraction = 0.50f,
            initialDescription = "The concealed wall safe stands ajar by half an inch, its brass dial smudged with a hasty sleeve wipe. Something metallic glints beneath the lower bookshelf trim.",
            carefulActionLabel = "Dust Safe Dial & Retrieve Object",
            quickActionLabel = "Inspect Open Ledger Tray",
            carefulOutcome = "You recover a monogrammed silver cufflink ('V.V.') wedged beneath the shelf and photograph a redacted audit ledger marked for an 8:00 AM board expulsion.",
            quickOutcome = "You extract the redacted audit ledger from the safe and spot a dropped silver cufflink bearing the initials 'V.V.' nearby.",
            clueIds = listOf("clue_cufflink", "clue_audit_ledger"),
            decisionId = "dec_safe_audit",
            carefulDecisionTag = "Cataloged Full Safe Forensics",
            quickDecisionTag = "Skimmed Audit Figures"
        ),
        CrimeZone(
            id = "zone_corridor",
            name = "Corridor Alcove & Security Terminal",
            locationLabel = "Outside Wing · Access Log",
            hotspotXFraction = 0.62f,
            hotspotYFraction = 0.28f,
            initialDescription = "An upstairs mahogany terminal governs motion sensors along the study wing. Nearby sit a brass ash tray and a service alcove behind heavy velvet curtains.",
            carefulActionLabel = "Audit Terminal Logs & Service Alcove",
            quickActionLabel = "Download Motion Log Summary",
            carefulOutcome = "You uncover three anomalies: a manually wiped 11:08–11:15 PM block executed via Executive Credential, charred prenup paper smelling of jasmine, and a dented guard flask.",
            quickOutcome = "You pull the motion log showing a deleted 11:08–11:15 PM block, alongside burned paper in the ash tray and an abandoned flask in the alcove.",
            clueIds = listOf("clue_security_log", "clue_shredded_note", "clue_guard_flask"),
            decisionId = "dec_corridor_audit",
            carefulDecisionTag = "Full Wing Telemetry Audit",
            quickDecisionTag = "Partial Log Pull"
        )
    )

    val CLUES = listOf(
        Clue(
            id = "clue_toxic_espresso",
            title = "Tainted Espresso Cup",
            category = ClueCategory.FORENSIC,
            zoneId = "zone_desk",
            summary = "Half-empty porcelain espresso cup on Arthur's desk with faint bitter-almond odor and crystalline rim residue.",
            forensicDetail = "Preliminary reagent test confirms fast-acting potassium cyanide dissolved in dark roast espresso. Given core body temperature, ingestion occurred between 11:05 PM and 11:15 PM.",
            timestampHint = "EST. INGESTION: 11:05–11:15 PM"
        ),
        Clue(
            id = "clue_lab_requisition",
            title = "Falsified Reagent Slip",
            category = ClueCategory.DOCUMENT,
            zoneId = "zone_desk",
            summary = "Bio-Dynamics requisition for 99% potassium cyanide signed at 4:15 PM, routed to Executive Suite B.",
            forensicDetail = "Signed with Arthur's digital stamp while Arthur was in London. Delivery manifest routes the sealed ampoule—along with a stiff laminated courier ID card—to Executive Suite B (Adrian's quarters).",
            timestampHint = "ROUTED: 4:15 PM · SUITE B"
        ),
        Clue(
            id = "clue_door_threshold",
            title = "Scratched Key & Dust Track",
            category = ClueCategory.PHYSICAL,
            zoneId = "zone_door",
            summary = "Brass study key found 40 cm inside the door with parallel scrape marks; dust under the 1.5 cm gap is swept inward.",
            forensicDetail = "The door was locked from the OUTSIDE, then the flat brass key was pushed beneath the 1.5 cm threshold gap using a stiff laminated card—explaining both the inward dust trail and horizontal scratches.",
            timestampHint = "LOCK MECHANISM: STAGED"
        ),
        Clue(
            id = "clue_cufflink",
            title = "Silver Cufflink ('V.V.')",
            category = ClueCategory.PHYSICAL,
            zoneId = "zone_safe",
            summary = "Heavy sterling cufflink engraved 'V.V.', wedged beneath the bookshelf directly beside the wall safe.",
            forensicDetail = "Matches Victor Vance's missing left sleeve fastener. Scuff marks on the safe dial indicate someone without the combination tried forcing it earlier in the evening.",
            timestampHint = "LOCATED NEAR SAFE"
        ),
        Clue(
            id = "clue_audit_ledger",
            title = "Redacted Audit Ledger",
            category = ClueCategory.DOCUMENT,
            zoneId = "zone_safe",
            summary = "Forensic accounting folder proving $14M siphoned to shell accounts under Victor Vance's authorization.",
            forensicDetail = "Attached memo schedules an emergency 8:00 AM board meeting to strip Victor of equity and refer the embezzlement to federal prosecutors.",
            timestampHint = "BOARD EXPULSION: 8:00 AM"
        ),
        Clue(
            id = "clue_security_log",
            title = "Wiped Corridor Motion Log",
            category = ClueCategory.DIGITAL,
            zoneId = "zone_corridor",
            summary = "Motion logs show 10:22 PM and 10:48 PM triggers, followed by an erased 11:08–11:15 PM block.",
            forensicDetail = "System audit proves the 11:08–11:15 PM erasure was NOT executed from Marcus's guardhouse console—it was deleted locally from the upstairs Executive Terminal using Master Credential #02.",
            timestampHint = "ERASED: 11:08–11:15 PM"
        ),
        Clue(
            id = "clue_shredded_note",
            title = "Charred Prenup & Jasmine",
            category = ClueCategory.PHYSICAL,
            zoneId = "zone_corridor",
            summary = "Burned fragment of a disinheritance amendment smelling of expensive jasmine perfume.",
            forensicDetail = "Dated the morning of the murder. The ash is still crisp inside the corridor sconce tray, matching Elena Thorne's signature fragrance.",
            timestampHint = "CORRIDOR ASH TRAY"
        ),
        Clue(
            id = "clue_guard_flask",
            title = "Dented Flask & Debt Notice",
            category = ClueCategory.PHYSICAL,
            zoneId = "zone_corridor",
            summary = "Marcus Sterling's whiskey flask and a final-demand $40,000 debt notice tucked inside the guard alcove.",
            forensicDetail = "Flask is three-quarters empty. Security camera timestamps show Marcus passed out in the ground-floor vestibule from 11:00 PM to 11:28 PM.",
            timestampHint = "GUARD ABSENT: 11:00–11:28 PM"
        )
    )

    val CLUE_CONNECTIONS = listOf(
        ClueConnection(
            id = "conn_poison_source",
            clueAId = "clue_toxic_espresso",
            clueBId = "clue_lab_requisition",
            title = "Targeted Cyanide Synthesis",
            deductionSummary = "The cyanide in Arthur's 11:05 PM espresso matches the falsified 4:15 PM reagent order routed directly to Adrian's quarters (Suite B).",
            unlocksSuspectId = SuspectId.ADRIAN,
            unlocksHint = "Confront Adrian with the falsified Suite B cyanide order."
        ),
        ClueConnection(
            id = "conn_locked_room_trick",
            clueAId = "clue_door_threshold",
            clueBId = "clue_lab_requisition",
            title = "The Card-Slide Illusion",
            deductionSummary = "The stiff laminated courier card from the Suite B delivery explains how the brass key was slid inward under the 1.5 cm door gap after locking the study from outside.",
            unlocksSuspectId = SuspectId.ADRIAN,
            unlocksHint = "Press Adrian on how the key ended up 40 cm inside the threshold."
        ),
        ClueConnection(
            id = "conn_executive_wipe",
            clueAId = "clue_door_threshold",
            clueBId = "clue_security_log",
            title = "Staged Exit Window (11:08–11:15 PM)",
            deductionSummary = "Whoever staged the locked door also erased the upstairs corridor motion log between 11:08 and 11:15 PM using Executive Credential #02.",
            unlocksSuspectId = SuspectId.ADRIAN,
            unlocksHint = "Ask Adrian why Executive Credential #02 wiped the 11:08 PM log."
        ),
        ClueConnection(
            id = "conn_victor_theft",
            clueAId = "clue_cufflink",
            clueBId = "clue_audit_ledger",
            title = "Victor's 10:22 PM Break-In",
            deductionSummary = "Victor entered the study earlier to destroy the $14M audit ledger—losing his cufflink near the safe—nearly an hour before the fatal poison was served.",
            unlocksSuspectId = SuspectId.VICTOR,
            unlocksHint = "Break Victor's downstairs alibi using the cufflink and audit ledger."
        ),
        ClueConnection(
            id = "conn_marcus_alibi",
            clueAId = "clue_guard_flask",
            clueBId = "clue_security_log",
            title = "Unwatched Corridor & False Blame",
            deductionSummary = "Marcus was intoxicated and absent from his post at 11:00–11:28 PM, leaving the wing unwatched—yet the log erasure came from upstairs, not his guardhouse.",
            unlocksSuspectId = SuspectId.MARCUS,
            unlocksHint = "Force Marcus to admit he slept through 11:10 PM—clearing him of the upstairs wipe."
        )
    )

    val SUSPECTS = listOf(
        SuspectProfile(
            id = SuspectId.VICTOR,
            fullName = "Victor Vance",
            role = "Managing Business Partner",
            age = 49,
            portraitRes = R.drawable.img_suspect_victor,
            personality = "Controlling, sharp-tongued, masks anxiety behind corporate condescension.",
            alibiSummary = "Claims he remained in the downstairs drawing room reviewing Q4 figures from 10:00 PM until Marcus raised the alarm.",
            motive = "Arthur uncovered $14M Victor embezzled into offshore shells and scheduled an 8:00 AM board vote to prosecute him.",
            hiddenSecret = "Broke into Arthur's study at 10:22 PM to steal the audit ledger, failed to crack the safe, and dropped his cufflink.",
            backstory = "Co-founded Thorne Bio-Dynamics twenty years ago. While Arthur built the patents, Victor financed his lifestyle through creative accounting—until Arthur hired external auditors.",
            baselineTell = "Adjusts left wrist cuff unconsciously whenever the study safe is mentioned.",
            baseStress = 32
        ),
        SuspectProfile(
            id = SuspectId.ELENA,
            fullName = "Elena Thorne",
            role = "The Victim's Wife",
            age = 38,
            portraitRes = R.drawable.img_suspect_elena,
            personality = "Porcelain-calm, poised, speaks in measured ambiguities; guards every emotion.",
            alibiSummary = "Claims she took migraine medication and stayed inside the master bedroom from 9:30 PM onward.",
            motive = "Arthur drafted a revised prenup amendment disinheriting her completely after discovering her secret departure plans.",
            hiddenSecret = "Sneaked to the study wing at 10:48 PM, burned the prenup fragment, and saw someone carrying a silver tray at 11:04 PM.",
            backstory = "Married Arthur six years ago to save her family's estate. Trapped in a gilded cage monitored by cameras, she prepared a forged passport to vanish to Lisbon.",
            baselineTell = "Pauses half a beat before answering timeline questions; fingers trace her collar.",
            baseStress = 26
        ),
        SuspectProfile(
            id = SuspectId.ADRIAN,
            fullName = "Adrian Cole",
            role = "Personal Assistant & Archivist",
            age = 29,
            portraitRes = R.drawable.img_suspect_adrian,
            personality = "Soft-spoken, hyper-observant, overly exact with timestamps; eerily calm under routine questioning.",
            alibiSummary = "Claims he prepared Arthur's 10:30 PM correspondence in Suite B and went straight to sleep by 10:55 PM.",
            motive = "Arthur ruined Adrian's father in a patent lawsuit five years ago—and just discovered Adrian leaking formulas to a rival lab.",
            hiddenSecret = "Synthesized cyanide via a forged requisition, laced Arthur's 11:05 PM espresso, wiped the 11:08 PM log, and slid the key under the door.",
            backstory = "A brilliant chemistry graduate whose thesis Thorne Bio-Dynamics buried in court. Adrian spent three years earning Arthur's absolute trust as live-in secretary.",
            baselineTell = "Over-explains locks and door physics; breathing flattens when Executive Credential #02 is referenced.",
            baseStress = 18
        ),
        SuspectProfile(
            id = SuspectId.MARCUS,
            fullName = "Marcus Sterling",
            role = "Head of Estate Security",
            age = 54,
            portraitRes = R.drawable.img_suspect_marcus,
            personality = "Gruff, defensive, military posture; quick to anger when his competence is questioned.",
            alibiSummary = "Claims he monitored security feeds continuously from the guardhouse before breaking down the study door at 11:45 PM.",
            motive = "Owes $40,000 to predatory creditors; Arthur denied his request for an emergency salary advance two days ago.",
            hiddenSecret = "Left his post to drink in the ground-floor vestibule and passed out from 11:00 PM to 11:28 PM, falsifying his patrol log.",
            backstory = "Twenty-two years in private military contracting before taking Blackwood Manor's security post. Proud to a fault, terrified of losing his final pension.",
            baselineTell = "Clenches jaw and deflects onto other suspects whenever 11:00–11:30 PM is scrutinized.",
            baseStress = 40
        )
    )

    val METHOD_THEORIES = listOf(
        MethodTheory(
            id = TRUE_METHOD_ID,
            title = "Cyanide Espresso + Key Slid Under Door",
            description = "The killer served poisoned espresso at 11:05 PM, wiped the upstairs motion log, locked the study from the outside, and slid the key back inside under the 1.5 cm threshold gap."
        ),
        MethodTheory(
            id = "method_safe_struggle",
            title = "Confrontation Over Safe & Internal Lock",
            description = "Arthur was coerced into swallowing poison during an argument over the wall safe, and the killer escaped through an unrecorded balcony passage."
        ),
        MethodTheory(
            id = "method_guard_override",
            title = "Guardhouse Master Key & Corrupted Feed",
            description = "Security killed Arthur using a duplicate master key and erased the camera corridor feed from the guardhouse console."
        )
    )

    // --- DIALOGUE NODES ---
    private val ALL_NODES: Map<String, DialogueNode> = listOf(
        // ================= VICTOR VANCE =================
        DialogueNode(
            id = "victor_start",
            suspectId = SuspectId.VICTOR,
            speakerName = "Victor Vance",
            text = "Let's make this brief, Detective. Arthur had a bad heart and worse enemies, but I was downstairs in the drawing room going over quarterly margins all evening.",
            reactionTell = "Left wrist stays tucked beneath his jacket cuff; posture rigid.",
            stressDelta = 0,
            psychologicalHint = "He volunteered his alibi before you even asked. Watch how he avoids mentioning the upstairs wing.",
            options = listOf(
                DialogueOption(
                    id = "v_opt_relation",
                    prompt = "How were things between you and Arthur tonight?",
                    nextNodeId = "victor_business"
                ),
                DialogueOption(
                    id = "v_opt_pressure",
                    prompt = "[Pressure] You seem awfully rehearsed for a grieving partner.",
                    nextNodeId = "victor_pressured",
                    isPsychologicalPressure = true,
                    decisionTag = "Pressured Victor Early"
                ),
                DialogueOption(
                    id = "v_opt_cufflink",
                    prompt = "[Evidence] Explain why your 'V.V.' cufflink was under his safe.",
                    nextNodeId = "victor_cufflink_break",
                    requiredClueId = "clue_cufflink"
                ),
                DialogueOption(
                    id = "v_opt_conn_theft",
                    prompt = "[Deduction] We linked your cufflink to the $14M audit ledger.",
                    nextNodeId = "victor_confesses_theft",
                    requiredConnectionId = "conn_victor_theft"
                )
            )
        ),
        DialogueNode(
            id = "victor_business",
            suspectId = SuspectId.VICTOR,
            speakerName = "Victor Vance",
            text = "Business partners disagree. Arthur was paranoid lately—hiring auditors, locking himself in that suffocating study. I never set foot upstairs after dinner at nine.",
            reactionTell = "Swallows hard; glances toward the closed corridor door.",
            stressDelta = 8,
            psychologicalHint = "Notice the absolute denial: 'never set foot upstairs after nine.' Absolute claims crumble fast against physical evidence.",
            options = listOf(
                DialogueOption(
                    id = "v_opt_b_cufflink",
                    prompt = "[Evidence] Then how did your silver cufflink end up beside his wall safe?",
                    nextNodeId = "victor_cufflink_break",
                    requiredClueId = "clue_cufflink"
                ),
                DialogueOption(
                    id = "v_opt_b_audit",
                    prompt = "[Evidence] An 8:00 AM board vote was set to indict you for $14M.",
                    nextNodeId = "victor_audit_dodge",
                    requiredClueId = "clue_audit_ledger"
                ),
                DialogueOption(
                    id = "v_opt_b_back",
                    prompt = "Let's revisit your timeline from the start.",
                    nextNodeId = "victor_start"
                )
            )
        ),
        DialogueNode(
            id = "victor_pressured",
            suspectId = SuspectId.VICTOR,
            speakerName = "Victor Vance",
            text = "Careful, Detective. Twenty years of building Thorne Bio-Dynamics doesn't evaporate because you enjoy theatrical accusations. Show me proof I touched that study, or let me call counsel.",
            reactionTell = "Jaw tightens; defensive aggression spiking to mask fear of financial exposure.",
            stressDelta = 16,
            psychologicalHint = "Aggression isn't proof of murder—it's a shield. Look for physical proof linking him to the safe rather than the poison.",
            options = listOf(
                DialogueOption(
                    id = "v_opt_p_conn",
                    prompt = "[Deduction] Your cufflink and the $14M ledger put you in the study at 10:22 PM.",
                    nextNodeId = "victor_confesses_theft",
                    requiredConnectionId = "conn_victor_theft"
                ),
                DialogueOption(
                    id = "v_opt_p_back",
                    prompt = "We'll return to your alibi shortly.",
                    nextNodeId = "victor_start"
                )
            )
        ),
        DialogueNode(
            id = "victor_audit_dodge",
            suspectId = SuspectId.VICTOR,
            speakerName = "Victor Vance",
            text = "Accounting discrepancies happen in R&D! Arthur misunderstood offshore retainers. Even if he wanted me off the board, killing him in a locked room wouldn't erase an audit file!",
            reactionTell = "Sweat beading along temple, yet his logic about the audit file is strangely coherent.",
            stressDelta = 18,
            psychologicalHint = "He's terrified of fraud charges—but notice he's right: killing Arthur wouldn't stop an external audit already in motion.",
            options = listOf(
                DialogueOption(
                    id = "v_opt_ad_conn",
                    prompt = "[Deduction] Which is why you tried stealing the ledger yourself at 10:22 PM.",
                    nextNodeId = "victor_confesses_theft",
                    requiredConnectionId = "conn_victor_theft"
                ),
                DialogueOption(
                    id = "v_opt_ad_back",
                    prompt = "Step back to earlier questioning.",
                    nextNodeId = "victor_start"
                )
            )
        ),
        DialogueNode(
            id = "victor_cufflink_break",
            suspectId = SuspectId.VICTOR,
            speakerName = "Victor Vance",
            text = "Wait—that cufflink? I... I dropped by earlier in the afternoon! No—Wait. Maybe it fell off when Marcus called me upstairs at midnight? You can't prove when it dropped!",
            reactionTell = "Voice cracks; fabricates two conflicting excuses in three seconds.",
            stressDelta = 24,
            contradictionFound = "Victor lied about never going upstairs—first claiming afternoon, then midnight.",
            psychologicalHint = "Contradiction exposed! Combine the Cufflink with the Audit Ledger on your Evidence Board to corner him completely.",
            options = listOf(
                DialogueOption(
                    id = "v_opt_cb_conn",
                    prompt = "[Deduction] Stop lying. You broke in at 10:22 PM for the $14M audit ledger.",
                    nextNodeId = "victor_confesses_theft",
                    requiredConnectionId = "conn_victor_theft"
                ),
                DialogueOption(
                    id = "v_opt_cb_back",
                    prompt = "Hold that thought while I review other leads.",
                    nextNodeId = "victor_start"
                )
            )
        ),
        DialogueNode(
            id = "victor_confesses_theft",
            suspectId = SuspectId.VICTOR,
            speakerName = "Victor Vance",
            text = "Damn it—fine! Yes, I slipped into the study at 10:22 PM! Arthur was downstairs arguing on a call, so I tried opening the safe to burn the ledger. I couldn't crack it, snapped my cufflink, and bolted before 10:35! Arthur was alive—and there wasn't even an espresso cup on his desk!",
            reactionTell = "Collapses back into the chair; frantic relief mixed with dread of fraud charges.",
            stressDelta = 30,
            contradictionFound = "Victor admits the 10:22 PM break-in—confirming Arthur was alive and no espresso had been served yet.",
            psychologicalHint = "Critical timeline confirmation: Victor left by 10:35 PM before the espresso existed. His secret is embezzlement, not murder.",
            options = listOf(
                DialogueOption(
                    id = "v_opt_ct_deal",
                    prompt = "Did you see anyone near the study corridor as you left?",
                    nextNodeId = "victor_corridor_tip",
                    decisionTag = "Leveraged Victor's Testimony"
                ),
                DialogueOption(
                    id = "v_opt_ct_back",
                    prompt = "Stay right here, Victor.",
                    nextNodeId = "victor_start"
                )
            )
        ),
        DialogueNode(
            id = "victor_corridor_tip",
            suspectId = SuspectId.VICTOR,
            speakerName = "Victor Vance",
            text = "Only shadows—wait. As I hurried down the service stairs around 10:35, I heard the dumbwaiter or kitchen espresso machine humming below. Adrian always made Arthur's 11 o'clock cup.",
            reactionTell = "Exhales shakily; genuine recall without calculation.",
            stressDelta = -5,
            psychologicalHint = "He places Adrian's routine espresso service right around 11:00 PM.",
            options = listOf(
                DialogueOption(
                    id = "v_opt_tip_back",
                    prompt = "Return to Victor's main dossier.",
                    nextNodeId = "victor_start"
                )
            )
        ),

        // ================= ELENA THORNE =================
        DialogueNode(
            id = "elena_start",
            suspectId = SuspectId.ELENA,
            speakerName = "Elena Thorne",
            text = "Arthur lived inside numbers and locks, Detective. Tonight was no different. I took my migraine tablets at 9:30 and never left the master suite until the shouting woke me.",
            reactionTell = "Hands folded serenely; eyes linger on the rain-streaked glass.",
            stressDelta = 0,
            psychologicalHint = "Her composure is practiced, almost theatrical. Look for physical traces she left in the corridor.",
            options = listOf(
                DialogueOption(
                    id = "e_opt_marriage",
                    prompt = "Was there trouble between you and Arthur this week?",
                    nextNodeId = "elena_marriage"
                ),
                DialogueOption(
                    id = "e_opt_empathy",
                    prompt = "[Empathy] Living under constant surveillance wears anyone down. You can be honest.",
                    nextNodeId = "elena_softens",
                    decisionTag = "Offered Elena Empathy"
                ),
                DialogueOption(
                    id = "e_opt_note",
                    prompt = "[Evidence] A burned prenup smelling of your jasmine perfume was in the corridor.",
                    nextNodeId = "elena_note_confront",
                    requiredClueId = "clue_shredded_note"
                ),
                DialogueOption(
                    id = "e_opt_log",
                    prompt = "[Evidence] Corridor sensors caught movement outside the study at 10:48 PM.",
                    nextNodeId = "elena_log_confront",
                    requiredClueId = "clue_security_log"
                )
            )
        ),
        DialogueNode(
            id = "elena_marriage",
            suspectId = SuspectId.ELENA,
            speakerName = "Elena Thorne",
            text = "Arthur did not keep a wife, Detective; he kept an asset. Yes, our marriage was cold. That hardly makes me foolish enough to poison him inside his own fortress.",
            reactionTell = "Chin lifts slightly; cold lucidity.",
            stressDelta = 5,
            psychologicalHint = "She concedes unhappiness freely—which usually means she's hiding a specific action rather than a general motive.",
            options = listOf(
                DialogueOption(
                    id = "e_opt_m_note",
                    prompt = "[Evidence] Then why burn a disinheritance amendment outside his study tonight?",
                    nextNodeId = "elena_note_confront",
                    requiredClueId = "clue_shredded_note"
                ),
                DialogueOption(
                    id = "e_opt_m_back",
                    prompt = "Let's return to your evening timeline.",
                    nextNodeId = "elena_start"
                )
            )
        ),
        DialogueNode(
            id = "elena_softens",
            suspectId = SuspectId.ELENA,
            speakerName = "Elena Thorne",
            text = "You're sharper than the local police... Truthfully, I wasn't asleep at 10:45. I was packing to leave for Lisbon tomorrow morning. If Arthur saw me in the hall, he would have had Marcus detain me.",
            reactionTell = "Shoulders drop a fraction; voice drops to a whisper.",
            stressDelta = 12,
            psychologicalHint = "She admits leaving her room to pack—ask her what she saw in the corridor around 11:00 PM.",
            options = listOf(
                DialogueOption(
                    id = "e_opt_s_witness",
                    prompt = "Did you see anyone approach the study while you were in the hall?",
                    nextNodeId = "elena_witness_account"
                ),
                DialogueOption(
                    id = "e_opt_s_back",
                    prompt = "Thank you for that honesty.",
                    nextNodeId = "elena_start"
                )
            )
        ),
        DialogueNode(
            id = "elena_note_confront",
            suspectId = SuspectId.ELENA,
            speakerName = "Elena Thorne",
            text = "You found that... Very well. I went to the study at 10:48 PM. Not to kill him—to beg him not to leave me destitute. When he slammed the door in my face, I burned the draft in the hallway sconce and ran!",
            reactionTell = "Eyes glisten with humiliated anger; fingers grip her silver necklace.",
            stressDelta = 24,
            contradictionFound = "Elena lied about staying in her bedroom—she confronted Arthur outside the study at 10:48 PM.",
            psychologicalHint = "Her alibi broke, yet burning a paper draft outside doesn't explain cyanide at 11:05 PM. Press her on what happened right after.",
            options = listOf(
                DialogueOption(
                    id = "e_opt_nc_witness",
                    prompt = "Wait—if you lingered in the corridor alcove, who came upstairs next?",
                    nextNodeId = "elena_witness_account"
                ),
                DialogueOption(
                    id = "e_opt_nc_back",
                    prompt = "Let's step back.",
                    nextNodeId = "elena_start"
                )
            )
        ),
        DialogueNode(
            id = "elena_log_confront",
            suspectId = SuspectId.ELENA,
            speakerName = "Elena Thorne",
            text = "The 10:48 sensor? Yes, that was me slipping along the corridor wall. I didn't want Marcus logging me carrying a travel bag! That's all I'll say unless you have something real.",
            reactionTell = "Defensive posture, trying to minimize her presence.",
            stressDelta = 16,
            contradictionFound = "Elena admits triggering the 10:48 PM upstairs sensor.",
            psychologicalHint = "Confront her with the charred prenup or use empathy to learn who else entered the wing after 11:00 PM.",
            options = listOf(
                DialogueOption(
                    id = "e_opt_lc_note",
                    prompt = "[Evidence] You weren't just carrying a bag—you burned his prenup amendment.",
                    nextNodeId = "elena_note_confront",
                    requiredClueId = "clue_shredded_note"
                ),
                DialogueOption(
                    id = "e_opt_lc_back",
                    prompt = "We'll continue in a moment.",
                    nextNodeId = "elena_start"
                )
            )
        ),
        DialogueNode(
            id = "elena_witness_account",
            suspectId = SuspectId.ELENA,
            speakerName = "Elena Thorne",
            text = "At 11:04 PM I hid behind the velvet alcove curtain so nobody would see my swollen eyes. I heard soft footsteps pass—someone carrying a porcelain cup on a silver tray. A few minutes later, I heard the upstairs terminal chime softly, then a faint scraping sound beneath the study oak door.",
            reactionTell = "Voice steady, vivid sensory recall—a mark of genuine memory, not fabrication.",
            stressDelta = -6,
            psychologicalHint = "Crucial eyewitness lead: 11:04 PM silver tray + upstairs terminal chime + scraping under the door!",
            options = listOf(
                DialogueOption(
                    id = "e_opt_wa_back",
                    prompt = "That detail changes everything. Stay close, Elena.",
                    nextNodeId = "elena_start"
                )
            )
        ),

        // ================= MARCUS STERLING =================
        DialogueNode(
            id = "marcus_start",
            suspectId = SuspectId.MARCUS,
            speakerName = "Marcus Sterling",
            text = "I've run security for generals and CEOs, Detective. I watched the corridor grid from my guardhouse until Arthur missed his 11:30 check-in. When I tried my master key, the brass key was lying inside—door bolted tight.",
            reactionTell = "Stands at rigid parade rest; avoids smelling distance.",
            stressDelta = 0,
            psychologicalHint = "Overcompensating with military authority. Check if he was actually awake and at his console between 11:00 and 11:30 PM.",
            options = listOf(
                DialogueOption(
                    id = "m_opt_door",
                    prompt = "Tell me exactly how you found the study door and key.",
                    nextNodeId = "marcus_door_details"
                ),
                DialogueOption(
                    id = "m_opt_flask",
                    prompt = "[Evidence] We found your whiskey flask and a $40,000 debt notice in the alcove.",
                    nextNodeId = "marcus_flask_break",
                    requiredClueId = "clue_guard_flask"
                ),
                DialogueOption(
                    id = "m_opt_conn",
                    prompt = "[Deduction] You passed out from 11:00 to 11:28—yet the 11:08 log was wiped upstairs.",
                    nextNodeId = "marcus_full_truth",
                    requiredConnectionId = "conn_marcus_alibi"
                )
            )
        ),
        DialogueNode(
            id = "marcus_door_details",
            suspectId = SuspectId.MARCUS,
            speakerName = "Marcus Sterling",
            text = "Deadbolt thrown. No key in the exterior keyhole, so I shouldered the frame until the latch gave. And there sits the study's only brass key on the rug inside! No human walked through that oak slab.",
            reactionTell = "Nods emphatically—genuinely baffled by the locked-room mechanics.",
            stressDelta = 4,
            psychologicalHint = "His confusion about the key sounds authentic. Notice he assumes the key couldn't cross a locked door.",
            options = listOf(
                DialogueOption(
                    id = "m_opt_dd_flask",
                    prompt = "[Evidence] Then why were you drinking in the alcove instead of watching the monitors?",
                    nextNodeId = "marcus_flask_break",
                    requiredClueId = "clue_guard_flask"
                ),
                DialogueOption(
                    id = "m_opt_dd_back",
                    prompt = "Back to your patrol timeline.",
                    nextNodeId = "marcus_start"
                )
            )
        ),
        DialogueNode(
            id = "marcus_flask_break",
            suspectId = SuspectId.MARCUS,
            speakerName = "Marcus Sterling",
            text = "Keep your voice down... Look, the loan sharks threatened my daughter's apartment. Arthur turned me down cold. I took three pulls of bourbon in the vestibule at 11:00 and blacked out until my watch alarm buzzed at 11:28. I lied on the log so I wouldn't lose my pension!",
            reactionTell = "Military posture collapses; knuckles white against his knees.",
            stressDelta = 26,
            contradictionFound = "Marcus admits he falsified his patrol sheet—he was unconscious from 11:00 to 11:28 PM.",
            psychologicalHint = "Wait: if Marcus was asleep downstairs, who wiped the 11:08–11:15 PM motion log? Connect his flask with the Security Log on the Evidence Board!",
            options = listOf(
                DialogueOption(
                    id = "m_opt_fb_conn",
                    prompt = "[Deduction] If you were out cold downstairs, who used Executive Credential #02 upstairs?",
                    nextNodeId = "marcus_full_truth",
                    requiredConnectionId = "conn_marcus_alibi"
                ),
                DialogueOption(
                    id = "m_opt_fb_back",
                    prompt = "Stay put while I review the logs.",
                    nextNodeId = "marcus_start"
                )
            )
        ),
        DialogueNode(
            id = "marcus_full_truth",
            suspectId = SuspectId.MARCUS,
            speakerName = "Marcus Sterling",
            text = "Executive Credential #02?! Only two people on Earth hold #02—Arthur himself, and his golden boy Adrian Cole! My guardhouse badge is #04. Whoever killed the 11:08 feed stood right outside the study door!",
            reactionTell = "Eyes widen with sudden clarity; angry realization.",
            stressDelta = -8,
            psychologicalHint = "Decisive break: Credential #02 narrows the digital wipe exclusively to Arthur or Adrian Cole.",
            options = listOf(
                DialogueOption(
                    id = "m_opt_ft_deal",
                    prompt = "[Decision] Give me Adrian's suite access records and I'll note your cooperation.",
                    nextNodeId = "marcus_suite_clue",
                    decisionTag = "Secured Marcus Cooperation"
                ),
                DialogueOption(
                    id = "m_opt_ft_harsh",
                    prompt = "[Decision] You're still facing obstruction charges. Hand over every keycard log now.",
                    nextNodeId = "marcus_suite_clue",
                    isPsychologicalPressure = true,
                    decisionTag = "Threatened Marcus With Obstruction"
                )
            )
        ),
        DialogueNode(
            id = "marcus_suite_clue",
            suspectId = SuspectId.MARCUS,
            speakerName = "Marcus Sterling",
            text = "Suite B has a private lab courier drop. And now that I think about it, when I broke the study door open, the brass key was unusually close to the threshold—not over by the desk where Arthur always tossed it.",
            reactionTell = "Salutes stiffly—anxious to make amends.",
            stressDelta = -4,
            psychologicalHint = "Reinforces the threshold anomaly: the key didn't fall from Arthur's hand.",
            options = listOf(
                DialogueOption(
                    id = "m_opt_sc_back",
                    prompt = "Return to Marcus's dossier.",
                    nextNodeId = "marcus_start"
                )
            )
        ),

        // ================= ADRIAN COLE (THE REAL CULPRIT) =================
        DialogueNode(
            id = "adrian_start",
            suspectId = SuspectId.ADRIAN,
            speakerName = "Adrian Cole",
            text = "I'm still shaking, Detective. Arthur was demanding, yes, but he trusted me with everything. I finished sorting his 10:30 PM correspondence in Suite B and turned in by 10:55. The door was locked from the inside—it makes no sense.",
            reactionTell = "Hands steady, voice soft and precisely paced; spectacles adjusted once.",
            stressDelta = 0,
            psychologicalHint = "Too composed for someone whose mentor just died. Notice how quickly he reinforces 'locked from the inside.'",
            options = listOf(
                DialogueOption(
                    id = "a_opt_routine",
                    prompt = "Didn't you normally bring Arthur a late espresso around 11:00 PM?",
                    nextNodeId = "adrian_espresso_lie"
                ),
                DialogueOption(
                    id = "a_opt_thesis",
                    prompt = "Tell me about your graduate chemistry work before joining Thorne Bio-Dynamics.",
                    nextNodeId = "adrian_past_probe",
                    isPsychologicalPressure = true,
                    decisionTag = "Probed Adrian's Buried Patent"
                ),
                DialogueOption(
                    id = "a_opt_conn_poison",
                    prompt = "[Deduction] Cyanide in the 11:05 espresso traces directly to your Suite B reagent slip.",
                    nextNodeId = "adrian_poison_corner",
                    requiredConnectionId = "conn_poison_source"
                ),
                DialogueOption(
                    id = "a_opt_conn_door",
                    prompt = "[Deduction] You slid the brass key under the 1.5 cm door gap with a laminated card.",
                    nextNodeId = "adrian_door_corner",
                    requiredConnectionId = "conn_locked_room_trick"
                ),
                DialogueOption(
                    id = "a_opt_conn_wipe",
                    prompt = "[Deduction] Executive Credential #02 erased the 11:08–11:15 PM corridor log.",
                    nextNodeId = "adrian_wipe_corner",
                    requiredConnectionId = "conn_executive_wipe"
                )
            )
        ),
        DialogueNode(
            id = "adrian_espresso_lie",
            suspectId = SuspectId.ADRIAN,
            speakerName = "Adrian Cole",
            text = "Usually, yes—11:00 sharp. Tonight Arthur told me at 10:15 not to bother; he said he had private calls. If there was an espresso cup on his desk, he must have brewed it himself earlier.",
            reactionTell = "Blinks twice in rapid succession; shoulders remain unnaturally still.",
            stressDelta = 10,
            psychologicalHint = "Wait: Victor swore there was NO espresso cup on the desk at 10:30, and Elena heard someone carrying a tray at 11:04 PM!",
            options = listOf(
                DialogueOption(
                    id = "a_opt_el_cup",
                    prompt = "[Evidence] Forensics says the espresso was brewed and poisoned between 11:05 and 11:15.",
                    nextNodeId = "adrian_espresso_contradiction",
                    requiredClueId = "clue_toxic_espresso"
                ),
                DialogueOption(
                    id = "a_opt_el_back",
                    prompt = "Let's check another angle.",
                    nextNodeId = "adrian_start"
                )
            )
        ),
        DialogueNode(
            id = "adrian_espresso_contradiction",
            suspectId = SuspectId.ADRIAN,
            speakerName = "Adrian Cole",
            text = "Forensics estimates? People overestimate time of death constantly, Detective. Even if Arthur drank coffee at 11:05, the study door was locked from the inside—nobody could have walked out after serving him.",
            reactionTell = "Micro-smirk suppressed at the corner of his mouth; leans back on the locked-room alibi.",
            stressDelta = 15,
            contradictionFound = "Adrian deflects from the 11:05 espresso timeline by hiding behind the 'impossible' locked door.",
            psychologicalHint = "He uses the locked door as a shield. Link the Scratched Key + Lab Slip + Security Log on your Evidence Board to shatter that shield.",
            options = listOf(
                DialogueOption(
                    id = "a_opt_ec_conn",
                    prompt = "[Deduction] Except we know how the key crossed the door—and where the cyanide came from.",
                    nextNodeId = "adrian_door_corner",
                    requiredConnectionId = "conn_locked_room_trick"
                ),
                DialogueOption(
                    id = "a_opt_ec_back",
                    prompt = "We'll test that locked-room theory shortly.",
                    nextNodeId = "adrian_start"
                )
            )
        ),
        DialogueNode(
            id = "adrian_past_probe",
            suspectId = SuspectId.ADRIAN,
            speakerName = "Adrian Cole",
            text = "Old academic litigation, Detective. Arthur's lawyers crushed my father's modest lab when I was twenty-four. I forgave him—working here was my way of moving forward, not backward.",
            reactionTell = "Breath pauses for two full seconds before exhaling through the nose. Pupils slightly dilated.",
            stressDelta = 18,
            psychologicalHint = "Chilling emotional suppression. Nobody 'moves forward' into serving midnight espresso to the man who bankrupted their father without a deeper agenda.",
            options = listOf(
                DialogueOption(
                    id = "a_opt_pp_poison",
                    prompt = "[Deduction] Moving forward by ordering 99% potassium cyanide to Suite B?",
                    nextNodeId = "adrian_poison_corner",
                    requiredConnectionId = "conn_poison_source"
                ),
                DialogueOption(
                    id = "a_opt_pp_back",
                    prompt = "Interesting restraint, Adrian.",
                    nextNodeId = "adrian_start"
                )
            )
        ),
        DialogueNode(
            id = "adrian_poison_corner",
            suspectId = SuspectId.ADRIAN,
            speakerName = "Adrian Cole",
            text = "That requisition has Arthur's own digital stamp! Anyone could have forged a courier routing slip to frame me—and even if I had chemicals in Suite B, how did I vanish through a bolted oak door?",
            reactionTell = "Mask slips—voice turns sharp, analytical, almost arrogant.",
            stressDelta = 26,
            contradictionFound = "Adrian denies ordering the Suite B cyanide—retreating again to the locked door defense.",
            psychologicalHint = "He's sweating now. Hit him with the Card-Slide Illusion or the Executive Credential #02 wipe!",
            options = listOf(
                DialogueOption(
                    id = "a_opt_pc_door",
                    prompt = "[Deduction] With the stiff courier card that left dust tracks under the 1.5 cm gap.",
                    nextNodeId = "adrian_door_corner",
                    requiredConnectionId = "conn_locked_room_trick"
                ),
                DialogueOption(
                    id = "a_opt_pc_wipe",
                    prompt = "[Deduction] After wiping the 11:08–11:15 PM log with Executive Credential #02.",
                    nextNodeId = "adrian_wipe_corner",
                    requiredConnectionId = "conn_executive_wipe"
                ),
                DialogueOption(
                    id = "a_opt_pc_back",
                    prompt = "Keep talking, Adrian.",
                    nextNodeId = "adrian_start"
                )
            )
        ),
        DialogueNode(
            id = "adrian_door_corner",
            suspectId = SuspectId.ADRIAN,
            speakerName = "Adrian Cole",
            text = "A... laminated card? Beneath the threshold? That's pure speculation! Any gap under that door is barely—well, it's uneven oak! You can't prove the brass key passed beneath it, or that I was even in that hallway at 11:10!",
            reactionTell = "Glasses fog slightly; right hand grips the edge of the steel table until knuckles turn white.",
            stressDelta = 32,
            contradictionFound = "Adrian panics when the 1.5 cm door-gap key slide is explained.",
            psychologicalHint = "He just tried to argue the door gap dimensions from memory! One final push with Executive Credential #02 will break him.",
            options = listOf(
                DialogueOption(
                    id = "a_opt_dc_wipe",
                    prompt = "[Deduction] We CAN prove you were there: Executive Credential #02 erased 11:08–11:15 PM.",
                    nextNodeId = "adrian_wipe_corner",
                    requiredConnectionId = "conn_executive_wipe"
                ),
                DialogueOption(
                    id = "a_opt_dc_back",
                    prompt = "You're out of room, Adrian. Time for the final accusation.",
                    nextNodeId = "adrian_start"
                )
            )
        ),
        DialogueNode(
            id = "adrian_wipe_corner",
            suspectId = SuspectId.ADRIAN,
            speakerName = "Adrian Cole",
            text = "...Arthur wasn't supposed to check the patent logs until Monday. When he called me into Suite B at ten and threatened to bury me just like he buried my father, I knew I only had one night. Cyanide acts in ninety seconds. All it took was thirty seconds with a laminated card to let the room lock itself around him.",
            reactionTell = "Total cold mask drops; hollow, eerie calm settles over his face.",
            stressDelta = 40,
            contradictionFound = "CONFESSION TRIGGERED: Adrian admits using cyanide, Credential #02, and the threshold key-slide.",
            psychologicalHint = "You have cracked the case wide open. Head to Final Accusation and attach your decisive evidence!",
            options = listOf(
                DialogueOption(
                    id = "a_opt_wc_back",
                    prompt = "Your confession is on record. Wait for the indictment.",
                    nextNodeId = "adrian_start"
                )
            )
        )
    ).associateBy { it.id }

    fun getNode(nodeId: String): DialogueNode? = ALL_NODES[nodeId]

    fun getInitialNodeId(suspectId: SuspectId): String = when (suspectId) {
        SuspectId.VICTOR -> "victor_start"
        SuspectId.ELENA -> "elena_start"
        SuspectId.ADRIAN -> "adrian_start"
        SuspectId.MARCUS -> "marcus_start"
    }

    fun findMatchingConnection(clueId1: String, clueId2: String): ClueConnection? {
        return CLUE_CONNECTIONS.firstOrNull {
            (it.clueAId == clueId1 && it.clueBId == clueId2) ||
                (it.clueAId == clueId2 && it.clueBId == clueId1)
        }
    }

    fun evaluateAccusation(
        accusedSuspect: SuspectId,
        selectedEvidenceIds: List<String>,
        selectedMethodId: String,
        discoveredConnections: Set<String>,
        recordedDecisions: List<String>
    ): EndingResult {
        val decisiveMatches = selectedEvidenceIds.count { it in DECISIVE_CLUES }
        val hasMethodCorrect = selectedMethodId == TRUE_METHOD_ID
        val hasStrongCase = decisiveMatches >= 2 && (hasMethodCorrect || discoveredConnections.size >= 2)
        val harshDecisions = recordedDecisions.count {
            it.contains("Rushed") || it.contains("Threatened")
        }

        return when {
            accusedSuspect == TRUE_CULPRIT && hasStrongCase && harshDecisions == 0 -> EndingResult(
                id = "ending_ironclad",
                title = "IRONCLAD JUSTICE",
                subtitle = "Case Closed · True Culprit Convicted",
                verdictBadge = "MASTER PROFILER",
                isSolvedCorrectly = true,
                profilerRating = "S-RANK · 100% FORENSIC PRECISION",
                narrativeSummary = "With razor-sharp toxicology, threshold physics, and Executive Credential #02 telemetry, you dismantled Adrian Cole's locked-room illusion piece by piece. Faced with an airtight chain of custody, the District Attorney secures a no-bail indictment before dawn. Blackwood Manor's ghosts finally rest."
            )
            accusedSuspect == TRUE_CULPRIT && hasStrongCase -> EndingResult(
                id = "ending_pyrrhic",
                title = "PYRRHIC CONVICTION",
                subtitle = "Case Closed · Ruthless Inquiry",
                verdictBadge = "SOLVED WITH SCARS",
                isSolvedCorrectly = true,
                profilerRating = "A-RANK · HARD-NOSED DEDUCTION",
                narrativeSummary = "You named the true killer, Adrian Cole, and backed it with decisive forensic evidence. Yet your aggressive methods—rushing sweeps or intimidating witnesses—left Marcus facing ruin and Elena silenced. Justice prevailed tonight, though the precinct whispers about the cost."
            )
            accusedSuspect == TRUE_CULPRIT -> EndingResult(
                id = "ending_doubt",
                title = "REASONABLE DOUBT",
                subtitle = "Right Suspect · Insufficient Proof",
                verdictBadge = "MISTRIAL RISK",
                isSolvedCorrectly = false,
                profilerRating = "B-RANK · INSTINCT WITHOUT PROOF",
                narrativeSummary = "Your profiler instincts pointed straight at Adrian Cole—but without attaching the decisive physical and digital evidence (such as the scratched key, falsified Suite B order, or wiped Executive log), Cole's defense attorneys tear the indictment apart in bail court. He walks out into the rain by noon."
            )
            else -> EndingResult(
                id = "ending_wrong_shadow",
                title = "THE WRONG SHADOW",
                subtitle = "Wrongful Arrest · Real Killer Escapes",
                verdictBadge = "CASE COMPROMISED",
                isSolvedCorrectly = false,
                profilerRating = "C-RANK · MISDIRECTED BY RED HERRINGS",
                narrativeSummary = "Police cuffs snap shut around ${accusedSuspect.displayName} while rain washes the courtyard clean. Behind the precinct glass, Adrian Cole watches quietly as the wrong suspect takes the fall for a crime he engineered with surgical precision. By morning, his resignation letter is on the desk—and his flight has already cleared airspace."
            )
        }
    }

    val FULL_SOLUTION_STEPS = listOf(
        "1. THE MOTIVE: Five years ago, Arthur Thorne crushed Adrian Cole's family in a patent suit. Recently, Arthur discovered Adrian leaking Thorne Bio-Dynamics formulas and confronted him at 10:00 PM.",
        "2. THE WEAPON: At 4:15 PM, Adrian forged Arthur's digital stamp to order 99% potassium cyanide routed to Suite B—packaged with a stiff laminated courier ID card.",
        "3. THE DISTRACTIONS: At 10:22 PM, Victor Vance broke in seeking the $14M audit ledger and lost his cufflink. At 10:48 PM, Elena Thorne burned the revised prenup in the corridor. At 11:00 PM, Marcus Sterling passed out drinking in the vestibule.",
        "4. THE MURDER (11:05 PM): Adrian brought Arthur his nightly espresso laced with potassium cyanide. Arthur collapsed within ninety seconds.",
        "5. THE LOCKED-ROOM ILLUSION (11:08–11:15 PM): Adrian stepped outside, wiped the corridor motion log using Executive Credential #02, locked the oak door from the OUTSIDE, and used the stiff laminated courier card to slide the brass key 40 cm inward beneath the 1.5 cm door gap—leaving parallel scratches on the key and a brushed dust trail."
    )
}
