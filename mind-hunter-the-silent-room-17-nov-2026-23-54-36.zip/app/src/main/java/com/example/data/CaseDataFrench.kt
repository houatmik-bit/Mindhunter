package com.example.data

import com.example.R
import com.example.model.Clue
import com.example.model.ClueCategory
import com.example.model.ClueConnection
import com.example.model.CrimeZone
import com.example.model.DialogueNode
import com.example.model.DialogueOption
import com.example.model.EndingResult
import com.example.model.ForensicManualEntry
import com.example.model.MethodTheory
import com.example.model.SuspectId
import com.example.model.SuspectProfile

object CaseDataFrench {
    val data: LocalizedCaseData by lazy {
        LocalizedCaseData(
            caseCode = "AFFAIRE #MH-01",
            caseTitle = "La Chambre Silencieuse",
            victimName = "Arthur Thorne",
            victimDetails = "58 ans · Fondateur de Thorne Bio-Dynamics · Retrouvé mort à 23 h 45 dans son bureau en acajou au 1er étage.",
            manorLocationBadge = "MANOIR BLACKWOOD · 23 H 45",
            briefingParagraphs = listOf(
                "La pluie fouette les vitraux du manoir Blackwood. À 23 h 45, le chef de la sécurité Marcus Sterling enfonce la porte du bureau après qu'Arthur Thorne cesse de répondre à l'interphone.",
                "À l'intérieur, Thorne est affaissé sur son sous-main — aucune balle, aucune lutte, aucune fenêtre forcée. Plus étrange encore : la seule lourde clé en laiton repose sur le tapis persan à l'intérieur de la pièce.",
                "Quatre personnes se trouvent encore dans le domaine bouclé ce soir. Chacune avait une raison de réduire Arthur Thorne au silence avant l'aube. Une seule a orchestré l'illusion d'une pièce close."
            ),
            crimeZones = listOf(
                CrimeZone(
                    id = "zone_desk",
                    name = "Bureau en Acajou & Service Espresso",
                    locationLabel = "Centre du Bureau · Zone Victime",
                    hotspotXFraction = 0.48f,
                    hotspotYFraction = 0.58f,
                    initialDescription = "Un verre en cristal renversé côtoie une tasse d'espresso en porcelaine à moitié vide. Sous le sous-main en cuir dépasse le coin d'un bon de laboratoire plié.",
                    carefulActionLabel = "Analyser la Tasse & Inspecter le Sous-Main",
                    quickActionLabel = "Mettre la Tasse sous Scellés Rapidement",
                    carefulOutcome = "Vous décelez une légère odeur d'amande amère dans le marc d'espresso et extrayez un bon de réactif falsifié caché sous le sous-main.",
                    quickOutcome = "Vous placez la tasse sous scellés en notant un résidu inhabituel, et repérez de justesse le bord du bon caché sous le sous-main.",
                    clueIds = listOf("clue_toxic_espresso", "clue_lab_requisition"),
                    decisionId = "dec_desk_forensics",
                    carefulDecisionTag = "Toxicologie Approfondie du Bureau",
                    quickDecisionTag = "Inspection Rapide de Surface"
                ),
                CrimeZone(
                    id = "zone_door",
                    name = "Porte en Chêne & Seuil en Laiton",
                    locationLabel = "Sortie Est · Point Verrouillé",
                    hotspotXFraction = 0.78f,
                    hotspotYFraction = 0.45f,
                    initialDescription = "La porte en chêne n'est fendue que là où Marcus a forcé le pêne. La clé en laiton gît à 40 cm à l'intérieur sur le tapis — étrangement loin du fauteuil.",
                    carefulActionLabel = "Mesurer l'Interstice & Traces de Poussière",
                    quickActionLabel = "Photographier la Position de la Clé",
                    carefulOutcome = "Sous lumière rasante, l'espace de 1,5 cm sous la porte révèle une traînée nette dans la poussière et de fines rayures parallèles sous la clé en laiton.",
                    quickOutcome = "Vous consignez la clé à 40 cm du seuil en remarquant de légères marques de glissement dans la poussière sous la porte.",
                    clueIds = listOf("clue_door_threshold"),
                    decisionId = "dec_door_measure",
                    carefulDecisionTag = "Mesure Précise de l'Interstice",
                    quickDecisionTag = "Relevé Standard de la Clé"
                ),
                CrimeZone(
                    id = "zone_safe",
                    name = "Coffre Mural & Bibliothèque",
                    locationLabel = "Mur Ouest · Coffre Financier",
                    hotspotXFraction = 0.22f,
                    hotspotYFraction = 0.50f,
                    initialDescription = "Le coffre dissimulé est entrouvert d'un centimètre, son cadran maculé par une manche pressée. Un éclat métallique brille sous la plinthe de la bibliothèque.",
                    carefulActionLabel = "Relever les Empreintes & Récupérer l'Objet",
                    quickActionLabel = "Examiner le Registre Ouvert",
                    carefulOutcome = "Vous récupérez un bouton de manchette en argent gravé « V.V. » sous l'étagère et photographiez un registre d'audit caviardé mentionnant une expulsion à 8 h 00.",
                    quickOutcome = "Vous sortez le registre d'audit du coffre et ramassez un bouton de manchette en argent gravé « V.V. » à proximité.",
                    clueIds = listOf("clue_cufflink", "clue_audit_ledger"),
                    decisionId = "dec_safe_audit",
                    carefulDecisionTag = "Analyse Complète du Coffre",
                    quickDecisionTag = "Lecture Sommaire du Registre"
                ),
                CrimeZone(
                    id = "zone_corridor",
                    name = "Alcôve du Couloir & Terminal Sécurité",
                    locationLabel = "Aile Extérieure · Journal d'Accès",
                    hotspotXFraction = 0.62f,
                    hotspotYFraction = 0.28f,
                    initialDescription = "Un terminal en acajou pilote les capteurs de mouvement du couloir. À côté se trouvent un cendrier en laiton et une alcôve dissimulée derrière un rideau de velours.",
                    carefulActionLabel = "Auditer le Terminal & Fouiller l'Alcôve",
                    quickActionLabel = "Télécharger le Résumé des Capteurs",
                    carefulOutcome = "Trois anomalies surgissent : un bloc effacé entre 23 h 08 et 23 h 15 via l'Identifiant Exécutif, du papier brûlé parfumé au jasmin et une flasque cabossée.",
                    quickOutcome = "Vous extrayez le journal montrant une coupure de 23 h 08 à 23 h 15, ainsi que des cendres parfumées et une flasque oubliée.",
                    clueIds = listOf("clue_security_log", "clue_shredded_note", "clue_guard_flask"),
                    decisionId = "dec_corridor_audit",
                    carefulDecisionTag = "Audit Complet de Télémétrie",
                    quickDecisionTag = "Extraction Partielle des Logs"
                )
            ),
            clues = listOf(
                Clue(
                    id = "clue_toxic_espresso",
                    title = "Tasse d'Espresso Contaminée",
                    category = ClueCategory.FORENSIC,
                    zoneId = "zone_desk",
                    summary = "Tasse en porcelaine à moitié vide sur le bureau, odeur d'amande amère et résidu cristallin sur le rebord.",
                    forensicDetail = "Le test préliminaire confirme du cyanure de potassium à action rapide dissous dans l'espresso. L'ingestion se situe entre 23 h 05 et 23 h 15.",
                    timestampHint = "INGESTION EST. : 23 H 05 – 23 H 15"
                ),
                Clue(
                    id = "clue_lab_requisition",
                    title = "Bon de Réactif Falsifié",
                    category = ClueCategory.DOCUMENT,
                    zoneId = "zone_desk",
                    summary = "Commande Bio-Dynamics de cyanure de potassium à 99 % signée à 16 h 15 et livrée à la Suite Exécutive B.",
                    forensicDetail = "Signée avec le sceau numérique d'Arthur alors qu'il était à Londres. Le bordereau achemine l'ampoule — et une carte de coursier plastifiée rigide — vers la Suite B (quartiers d'Adrian).",
                    timestampHint = "LIVRAISON : 16 H 15 · SUITE B"
                ),
                Clue(
                    id = "clue_door_threshold",
                    title = "Clé Rayée & Trace de Poussière",
                    category = ClueCategory.PHYSICAL,
                    zoneId = "zone_door",
                    summary = "Clé en laiton retrouvée à 40 cm à l'intérieur avec rayures parallèles ; poussière balayée vers l'intérieur sous le seuil de 1,5 cm.",
                    forensicDetail = "La porte fut verrouillée de l'EXTÉRIEUR, puis la clé plate a été glissée sous l'interstice de 1,5 cm à l'aide d'une carte rigide plastifiée.",
                    timestampHint = "VERROUILLAGE : MIS EN SCÈNE"
                ),
                Clue(
                    id = "clue_cufflink",
                    title = "Bouton de Manchette (« V.V. »)",
                    category = ClueCategory.PHYSICAL,
                    zoneId = "zone_safe",
                    summary = "Bouton en argent gravé « V.V. », coincé sous la bibliothèque juste à côté du coffre mural.",
                    forensicDetail = "Correspond à la manchette gauche manquante de Victor Vance. Les éraflures du cadran montrent une tentative d'ouverture plus tôt dans la soirée.",
                    timestampHint = "TROUVÉ PRÈS DU COFFRE"
                ),
                Clue(
                    id = "clue_audit_ledger",
                    title = "Registre d'Audit Caviardé",
                    category = ClueCategory.DOCUMENT,
                    zoneId = "zone_safe",
                    summary = "Dossier comptable prouvant un détournement de 14 M$ vers des sociétés écrans sous la signature de Victor Vance.",
                    forensicDetail = "Une note jointe convoque un conseil d'administration d'urgence à 8 h 00 pour révoquer Victor et saisir le parquet fédéral.",
                    timestampHint = "CONSEIL D'URGENCE : 8 H 00"
                ),
                Clue(
                    id = "clue_security_log",
                    title = "Journal de Capteurs Effacé",
                    category = ClueCategory.DIGITAL,
                    zoneId = "zone_corridor",
                    summary = "Mouvements détectés à 22 h 22 et 22 h 48, suivis d'un bloc effacé entre 23 h 08 et 23 h 15.",
                    forensicDetail = "L'audit système prouve que l'effacement de 23 h 08–23 h 15 n'a PAS été lancé depuis le poste de garde, mais depuis le terminal du couloir avec l'Identifiant Exécutif #02.",
                    timestampHint = "EFFACÉ : 23 H 08 – 23 H 15"
                ),
                Clue(
                    id = "clue_shredded_note",
                    title = "Contrat Brûlé & Parfum Jasmin",
                    category = ClueCategory.PHYSICAL,
                    zoneId = "zone_corridor",
                    summary = "Fragment calciné d'un avenant de déshéritement exhalant un parfum de jasmin coûteux.",
                    forensicDetail = "Daté du matin même du meurtre. Les cendres encore intactes portent la fragrance signature d'Elena Thorne.",
                    timestampHint = "CENDRIER DU COULOIR"
                ),
                Clue(
                    id = "clue_guard_flask",
                    title = "Flasque & Avis de Dette",
                    category = ClueCategory.PHYSICAL,
                    zoneId = "zone_corridor",
                    summary = "Flasque à whisky de Marcus Sterling et mise en demeure de 40 000 $ cachés dans l'alcôve.",
                    forensicDetail = "Flasque aux trois quarts vide. Les caméras du rez-de-chaussée montrent Marcus assoupi dans le vestibule entre 23 h 00 et 23 h 28.",
                    timestampHint = "GARDE ABSENT : 23 H 00 – 23 H 28"
                )
            ),
            clueConnections = listOf(
                ClueConnection(
                    id = "conn_poison_source",
                    clueAId = "clue_toxic_espresso",
                    clueBId = "clue_lab_requisition",
                    title = "Synthèse Ciblée de Cyanure",
                    deductionSummary = "Le cyanure de l'espresso de 23 h 05 correspond à la commande falsifiée de 16 h 15 livrée directement à la Suite B d'Adrian.",
                    unlocksSuspectId = SuspectId.ADRIAN,
                    unlocksHint = "Confrontez Adrian avec la commande falsifiée de la Suite B."
                ),
                ClueConnection(
                    id = "conn_locked_room_trick",
                    clueAId = "clue_door_threshold",
                    clueBId = "clue_lab_requisition",
                    title = "L'Illusion de la Carte Glissée",
                    deductionSummary = "La carte plastifiée rigide du colis de la Suite B explique comment la clé en laiton fut glissée sous le seuil de 1,5 cm après verrouillage extérieur.",
                    unlocksSuspectId = SuspectId.ADRIAN,
                    unlocksHint = "Poussez Adrian à expliquer comment la clé s'est retrouvée à 40 cm à l'intérieur."
                ),
                ClueConnection(
                    id = "conn_executive_wipe",
                    clueAId = "clue_door_threshold",
                    clueBId = "clue_security_log",
                    title = "Fenêtre de Sortie (23 h 08–23 h 15)",
                    deductionSummary = "Celui qui a mis en scène la porte close a aussi effacé les capteurs du couloir entre 23 h 08 et 23 h 15 avec l'Identifiant Exécutif #02.",
                    unlocksSuspectId = SuspectId.ADRIAN,
                    unlocksHint = "Demandez à Adrian pourquoi l'Identifiant #02 a effacé le journal de 23 h 08."
                ),
                ClueConnection(
                    id = "conn_victor_theft",
                    clueAId = "clue_cufflink",
                    clueBId = "clue_audit_ledger",
                    title = "Effraction de Victor à 22 h 22",
                    deductionSummary = "Victor s'est introduit dans le bureau à 22 h 22 pour détruire le registre des 14 M$ — perdant son bouton près du coffre — près d'une heure avant le poison.",
                    unlocksSuspectId = SuspectId.VICTOR,
                    unlocksHint = "Brisez l'alibi de Victor grâce au bouton et au registre d'audit."
                ),
                ClueConnection(
                    id = "conn_marcus_alibi",
                    clueAId = "clue_guard_flask",
                    clueBId = "clue_security_log",
                    title = "Couloir Sans Surveillance & Fausse Piste",
                    deductionSummary = "Marcus était ivre et inconscient de 23 h 00 à 23 h 28 — mais l'effacement du journal provient de l'étage, pas de sa guérite.",
                    unlocksSuspectId = SuspectId.MARCUS,
                    unlocksHint = "Forcez Marcus à avouer son absence à 23 h 10, l'innocentant de l'effacement à l'étage."
                )
            ),
            suspects = listOf(
                SuspectProfile(
                    id = SuspectId.VICTOR,
                    fullName = "Victor Vance",
                    role = "Associé Directeur",
                    age = 49,
                    portraitRes = R.drawable.img_suspect_victor,
                    personality = "Autoritaire, cinglant, masque son anxiété derrière une arrogance d'affaires.",
                    alibiSummary = "Affirme être resté au salon du bas à étudier les bilans du T4 de 22 h 00 jusqu'à l'alerte.",
                    motive = "Arthur a découvert 14 M$ détournés par Victor et convoqué un vote à 8 h 00 pour le livrer à la justice.",
                    hiddenSecret = "S'est glissé dans le bureau à 22 h 22 pour voler le registre, a échoué devant le coffre et perdu son bouton.",
                    backstory = "Co-fondateur de Thorne Bio-Dynamics il y a vingt ans. Pendant qu'Arthur créait les brevets, Victor maquillait les comptes jusqu'à l'arrivée d'auditeurs externes.",
                    baselineTell = "Ajuste inconsciemment sa manchette gauche dès qu'on évoque le coffre.",
                    baseStress = 32
                ),
                SuspectProfile(
                    id = SuspectId.ELENA,
                    fullName = "Elena Thorne",
                    role = "Épouse de la Victime",
                    age = 38,
                    portraitRes = R.drawable.img_suspect_elena,
                    personality = "Calme de porcelaine, calculatrice, s'exprime par demi-vérités mesurées.",
                    alibiSummary = "Prétend avoir pris un traitement contre la migraine et être restée dans la suite parentale dès 21 h 30.",
                    motive = "Arthur venait de rédiger un avenant la déshéritant totalement après avoir découvert ses préparatifs de fuite.",
                    hiddenSecret = "Est montée dans l'aile du bureau à 22 h 48, a brûlé le brouillon et aperçu une silhouette portant un plateau d'argent à 23 h 04.",
                    backstory = "A épousé Arthur il y a six ans pour sauver le domaine familial. Prisonnière d'une cage dorée sous caméras, elle préparait un faux passeport pour Lisbonne.",
                    baselineTell = "Marque une demi-seconde d'hésitation sur les horaires ; effleure son collier.",
                    baseStress = 26
                ),
                SuspectProfile(
                    id = SuspectId.ADRIAN,
                    fullName = "Adrian Cole",
                    role = "Assistant Personnel & Archiviste",
                    age = 29,
                    portraitRes = R.drawable.img_suspect_adrian,
                    personality = "Doux, hyper-observateur, d'une précision horaire chirurgicale ; calme glaçant sous pression.",
                    alibiSummary = "Affirme avoir préparé le courrier de 22 h 30 dans la Suite B puis s'être couché à 22 h 55.",
                    motive = "Arthur a ruiné son père lors d'un procès sur un brevet — et vient de découvrir qu'Adrian vendait des formules à un concurrent.",
                    hiddenSecret = "A commandé du cyanure via un faux bon, empoisonné l'espresso à 23 h 05, effacé le journal à 23 h 08 et glissé la clé sous la porte.",
                    backstory = "Brillant diplômé en chimie dont la thèse fut enterrée par Thorne Bio-Dynamics. A passé trois ans à gagner la confiance absolue d'Arthur.",
                    baselineTell = "Sur-explique la physique des serrures ; sa respiration se fige à l'évocation de l'Identifiant #02.",
                    baseStress = 18
                ),
                SuspectProfile(
                    id = SuspectId.MARCUS,
                    fullName = "Marcus Sterling",
                    role = "Chef de la Sécurité",
                    age = 54,
                    portraitRes = R.drawable.img_suspect_marcus,
                    personality = "Bourru, défensif, attitude militaire ; s'emporte dès qu'on doute de sa compétence.",
                    alibiSummary = "Affirme avoir surveillé les écrans sans relâche avant d'enfoncer la porte du bureau à 23 h 45.",
                    motive = "Doit 40 000 $ à des créanciers ; Arthur lui a refusé une avance sur salaire deux jours plus tôt.",
                    hiddenSecret = "A quitté son poste pour boire dans le vestibule et s'est évanoui de 23 h 00 à 23 h 28, falsifiant sa ronde.",
                    backstory = "Vingt-deux ans dans la sécurité privée avant de rejoindre Blackwood Manor. Fier et terrorisé à l'idée de perdre sa retraite.",
                    baselineTell = "Serre la mâchoire et détourne l'attention dès qu'on scrute la tranche 23 h 00–23 h 30.",
                    baseStress = 40
                )
            ),
            methodTheories = listOf(
                MethodTheory(
                    id = Case01SilentRoom.TRUE_METHOD_ID,
                    title = "Espresso au Cyanure + Clé Glissée sous la Porte",
                    description = "Le tueur a servi un espresso empoisonné à 23 h 05, effacé le journal du couloir, verrouillé de l'extérieur puis glissé la clé sous l'interstice de 1,5 cm."
                ),
                MethodTheory(
                    id = "method_safe_struggle",
                    title = "Altercation près du Coffre & Verrou Intérieur",
                    description = "Arthur aurait été contraint d'avaler du poison lors d'une dispute devant le coffre, l'assassin fuyant par un balcon caché."
                ),
                MethodTheory(
                    id = "method_guard_override",
                    title = "Passe-Partout de Garde & Effacement depuis la Guérite",
                    description = "La sécurité aurait utilisé un double de clé et effacé le flux directement depuis le poste de garde."
                )
            ),
            dialogueNodes = frenchDialogueNodes.associateBy { it.id },
            fullSolutionSteps = listOf(
                "1. LE MOBILE : Cinq ans plus tôt, Arthur Thorne a ruiné la famille d'Adrian Cole dans un procès de brevet. Récemment, Arthur a découvert qu'Adrian vendait des formules et l'a confronté à 22 h 00.",
                "2. L'ARME : À 16 h 15, Adrian a imité le sceau numérique d'Arthur pour commander du cyanure de potassium à 99 % vers la Suite B — livré avec une carte plastifiée rigide.",
                "3. LES DIVERSIONS : À 22 h 22, Victor Vance a forcé l'entrée pour le registre des 14 M$ et perdu son bouton. À 22 h 48, Elena a brûlé l'avenant dans le couloir. À 23 h 00, Marcus s'est assoupi ivre.",
                "4. LE MEURTRE (23 H 05) : Adrian a apporté à Arthur son espresso nocturne additionné de cyanure. Arthur s'est effondré en quatre-vingt-dix secondes.",
                "5. L'ILLUSION DE LA PIÈCE CLOSE (23 H 08–23 H 15) : Adrian est sorti, a effacé le capteur du couloir via l'Identifiant Exécutif #02, a verrouillé de l'EXTÉRIEUR et glissé la clé à 40 cm sous l'interstice avec la carte rigide."
            ),
            forensicManual = listOf(
                ForensicManualEntry(
                    id = "fm_cyanide",
                    code = "TOX-04",
                    title = "Cinétique du Cyanure",
                    summary = "Asphyxiant cellulaire fulgurant. Dégage une note d'amande amère dans les boissons chaudes et agit en 60 à 120 secondes."
                ),
                ForensicManualEntry(
                    id = "fm_threshold",
                    code = "PHY-11",
                    title = "Illusion de Seuil",
                    summary = "Une clé trouvée loin à l'intérieur avec rayures parallèles suggère une insertion par le bas de porte avec une carte rigide."
                ),
                ForensicManualEntry(
                    id = "fm_deception",
                    code = "PSY-07",
                    title = "Alibis Sur-Calibrés",
                    summary = "Un suspect manipulateur donne des horaires trop précis et ramène toujours l'enquête sur « l'impossibilité » de la pièce close."
                ),
                ForensicManualEntry(
                    id = "fm_logs",
                    code = "DIG-02",
                    title = "Signatures d'Effacement",
                    summary = "Les journaux de capteurs conservent l'identifiant matériel de la console d'origine — distinguant la guérite des terminaux exécutifs."
                )
            ),
            endingDescriptions = listOf(
                "ending_ironclad" to "Fin I : Justice Implacable — Vrai coupable, preuves irréfutables, profilage rigoureux.",
                "ending_pyrrhic" to "Fin II : Victoire à la Pyrrhus — Vrai coupable condamné au prix de méthodes brutales.",
                "ending_doubt" to "Fin III : Doute Raisonnable — Vrai coupable désigné sans preuves décisives.",
                "ending_wrong_shadow" to "Fin IV : La Mauvaise Ombre — Piégé par les fausses pistes pendant que le tueur s'enfuit."
            ),
            noLinkReasoning = { c1, c2 ->
                "« $c1 » et « $c2 » appartiennent à des chronologies ou mécanismes distincts. Cherchez des horaires communs, la Suite B ou le mécanisme de la porte."
            },
            evaluateEnding = { accused, evidence, method, connections, decisions ->
                evaluateFrench(accused, evidence, method, connections, decisions)
            }
        )
    }

    private fun evaluateFrench(
        accusedSuspect: SuspectId,
        selectedEvidenceIds: List<String>,
        selectedMethodId: String,
        discoveredConnections: Set<String>,
        recordedDecisions: List<String>
    ): EndingResult {
        val decisiveMatches = selectedEvidenceIds.count { it in Case01SilentRoom.DECISIVE_CLUES }
        val hasMethodCorrect = selectedMethodId == Case01SilentRoom.TRUE_METHOD_ID
        val hasStrongCase = decisiveMatches >= 2 && (hasMethodCorrect || discoveredConnections.size >= 2)
        val harshDecisions = recordedDecisions.count { it.contains("Rapide") || it.contains("Menacé") || it.contains("Rushed") || it.contains("Threatened") }

        return when {
            accusedSuspect == Case01SilentRoom.TRUE_CULPRIT && hasStrongCase && harshDecisions == 0 -> EndingResult(
                id = "ending_ironclad",
                title = "JUSTICE IMPLACABLE",
                subtitle = "Affaire Classée · Véritable Coupable Condamné",
                verdictBadge = "MAÎTRE PROFILEUR",
                isSolvedCorrectly = true,
                profilerRating = "RANG S · PRÉCISION MÉDICO-LÉGALE 100 %",
                narrativeSummary = "Grâce à la toxicologie, à l'analyse du seuil et à la télémétrie de l'Identifiant #02, vous avez démonté pièce par pièce l'illusion d'Adrian Cole. Le procureur obtient son inculpation sans caution avant l'aube."
            )
            accusedSuspect == Case01SilentRoom.TRUE_CULPRIT && hasStrongCase -> EndingResult(
                id = "ending_pyrrhic",
                title = "VICTOIRE À LA PYRRHUS",
                subtitle = "Affaire Classée · Enquête Impitoyable",
                verdictBadge = "RÉSOLUE AVEC CICATRICES",
                isSolvedCorrectly = true,
                profilerRating = "RANG A · DÉDUCTION IMPLACABLE",
                narrativeSummary = "Vous avez arrêté le vrai meurtrier, Adrian Cole, preuves à l'appui. Mais vos méthodes expéditives ont brisé les témoins sur votre passage. La justice triomphe, non sans séquelles."
            )
            accusedSuspect == Case01SilentRoom.TRUE_CULPRIT -> EndingResult(
                id = "ending_doubt",
                title = "DOUTE RAISONNABLE",
                subtitle = "Bon Suspect · Preuves Insuffisantes",
                verdictBadge = "RISQUE DE NON-LIEU",
                isSolvedCorrectly = false,
                profilerRating = "RANG B · INTUITION SANS PREUVE",
                narrativeSummary = "Votre instinct désignait bien Adrian Cole — mais sans joindre les preuves décisives (clé rayée, bon Suite B ou log effacé), ses avocats font annuler le mandat dès midi."
            )
            else -> EndingResult(
                id = "ending_wrong_shadow",
                title = "LA MAUVAISE OMBRE",
                subtitle = "Arrestation Erronée · Le Tueur S'échappe",
                verdictBadge = "ENQUÊTE COMPROMISE",
                isSolvedCorrectly = false,
                profilerRating = "RANG C · LEURRÉ PAR LES FAUSSES PISTES",
                narrativeSummary = "Les menottes se referment sur ${accusedSuspect.displayName} sous la pluie battante. Derrière la vitre, Adrian Cole observe calmement un innocent tomber à sa place — avant de disparaître au lever du jour."
            )
        }
    }

    private val frenchDialogueNodes: List<DialogueNode> = listOf(
        // VICTOR
        DialogueNode(
            id = "victor_start",
            suspectId = SuspectId.VICTOR,
            speakerName = "Victor Vance",
            text = "Faisons vite, Inspecteur. Arthur avait le cœur fragile et beaucoup d'ennemis, mais je suis resté au salon du bas sur les marges du T4 toute la soirée.",
            reactionTell = "Poignet gauche dissimulé sous la manche ; posture raide.",
            stressDelta = 0,
            psychologicalHint = "Il a livré son alibi avant même votre question. Notez qu'il évite d'évoquer l'étage.",
            options = listOf(
                DialogueOption("v_opt_relation", "Comment étaient vos relations avec Arthur ce soir ?", "victor_business"),
                DialogueOption("v_opt_pressure", "[Pression] Votre récit semble bien répété pour un associé endeuillé.", "victor_pressured", isPsychologicalPressure = true, decisionTag = "Pression Précoce sur Victor"),
                DialogueOption("v_opt_cufflink", "[Preuve] Expliquez la présence de votre bouton « V.V. » sous son coffre.", "victor_cufflink_break", requiredClueId = "clue_cufflink"),
                DialogueOption("v_opt_conn_theft", "[Déduction] Nous avons relié votre bouton au registre des 14 M$.", "victor_confesses_theft", requiredConnectionId = "conn_victor_theft")
            )
        ),
        DialogueNode(
            id = "victor_business",
            suspectId = SuspectId.VICTOR,
            speakerName = "Victor Vance",
            text = "Les associés divergent parfois. Arthur devenait paranoïaque — engageant des auditeurs, s'enfermant dans ce bureau étouffant. Je n'ai pas remis les pieds à l'étage après 21 h.",
            reactionTell = "Déglutit sèchement ; coup d'œil vers la porte du couloir.",
            stressDelta = 8,
            psychologicalHint = "Un démenti absolu (« jamais monté après 21 h ») s'effondre vite face à une preuve physique.",
            options = listOf(
                DialogueOption("v_opt_b_cufflink", "[Preuve] Alors comment votre bouton en argent est-il arrivé près du coffre ?", "victor_cufflink_break", requiredClueId = "clue_cufflink"),
                DialogueOption("v_opt_b_audit", "[Preuve] Un conseil à 8 h 00 devait vous inculper pour 14 M$.", "victor_audit_dodge", requiredClueId = "clue_audit_ledger"),
                DialogueOption("v_opt_b_back", "Revenons à votre emploi du temps.", "victor_start")
            )
        ),
        DialogueNode(
            id = "victor_pressured",
            suspectId = SuspectId.VICTOR,
            speakerName = "Victor Vance",
            text = "Prudence, Inspecteur. Vingt ans à bâtir Bio-Dynamics ne s'effacent pas sur vos effets de manche. Montrez-moi une preuve de ma présence là-haut, ou appelez mon avocat.",
            reactionTell = "Mâchoire crispée ; agressivité défensive masquant la peur du scandale financier.",
            stressDelta = 16,
            psychologicalHint = "Sa colère protège un secret financier, pas forcément un meurtre.",
            options = listOf(
                DialogueOption("v_opt_p_conn", "[Déduction] Votre bouton et le registre prouvent votre effraction à 22 h 22.", "victor_confesses_theft", requiredConnectionId = "conn_victor_theft"),
                DialogueOption("v_opt_p_back", "Nous reprendrons cet alibi.", "victor_start")
            )
        ),
        DialogueNode(
            id = "victor_audit_dodge",
            suspectId = SuspectId.VICTOR,
            speakerName = "Victor Vance",
            text = "Des écarts comptables arrivent en R&D ! Même s'il voulait m'écarter du conseil, le tuer dans une pièce close n'aurait jamais arrêté un audit externe déjà transmis !",
            reactionTell = "Sueur aux tempes, mais son raisonnement sur l'audit reste lucide.",
            stressDelta = 18,
            psychologicalHint = "Il redoute la prison pour fraude — mais il dit vrai : tuer Arthur n'effaçait pas l'audit.",
            options = listOf(
                DialogueOption("v_opt_ad_conn", "[Déduction] C'est pourquoi vous avez tenté de voler le registre à 22 h 22.", "victor_confesses_theft", requiredConnectionId = "conn_victor_theft"),
                DialogueOption("v_opt_ad_back", "Revenir aux questions précédentes.", "victor_start")
            )
        ),
        DialogueNode(
            id = "victor_cufflink_break",
            suspectId = SuspectId.VICTOR,
            speakerName = "Victor Vance",
            text = "Attendez — ce bouton ? Je... il est tombé l'après-midi ! Non — peut-être quand Marcus m'a appelé à minuit ? Vous ne pouvez pas dater sa chute !",
            reactionTell = "Voix brisée ; invente deux excuses contradictoires en trois secondes.",
            stressDelta = 24,
            contradictionFound = "Victor a menti sur sa venue à l'étage — évoquant l'après-midi puis minuit.",
            psychologicalHint = "Contradiction exposée ! Reliez le Bouton et le Registre sur le Tableau pour le faire craquer.",
            options = listOf(
                DialogueOption("v_opt_cb_conn", "[Déduction] Assez menti. Vous êtes entré à 22 h 22 pour brûler le registre des 14 M$.", "victor_confesses_theft", requiredConnectionId = "conn_victor_theft"),
                DialogueOption("v_opt_cb_back", "Gardons cela pour plus tard.", "victor_start")
            )
        ),
        DialogueNode(
            id = "victor_confesses_theft",
            suspectId = SuspectId.VICTOR,
            speakerName = "Victor Vance",
            text = "Bon sang — d'accord ! Oui, j'ai forcé le bureau à 22 h 22 ! Arthur était au téléphone en bas. Je n'ai pas su ouvrir le coffre, j'ai arraché mon bouton et filé avant 22 h 35 ! Arthur vivait — et il n'y avait aucune tasse d'espresso sur son bureau !",
            reactionTell = "S'affaisse dans le fauteuil ; soulagement fébrile mêlé d'effroi.",
            stressDelta = 30,
            contradictionFound = "Victor avoue l'effraction de 22 h 22 — prouvant qu'Arthur vivait et sans espresso à 22 h 35.",
            psychologicalHint = "Repère temporel capital : Victor est parti avant que le café empoisonné n'existe.",
            options = listOf(
                DialogueOption("v_opt_ct_deal", "Avez-vous aperçu quelqu'un près du couloir en partant ?", "victor_corridor_tip", decisionTag = "Témoignage de Victor Exploité"),
                DialogueOption("v_opt_ct_back", "Restez à disposition, Victor.", "victor_start")
            )
        ),
        DialogueNode(
            id = "victor_corridor_tip",
            suspectId = SuspectId.VICTOR,
            speakerName = "Victor Vance",
            text = "Juste des ombres — attendez. En descendant l'escalier de service vers 22 h 35, j'ai entendu la machine à espresso bourdonner en cuisine. Adrian préparait toujours la tasse de 23 h.",
            reactionTell = "Souffle tremblant ; souvenir authentique sans calcul.",
            stressDelta = -5,
            psychologicalHint = "Il situe la préparation rituelle de l'espresso par Adrian juste avant 23 h 00.",
            options = listOf(
                DialogueOption("v_opt_tip_back", "Retour au dossier de Victor.", "victor_start")
            )
        ),

        // ELENA
        DialogueNode(
            id = "elena_start",
            suspectId = SuspectId.ELENA,
            speakerName = "Elena Thorne",
            text = "Arthur vivait entre chiffres et serrures, Inspecteur. J'ai pris mes cachets contre la migraine à 21 h 30 et ne suis sortie de ma chambre qu'aux cris de Marcus.",
            reactionTell = "Mains jointes avec sérénité ; regard fixé sur la pluie.",
            stressDelta = 0,
            psychologicalHint = "Un calme presque théâtral. Cherchez des traces physiques de son passage dans le couloir.",
            options = listOf(
                DialogueOption("e_opt_marriage", "Y avait-il des tensions entre vous cette semaine ?", "elena_marriage"),
                DialogueOption("e_opt_empathy", "[Empathie] Vivre sous surveillance constante épuise. Soyez franche.", "elena_softens", decisionTag = "Empathie envers Elena"),
                DialogueOption("e_opt_note", "[Preuve] Un contrat brûlé parfumé au jasmin gisait dans le couloir.", "elena_note_confront", requiredClueId = "clue_shredded_note"),
                DialogueOption("e_opt_log", "[Preuve] Les capteurs ont détecté un passage devant le bureau à 22 h 48.", "elena_log_confront", requiredClueId = "clue_security_log")
            )
        ),
        DialogueNode(
            id = "elena_marriage",
            suspectId = SuspectId.ELENA,
            speakerName = "Elena Thorne",
            text = "Arthur n'avait pas une épouse, mais un actif. Oui, notre mariage était glacial. Cela ne fait pas de moi l'idiote qui l'empoisonnerait dans sa propre forteresse.",
            reactionTell = "Menton relevé ; lucidité froide.",
            stressDelta = 5,
            psychologicalHint = "Elle admet la mésentente sans peine — elle dissimule plutôt un acte précis dans le couloir.",
            options = listOf(
                DialogueOption("e_opt_m_note", "[Preuve] Alors pourquoi brûler son avenant de déshéritement devant son bureau ?", "elena_note_confront", requiredClueId = "clue_shredded_note"),
                DialogueOption("e_opt_m_back", "Revenons à votre soirée.", "elena_start")
            )
        ),
        DialogueNode(
            id = "elena_softens",
            suspectId = SuspectId.ELENA,
            speakerName = "Elena Thorne",
            text = "Vous êtes plus fin que la police locale... En vérité, je ne dormais pas à 22 h 45. Je faisais mes valises pour Lisbonne. Si Arthur m'avait vue dans le couloir, il m'aurait fait retenir.",
            reactionTell = "Épaules légèrement relâchées ; voix chuchotée.",
            stressDelta = 12,
            psychologicalHint = "Elle avoue être sortie dans le couloir — demandez-lui qui est passé vers 23 h 00.",
            options = listOf(
                DialogueOption("e_opt_s_witness", "Avez-vous vu quelqu'un approcher du bureau pendant que vous étiez là ?", "elena_witness_account"),
                DialogueOption("e_opt_s_back", "Merci pour cette franchise.", "elena_start")
            )
        ),
        DialogueNode(
            id = "elena_note_confront",
            suspectId = SuspectId.ELENA,
            speakerName = "Elena Thorne",
            text = "Vous l'avez trouvé... Très bien. Je suis allée devant le bureau à 22 h 48 pour le supplier de ne pas me laisser sans rien. Quand il m'a claqué la porte au nez, j'ai brûlé le papier dans le cendrier !",
            reactionTell = "Yeux brillants d'humiliation ; doigts crispés sur son collier.",
            stressDelta = 24,
            contradictionFound = "Elena a menti sur sa chambre — elle a affronté Arthur devant le bureau à 22 h 48.",
            psychologicalHint = "Son alibi tombe, mais brûler un papier ne prouve pas le cyanure de 23 h 05. Demandez qui est venu juste après.",
            options = listOf(
                DialogueOption("e_opt_nc_witness", "Si vous étiez cachée dans le couloir, qui est monté ensuite ?", "elena_witness_account"),
                DialogueOption("e_opt_nc_back", "Revenons en arrière.", "elena_start")
            )
        ),
        DialogueNode(
            id = "elena_log_confront",
            suspectId = SuspectId.ELENA,
            speakerName = "Elena Thorne",
            text = "Le capteur de 22 h 48 ? Oui, c'était moi longeant le mur avec mon sac de voyage. Je ne dirai rien de plus sans preuve concrète.",
            reactionTell = "Posture défensive, minimisant sa présence.",
            stressDelta = 16,
            contradictionFound = "Elena reconnaît avoir déclenché le capteur de 22 h 48.",
            psychologicalHint = "Utilisez l'empathie ou le papier brûlé pour obtenir son témoignage sur 23 h 04.",
            options = listOf(
                DialogueOption("e_opt_lc_note", "[Preuve] Vous n'aviez pas qu'un sac — vous avez brûlé son contrat.", "elena_note_confront", requiredClueId = "clue_shredded_note"),
                DialogueOption("e_opt_lc_back", "Nous y reviendrons.", "elena_start")
            )
        ),
        DialogueNode(
            id = "elena_witness_account",
            suspectId = SuspectId.ELENA,
            speakerName = "Elena Thorne",
            text = "À 23 h 04, cachée derrière le rideau de velours, j'ai entendu des pas légers portant une tasse en porcelaine sur un plateau d'argent. Quelques minutes plus tard, le terminal du couloir a tinté, suivi d'un léger raclement sous la porte en chêne.",
            reactionTell = "Souvenir sensoriel précis, sans hésitation.",
            stressDelta = -6,
            psychologicalHint = "Témoignage décisif : plateau à 23 h 04 + bip du terminal + raclement sous la porte !",
            options = listOf(
                DialogueOption("e_opt_wa_back", "Ce détail change tout. Restez ici, Elena.", "elena_start")
            )
        ),

        // MARCUS
        DialogueNode(
            id = "marcus_start",
            suspectId = SuspectId.MARCUS,
            speakerName = "Marcus Sterling",
            text = "J'ai assuré la sécurité de généraux, Inspecteur. J'ai surveillé les écrans jusqu'à l'appel manqué de 23 h 30. En forçant la porte à 23 h 45, la clé en laiton gisait à l'intérieur.",
            reactionTell = "Garde-à-vous rigide ; garde ses distances.",
            stressDelta = 0,
            psychologicalHint = "Surcompensation militaire. Vérifiez s'il était vraiment éveillé à son poste entre 23 h 00 et 23 h 30.",
            options = listOf(
                DialogueOption("m_opt_door", "Décrivez exactement la porte et la position de la clé.", "marcus_door_details"),
                DialogueOption("m_opt_flask", "[Preuve] Nous avons trouvé votre flasque et une dette de 40 000 $ dans l'alcôve.", "marcus_flask_break", requiredClueId = "clue_guard_flask"),
                DialogueOption("m_opt_conn", "[Déduction] Vous dormiez de 23 h 00 à 23 h 28 — mais l'effacement vient de l'étage.", "marcus_full_truth", requiredConnectionId = "conn_marcus_alibi")
            )
        ),
        DialogueNode(
            id = "marcus_door_details",
            suspectId = SuspectId.MARCUS,
            speakerName = "Marcus Sterling",
            text = "Pêne tiré, aucune clé côté couloir. J'ai défoncé le montant — et la seule clé du bureau était posée sur le tapis dedans ! Personne n'a pu traverser ce chêne massif.",
            reactionTell = "Hochement sincère — réellement perplexe.",
            stressDelta = 4,
            psychologicalHint = "Son incompréhension paraît authentique. Il ignore qu'on peut glisser la clé sous le seuil.",
            options = listOf(
                DialogueOption("m_opt_dd_flask", "[Preuve] Pourquoi buviez-vous dans l'alcôve au lieu de surveiller les écrans ?", "marcus_flask_break", requiredClueId = "clue_guard_flask"),
                DialogueOption("m_opt_dd_back", "Revenons à votre ronde.", "marcus_start")
            )
        ),
        DialogueNode(
            id = "marcus_flask_break",
            suspectId = SuspectId.MARCUS,
            speakerName = "Marcus Sterling",
            text = "Parlez plus bas... Les usuriers menaçaient ma fille. Arthur m'a refusé un prêt. J'ai bu trois gorgées dans le vestibule à 23 h 00 et je me suis effondré jusqu'à 23 h 28. J'ai menti pour sauver ma retraite !",
            reactionTell = "Posture militaire brisée ; poings serrés sur les genoux.",
            stressDelta = 26,
            contradictionFound = "Marcus avoue avoir falsifié sa ronde — il était inconscient de 23 h 00 à 23 h 28.",
            psychologicalHint = "Si Marcus dormait en bas, qui a effacé le journal à 23 h 08 ? Reliez sa Flasque au Journal sur le Tableau !",
            options = listOf(
                DialogueOption("m_opt_fb_conn", "[Déduction] Si vous dormiez en bas, qui a utilisé l'Identifiant #02 à l'étage ?", "marcus_full_truth", requiredConnectionId = "conn_marcus_alibi"),
                DialogueOption("m_opt_fb_back", "Ne bougez pas pendant que je vérifie.", "marcus_start")
            )
        ),
        DialogueNode(
            id = "marcus_full_truth",
            suspectId = SuspectId.MARCUS,
            speakerName = "Marcus Sterling",
            text = "L'Identifiant #02 ?! Seuls deux hommes le possèdent : Arthur lui-même et son protégé Adrian Cole ! Mon badge de garde est le #04. L'auteur de la coupure de 23 h 08 se tenait juste devant le bureau !",
            reactionTell = "Yeux écarquillés ; colère soudaine et lucide.",
            stressDelta = -8,
            psychologicalHint = "Percée décisive : seul Adrian Cole (avec Arthur) détient l'Identifiant #02.",
            options = listOf(
                DialogueOption("m_opt_ft_deal", "[Décision] Donnez-moi les accès de la Suite B et je noterai votre coopération.", "marcus_suite_clue", decisionTag = "Coopération de Marcus Obtenue"),
                DialogueOption("m_opt_ft_harsh", "[Décision] Vous risquez l'entrave à la justice. Donnez ces relevés maintenant.", "marcus_suite_clue", isPsychologicalPressure = true, decisionTag = "Menacé Marcus d'Entrave")
            )
        ),
        DialogueNode(
            id = "marcus_suite_clue",
            suspectId = SuspectId.MARCUS,
            speakerName = "Marcus Sterling",
            text = "La Suite B a une livraison privée de laboratoire. Et en y repensant, quand j'ai forcé la porte, la clé était tout près du seuil — pas près du bureau où Arthur la posait toujours.",
            reactionTell = "Salut raide — impatient de se racheter.",
            stressDelta = -4,
            psychologicalHint = "Confirme l'anomalie : la clé ne vient pas de la main d'Arthur.",
            options = listOf(
                DialogueOption("m_opt_sc_back", "Retour au dossier de Marcus.", "marcus_start")
            )
        ),

        // ADRIAN (CULPRIT)
        DialogueNode(
            id = "adrian_start",
            suspectId = SuspectId.ADRIAN,
            speakerName = "Adrian Cole",
            text = "Je tremble encore, Inspecteur. Arthur était exigeant, mais il me faisait confiance. J'ai classé son courrier à 22 h 30 dans la Suite B et me suis couché à 22 h 55. La porte était fermée de l'intérieur — c'est incompréhensible.",
            reactionTell = "Mains calmes, débit précis ; ajuste ses lunettes une fois.",
            stressDelta = 0,
            psychologicalHint = "Trop serein. Remarquez comme il insiste d'emblée sur « fermée de l'intérieur ».",
            options = listOf(
                DialogueOption("a_opt_routine", "Ne lui apportiez-vous pas d'habitude son espresso à 23 h 00 ?", "adrian_espresso_lie"),
                DialogueOption("a_opt_thesis", "Parlez-moi de vos recherches en chimie avant Thorne Bio-Dynamics.", "adrian_past_probe", isPsychologicalPressure = true, decisionTag = "Sondé le Brevet Enterré d'Adrian"),
                DialogueOption("a_opt_conn_poison", "[Déduction] Le cyanure de l'espresso de 23 h 05 vient du bon de la Suite B.", "adrian_poison_corner", requiredConnectionId = "conn_poison_source"),
                DialogueOption("a_opt_conn_door", "[Déduction] Vous avez glissé la clé sous le seuil de 1,5 cm avec une carte rigide.", "adrian_door_corner", requiredConnectionId = "conn_locked_room_trick"),
                DialogueOption("a_opt_conn_wipe", "[Déduction] L'Identifiant Exécutif #02 a effacé le journal de 23 h 08–23 h 15.", "adrian_wipe_corner", requiredConnectionId = "conn_executive_wipe")
            )
        ),
        DialogueNode(
            id = "adrian_espresso_lie",
            suspectId = SuspectId.ADRIAN,
            speakerName = "Adrian Cole",
            text = "D'ordinaire oui, à 23 h pile. Ce soir, Arthur m'a dit à 22 h 15 de ne pas le déranger. S'il y avait une tasse sur son bureau, il se l'est préparée plus tôt.",
            reactionTell = "Cligne deux fois des yeux ; épaules figées.",
            stressDelta = 10,
            psychologicalHint = "Victor a juré qu'il n'y avait PAS de tasse à 22 h 30, et Elena a entendu un plateau à 23 h 04 !",
            options = listOf(
                DialogueOption("a_opt_el_cup", "[Preuve] La médecine légale date l'espresso empoisonné entre 23 h 05 et 23 h 15.", "adrian_espresso_contradiction", requiredClueId = "clue_toxic_espresso"),
                DialogueOption("a_opt_el_back", "Examinons un autre angle.", "adrian_start")
            )
        ),
        DialogueNode(
            id = "adrian_espresso_contradiction",
            suspectId = SuspectId.ADRIAN,
            speakerName = "Adrian Cole",
            text = "Des estimations légales ? On surestime souvent l'heure du décès. Même s'il a bu à 23 h 05, la porte était verrouillée de l'intérieur — personne n'a pu sortir après l'avoir servi.",
            reactionTell = "Micro-sourire réprimé ; se retranche derrière le verrouillage intérieur.",
            stressDelta = 15,
            contradictionFound = "Adrian esquive l'horaire de 23 h 05 en se cachant derrière la porte close.",
            psychologicalHint = "Reliez la Clé Rayée, le Bon Suite B et le Journal sur le Tableau pour briser sa défense.",
            options = listOf(
                DialogueOption("a_opt_ec_conn", "[Déduction] Sauf que nous savons comment la clé a traversé la porte.", "adrian_door_corner", requiredConnectionId = "conn_locked_room_trick"),
                DialogueOption("a_opt_ec_back", "Nous testerons cette théorie sous peu.", "adrian_start")
            )
        ),
        DialogueNode(
            id = "adrian_past_probe",
            suspectId = SuspectId.ADRIAN,
            speakerName = "Adrian Cole",
            text = "Un vieux litige académique. Les avocats d'Arthur ont ruiné le laboratoire de mon père quand j'avais vingt-quatre ans. J'ai pardonné — travailler ici était ma façon d'avancer.",
            reactionTell = "Retient son souffle deux secondes ; pupilles dilatées.",
            stressDelta = 18,
            psychologicalHint = "Répression émotionnelle glaçante. On ne sert pas le café à minuit à celui qui a ruiné son père sans arrière-pensée.",
            options = listOf(
                DialogueOption("a_opt_pp_poison", "[Déduction] Avancer en commandant du cyanure à 99 % vers la Suite B ?", "adrian_poison_corner", requiredConnectionId = "conn_poison_source"),
                DialogueOption("a_opt_pp_back", "Belle maîtrise de soi, Adrian.", "adrian_start")
            )
        ),
        DialogueNode(
            id = "adrian_poison_corner",
            suspectId = SuspectId.ADRIAN,
            speakerName = "Adrian Cole",
            text = "Ce bon porte le sceau numérique d'Arthur ! N'importe qui aurait pu me piéger — et même avec des réactifs en Suite B, comment aurais-je traversé une porte en chêne verrouillée ?",
            reactionTell = "Le masque tombe — voix tranchante, analytique, presque arrogante.",
            stressDelta = 26,
            contradictionFound = "Adrian nie la commande de cyanure tout en se réfugiant derrière la porte close.",
            psychologicalHint = "Il vacille. Frappez-le avec la Carte Glissée ou l'Identifiant #02 !",
            options = listOf(
                DialogueOption("a_opt_pc_door", "[Déduction] Avec la carte rigide qui a rayé la poussière sous l'espace de 1,5 cm.", "adrian_door_corner", requiredConnectionId = "conn_locked_room_trick"),
                DialogueOption("a_opt_pc_wipe", "[Déduction] Après avoir effacé le journal de 23 h 08–23 h 15 avec l'Identifiant #02.", "adrian_wipe_corner", requiredConnectionId = "conn_executive_wipe"),
                DialogueOption("a_opt_pc_back", "Continuez à parler, Adrian.", "adrian_start")
            )
        ),
        DialogueNode(
            id = "adrian_door_corner",
            suspectId = SuspectId.ADRIAN,
            speakerName = "Adrian Cole",
            text = "Une... carte plastifiée ? Sous le seuil ? Pure spéculation ! L'espace sous cette porte est à peine — enfin, c'est du vieux chêne ! Vous ne pouvez prouver ni le passage de la clé, ni ma présence dans ce couloir à 23 h 10 !",
            reactionTell = "Lunettes légèrement embuées ; main droite crispée sur le bord de la table.",
            stressDelta = 32,
            contradictionFound = "Adrian panique lorsque l'astuce du seuil de 1,5 cm est exposée.",
            psychologicalHint = "Il vient de contester de mémoire la hauteur du bas de porte ! Un dernier coup avec l'Identifiant #02 le fera céder.",
            options = listOf(
                DialogueOption("a_opt_dc_wipe", "[Déduction] Si : l'Identifiant Exécutif #02 a effacé 23 h 08–23 h 15 depuis le couloir.", "adrian_wipe_corner", requiredConnectionId = "conn_executive_wipe"),
                DialogueOption("a_opt_dc_back", "Vous êtes cerné, Adrian. Place à l'accusation finale.", "adrian_start")
            )
        ),
        DialogueNode(
            id = "adrian_wipe_corner",
            suspectId = SuspectId.ADRIAN,
            speakerName = "Adrian Cole",
            text = "...Arthur ne devait vérifier les brevets que lundi. Quand il m'a convoqué à 22 h pour me briser comme il a brisé mon père, il ne me restait qu'une nuit. Le cyanure agit en quatre-vingt-dix secondes. Trente secondes avec une carte rigide ont suffi pour que la pièce se referme sur lui.",
            reactionTell = "Le masque s'effondre ; calme vide et glaçant.",
            stressDelta = 40,
            contradictionFound = "AVEUX OBTENUS : Adrian reconnaît le cyanure, l'Identifiant #02 et le glissement de la clé.",
            psychologicalHint = "L'affaire est percée à jour. Passez à l'Accusation Finale avec vos preuves décisives !",
            options = listOf(
                DialogueOption("a_opt_wc_back", "Vos aveux sont enregistrés. Attendez votre inculpation.", "adrian_start")
            )
        )
    )
}
