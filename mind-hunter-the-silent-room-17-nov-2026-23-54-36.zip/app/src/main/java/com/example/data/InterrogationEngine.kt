package com.example.data

import com.example.model.AppLanguage
import com.example.model.EvidenceItem
import com.example.model.SuspectComposure
import com.example.model.SuspectId

data class EvidencePresentationOutcome(
    val targetNodeId: String?,
    val feedbackTitle: String,
    val feedbackMessage: String,
    val isContradiction: Boolean,
    val stressDelta: Int
)

data class PressStatementOutcome(
    val feedbackTitle: String,
    val feedbackMessage: String,
    val stressDelta: Int,
    val exposesWeakness: Boolean
)

object InterrogationEngine {

    fun evaluateComposure(stress: Int): SuspectComposure = when {
        stress >= 88 -> SuspectComposure.BROKEN
        stress >= 70 -> SuspectComposure.CORNERED
        stress >= 50 -> SuspectComposure.RATTLED
        stress >= 30 -> SuspectComposure.DEFENSIVE
        else -> SuspectComposure.CALM
    }

    fun evaluateEvidencePresentation(
        suspectId: SuspectId,
        evidence: EvidenceItem,
        discoveredConnections: Set<String>,
        language: AppLanguage
    ): EvidencePresentationOutcome {
        return when (suspectId) {
            SuspectId.VICTOR -> when (evidence.id) {
                "clue_cufflink" -> EvidencePresentationOutcome(
                    targetNodeId = "victor_cufflink_break",
                    feedbackTitle = localizedTitle(language, isHit = true),
                    feedbackMessage = when (language) {
                        AppLanguage.ENGLISH -> "Victor's eyes dart to his bare left wrist as you place the 'V.V.' cufflink on the steel table."
                        AppLanguage.FRENCH -> "Le regard de Victor file vers son poignet gauche nu lorsque vous posez le bouton « V.V. » sur la table."
                        AppLanguage.ARABIC -> "تتجه عينا فيكتور لا إرادياً إلى معصمه الأيسر العاري لحظة وضع زر «V.V.» على الطاولة."
                    },
                    isContradiction = true,
                    stressDelta = 12
                )
                "clue_audit_ledger" -> {
                    val target = if ("conn_victor_theft" in discoveredConnections) "victor_confesses_theft" else "victor_audit_dodge"
                    EvidencePresentationOutcome(
                        targetNodeId = target,
                        feedbackTitle = localizedTitle(language, isHit = true),
                        feedbackMessage = when (language) {
                            AppLanguage.ENGLISH -> "Mentioning the $14M audit ledger forces Victor onto the defensive."
                            AppLanguage.FRENCH -> "L'évocation du registre de 14 M$ place immédiatement Victor sur la défensive."
                            AppLanguage.ARABIC -> "ذكر دفتر التدقيق البالغ 14 مليون دولار يجبر فيكتور على التراجع الدفاعي."
                        },
                        isContradiction = target == "victor_confesses_theft",
                        stressDelta = 10
                    )
                }
                else -> neutralDeflection(suspectId, evidence, language)
            }

            SuspectId.ELENA -> when (evidence.id) {
                "clue_shredded_note" -> EvidencePresentationOutcome(
                    targetNodeId = "elena_note_confront",
                    feedbackTitle = localizedTitle(language, isHit = true),
                    feedbackMessage = when (language) {
                        AppLanguage.ENGLISH -> "The faint scent of jasmine on the burned prenup shatters Elena's bedroom alibi."
                        AppLanguage.FRENCH -> "Le parfum de jasmin sur le contrat brûlé brise l'alibi de la chambre d'Elena."
                        AppLanguage.ARABIC -> "رائحة الياسمين على الورقة المحترقة تحطم حجة بقاء إيلينا في غرفتها."
                    },
                    isContradiction = true,
                    stressDelta = 12
                )
                "clue_security_log" -> EvidencePresentationOutcome(
                    targetNodeId = "elena_log_confront",
                    feedbackTitle = localizedTitle(language, isHit = true),
                    feedbackMessage = when (language) {
                        AppLanguage.ENGLISH -> "Confronting Elena with the 10:48 PM corridor sensor forces her to acknowledge leaving her suite."
                        AppLanguage.FRENCH -> "Confrontée au capteur de 22 h 48, Elena admet avoir quitté sa suite."
                        AppLanguage.ARABIC -> "مواجهة إيلينا بسجل حركة 10:48 م تجبرها على الاعتراف بمغادرة جناحها."
                    },
                    isContradiction = true,
                    stressDelta = 8
                )
                else -> neutralDeflection(suspectId, evidence, language)
            }

            SuspectId.MARCUS -> when (evidence.id) {
                "clue_guard_flask" -> EvidencePresentationOutcome(
                    targetNodeId = "marcus_flask_break",
                    feedbackTitle = localizedTitle(language, isHit = true),
                    feedbackMessage = when (language) {
                        AppLanguage.ENGLISH -> "Showing Marcus his dented flask and $40,000 debt notice breaks his military facade."
                        AppLanguage.FRENCH -> "Montrer la flasque et la dette de 40 000 $ brise la façade militaire de Marcus."
                        AppLanguage.ARABIC -> "عرض القارورة وإشعار الدين البالغ 40,000 دولار يكسر الصرامة العسكرية لماركوس."
                    },
                    isContradiction = true,
                    stressDelta = 14
                )
                "clue_security_log" -> {
                    val target = if ("conn_marcus_alibi" in discoveredConnections) "marcus_full_truth" else "marcus_door_details"
                    EvidencePresentationOutcome(
                        targetNodeId = target,
                        feedbackTitle = localizedTitle(language, isHit = true),
                        feedbackMessage = when (language) {
                            AppLanguage.ENGLISH -> "Marcus studies the Executive #02 log erasure and realizes who framed the guardhouse."
                            AppLanguage.FRENCH -> "Marcus examine l'effacement via l'Identifiant #02 et comprend qui a piégé le poste de garde."
                            AppLanguage.ARABIC -> "يتفحص ماركوس مسح الاعتماد #02 ويدرك من الذي ورّط غرفة الحراسة."
                        },
                        isContradiction = false,
                        stressDelta = 6
                    )
                }
                else -> neutralDeflection(suspectId, evidence, language)
            }

            SuspectId.ADRIAN -> when (evidence.id) {
                "clue_toxic_espresso" -> EvidencePresentationOutcome(
                    targetNodeId = "adrian_espresso_contradiction",
                    feedbackTitle = localizedTitle(language, isHit = true),
                    feedbackMessage = when (language) {
                        AppLanguage.ENGLISH -> "Adrian's breathing stalls for a fraction of a second as you detail the 11:05 PM cyanide espresso."
                        AppLanguage.FRENCH -> "La respiration d'Adrian se bloque une fraction de seconde à l'évocation de l'espresso de 23 h 05."
                        AppLanguage.ARABIC -> "يتوقف تنفس أدريان لجزء من الثانية عند طرح فنجان الإسبريسو المسموم عند 11:05 م."
                    },
                    isContradiction = true,
                    stressDelta = 12
                )
                "clue_lab_requisition" -> EvidencePresentationOutcome(
                    targetNodeId = "adrian_poison_corner",
                    feedbackTitle = localizedTitle(language, isHit = true),
                    feedbackMessage = when (language) {
                        AppLanguage.ENGLISH -> "The falsified Suite B cyanide slip strips away Adrian's polite composure."
                        AppLanguage.FRENCH -> "Le bon falsifié de la Suite B fait tomber le calme poli d'Adrian."
                        AppLanguage.ARABIC -> "إذن طلب السيانيد المزور للجناح B ينزع عن أدريان قناع الهدوء."
                    },
                    isContradiction = true,
                    stressDelta = 16
                )
                "clue_door_threshold" -> EvidencePresentationOutcome(
                    targetNodeId = "adrian_door_corner",
                    feedbackTitle = localizedTitle(language, isHit = true),
                    feedbackMessage = when (language) {
                        AppLanguage.ENGLISH -> "Explaining the 1.5 cm threshold scratches causes Adrian's calm mask to crack."
                        AppLanguage.FRENCH -> "Expliquer les rayures sous le seuil de 1,5 cm fissure le masque d'Adrian."
                        AppLanguage.ARABIC -> "شرح خدوش العتبة أسفل فراغ الـ 1.5 سم يصدّع قناع أدريان بالكامل."
                    },
                    isContradiction = true,
                    stressDelta = 18
                )
                "clue_security_log" -> {
                    val target = if ("conn_executive_wipe" in discoveredConnections) "adrian_wipe_corner" else "adrian_poison_corner"
                    EvidencePresentationOutcome(
                        targetNodeId = target,
                        feedbackTitle = localizedTitle(language, isHit = true),
                        feedbackMessage = when (language) {
                            AppLanguage.ENGLISH -> "Executive Credential #02 pins the 11:08 PM erasure directly to the upstairs terminal."
                            AppLanguage.FRENCH -> "L'Identifiant #02 relie directement la coupure de 23 h 08 au terminal de l'étage."
                            AppLanguage.ARABIC -> "الاعتماد التنفيذي #02 يربط مسح الساعة 11:08 م مباشرة بالمحطة العلوية."
                        },
                        isContradiction = true,
                        stressDelta = 20
                    )
                }
                else -> neutralDeflection(suspectId, evidence, language)
            }
        }
    }

    fun pressStatement(
        suspectId: SuspectId,
        currentNodeId: String,
        currentStress: Int,
        language: AppLanguage
    ): PressStatementOutcome {
        val exposesWeakness = currentNodeId.contains("break") ||
            currentNodeId.contains("corner") ||
            currentNodeId.contains("contradiction") ||
            currentNodeId.contains("lie") ||
            currentNodeId.contains("business") ||
            currentStress >= 50

        val title = when (language) {
            AppLanguage.ENGLISH -> if (exposesWeakness) "STATEMENT PRESSED · CRACK DETECTED" else "STATEMENT PRESSED"
            AppLanguage.FRENCH -> if (exposesWeakness) "DÉCLARATION PRESSÉE · FAILLE DÉTECTÉE" else "DÉCLARATION PRESSÉE"
            AppLanguage.ARABIC -> if (exposesWeakness) "ضغط على الإفادة · رصد ثغرة" else "ضغط على الإفادة"
        }

        val message = when (suspectId) {
            SuspectId.VICTOR -> when (language) {
                AppLanguage.ENGLISH -> "You lean forward: 'Exact times, Victor. Where were your hands at 10:22 PM?' His thumb rubs the missing cufflink buttonhole."
                AppLanguage.FRENCH -> "Vous insistez : « Des heures exactes, Victor. Où étiez-vous à 22 h 22 ? » Son pouce frotte la boutonnière sans bouton."
                AppLanguage.ARABIC -> "تميل للأمام: «أوقات دقيقة يا فيكتور. أين كانت يداك الساعة 10:22 م؟» يفرك إبهامه عروة الكم الفارغة."
            }
            SuspectId.ELENA -> when (language) {
                AppLanguage.ENGLISH -> "You press quietly: 'Migraine pills don't explain perfume in the upstairs ash tray.' Her poise tightens by a fraction."
                AppLanguage.FRENCH -> "Vous pressez doucement : « La migraine n'explique pas votre parfum dans le couloir. » Son port de tête se crispe."
                AppLanguage.ARABIC -> "تضغط بهدوء: «أقراص الصداع لا تفسر رائحة عطركِ في منفضة الممر.» تتصلب ملامحها قليلاً."
            }
            SuspectId.MARCUS -> when (language) {
                AppLanguage.ENGLISH -> "You challenge his patrol pride: 'Thirty minutes without an alert on your watch, Marcus?' His shoulders sag defensively."
                AppLanguage.FRENCH -> "Vous piquez son orgueil : « Trente minutes sans surveillance sous votre garde, Marcus ? » Ses épaules s'affaissent."
                AppLanguage.ARABIC -> "تتحدى انضباطه: «ثلاثون دقيقة بلا مراقبة في نوبتك يا ماركوس؟» تنخفض كتفاه دفاعياً."
            }
            SuspectId.ADRIAN -> when (language) {
                AppLanguage.ENGLISH -> "You test his precision: 'You remember 10:55 PM to the minute, yet claim the door locked itself?' His gaze stays unnervingly level."
                AppLanguage.FRENCH -> "Vous testez sa précision : « 22 h 55 à la minute près, et une porte close par miracle ? » Son regard reste glacialement fixe."
                AppLanguage.ARABIC -> "تختبر دقته: «تتذكر 10:55 م بالدقيقة، وتزعم أن الباب أقفل نفسه بنفسه؟» تبقى نظرته ثابتة ببرود مريب."
            }
        }

        return PressStatementOutcome(
            feedbackTitle = title,
            feedbackMessage = message,
            stressDelta = if (exposesWeakness) 7 else 4,
            exposesWeakness = exposesWeakness
        )
    }

    private fun localizedTitle(language: AppLanguage, isHit: Boolean): String = when (language) {
        AppLanguage.ENGLISH -> if (isHit) "EVIDENCE IMPACT" else "NO DIRECT REACTION"
        AppLanguage.FRENCH -> if (isHit) "PREUVE DÉCISIVE" else "AUCUNE RÉACTION DIRECTE"
        AppLanguage.ARABIC -> if (isHit) "تأثير الدليل" else "لا رد فعل مباشر"
    }

    private fun neutralDeflection(
        suspectId: SuspectId,
        evidence: EvidenceItem,
        language: AppLanguage
    ): EvidencePresentationOutcome {
        val msg = when (suspectId) {
            SuspectId.VICTOR -> when (language) {
                AppLanguage.ENGLISH -> "Victor glances coldly at \"${evidence.title}\": \"That has nothing to do with my balance sheets or the drawing room.\""
                AppLanguage.FRENCH -> "Victor jette un œil froid sur « ${evidence.title} » : « Cela n'a aucun rapport avec mes comptes. »"
                AppLanguage.ARABIC -> "يلقي فيكتور نظرة باردة على «${evidence.title}»: «لا علاقة لهذا بحساباتي أو بقاعة الاستقبال.»"
            }
            SuspectId.ELENA -> when (language) {
                AppLanguage.ENGLISH -> "Elena inspects \"${evidence.title}\" calmly: \"Ask Marcus or Adrian about that—I stayed clear of Arthur's study desk.\""
                AppLanguage.FRENCH -> "Elena observe « ${evidence.title} » avec calme : « Voyez cela avec Marcus ou Adrian, je ne m'approchais pas du bureau. »"
                AppLanguage.ARABIC -> "تتأمل إيلينا «${evidence.title}» بهدوء: «اسأل ماركوس أو أدريان عن ذلك، لم أقترب من طاولة آرثر.»"
            }
            SuspectId.MARCUS -> when (language) {
                AppLanguage.ENGLISH -> "Marcus shakes his head at \"${evidence.title}\": \"Not my department, Detective. Check who handled Arthur's personal affairs.\""
                AppLanguage.FRENCH -> "Marcus secoue la tête devant « ${evidence.title} » : « Ce n'est pas mon secteur, Inspecteur. »"
                AppLanguage.ARABIC -> "يهز ماركوس رأسه أمام «${evidence.title}»: «ليس من اختصاصي أيها المحقق، افحص من يدير شؤون آرثر الخاصة.»"
            }
            SuspectId.ADRIAN -> when (language) {
                AppLanguage.ENGLISH -> "Adrian adjusts his glasses at \"${evidence.title}\": \"Interesting detail, Detective, though hardly connected to my duties in Suite B.\""
                AppLanguage.FRENCH -> "Adrian ajuste ses lunettes devant « ${evidence.title} » : « Détail curieux, mais sans lien avec la Suite B. »"
                AppLanguage.ARABIC -> "يعدل أدريان نظارته أمام «${evidence.title}»: «تفصيل مثير، لكنه لا يرتبط بمهامي في الجناح B.»"
            }
        }
        return EvidencePresentationOutcome(
            targetNodeId = null,
            feedbackTitle = localizedTitle(language, isHit = false),
            feedbackMessage = msg,
            isContradiction = false,
            stressDelta = 1
        )
    }
}
