package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.AppLanguage
import com.example.model.DetectiveNote
import com.example.model.GameScreen
import com.example.model.GameSettings
import com.example.model.InvestigationProgress
import com.example.model.NoteCategory
import com.example.model.SuspectId
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

private val Context.mindHunterDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "mind_hunter_save_store"
)

class GameProgressRepository(private val context: Context) {

    private object Keys {
        val PROGRESS_JSON = stringPreferencesKey("progress_json")
        val ENDINGS_HISTORY = stringPreferencesKey("endings_history_json")
        val SETTING_MUTED = booleanPreferencesKey("setting_muted")
        val SETTING_AMBIENT_MUSIC = booleanPreferencesKey("setting_ambient_music")
        val SETTING_HINTS = booleanPreferencesKey("setting_hints")
        val SETTING_FAST_TEXT = booleanPreferencesKey("setting_fast_text")
        val SETTING_LANGUAGE = stringPreferencesKey("setting_language")
    }

    val settingsFlow: Flow<GameSettings> = context.mindHunterDataStore.data.map { prefs ->
        GameSettings(
            isMuted = prefs[Keys.SETTING_MUTED] ?: false,
            ambientMusicEnabled = prefs[Keys.SETTING_AMBIENT_MUSIC] ?: true,
            hintsEnabled = prefs[Keys.SETTING_HINTS] ?: true,
            fastTypewriter = prefs[Keys.SETTING_FAST_TEXT] ?: false,
            language = AppLanguage.fromCode(prefs[Keys.SETTING_LANGUAGE])
        )
    }

    val progressFlow: Flow<InvestigationProgress> = context.mindHunterDataStore.data.map { prefs ->
        val raw = prefs[Keys.PROGRESS_JSON]
        val unlockedHistory = parseStringSet(prefs[Keys.ENDINGS_HISTORY])
        if (raw.isNullOrBlank()) {
            InvestigationProgress(unlockedEndingsHistory = unlockedHistory)
        } else {
            decodeProgress(raw, unlockedHistory)
        }
    }

    suspend fun saveProgress(progress: InvestigationProgress) {
        context.mindHunterDataStore.edit { prefs ->
            prefs[Keys.PROGRESS_JSON] = encodeProgress(progress)
            prefs[Keys.ENDINGS_HISTORY] = JSONArray(progress.unlockedEndingsHistory.toList()).toString()
        }
    }

    suspend fun clearCurrentInvestigation(keepHistory: Boolean = true) {
        context.mindHunterDataStore.edit { prefs ->
            prefs.remove(Keys.PROGRESS_JSON)
            if (!keepHistory) {
                prefs.remove(Keys.ENDINGS_HISTORY)
            }
        }
    }

    suspend fun updateSettings(settings: GameSettings) {
        context.mindHunterDataStore.edit { prefs ->
            prefs[Keys.SETTING_MUTED] = settings.isMuted
            prefs[Keys.SETTING_AMBIENT_MUSIC] = settings.ambientMusicEnabled
            prefs[Keys.SETTING_HINTS] = settings.hintsEnabled
            prefs[Keys.SETTING_FAST_TEXT] = settings.fastTypewriter
            prefs[Keys.SETTING_LANGUAGE] = settings.language.code
        }
    }

    private fun encodeProgress(p: InvestigationProgress): String {
        val root = JSONObject()
        root.put("caseId", p.caseId)
        root.put("hasActiveInvestigation", p.hasActiveInvestigation)
        root.put("currentScreen", p.currentScreen.name)
        root.put("inspectedZones", JSONArray(p.inspectedZones.toList()))
        root.put("collectedClues", JSONArray(p.collectedClues.toList()))
        root.put("discoveredConnections", JSONArray(p.discoveredConnections.toList()))
        root.put("visitedDialogueNodes", JSONArray(p.visitedDialogueNodes.toList()))
        root.put("detectedContradictions", JSONArray(p.detectedContradictions.toList()))

        val stressObj = JSONObject()
        p.suspectStress.forEach { (id, v) -> stressObj.put(id.name, v) }
        root.put("suspectStress", stressObj)

        val dlgObj = JSONObject()
        p.currentDialogueBySuspect.forEach { (id, nodeId) -> dlgObj.put(id.name, nodeId) }
        root.put("currentDialogueBySuspect", dlgObj)

        root.put("selectedSuspect", p.selectedSuspect.name)
        root.put("recordedDecisions", JSONArray(p.recordedDecisions))
        root.put("detectiveNotes", encodeNotes(p.detectiveNotes))
        root.put("accusedSuspect", p.accusedSuspect?.name ?: "")
        root.put("accusedEvidenceIds", JSONArray(p.accusedEvidenceIds))
        root.put("accusedMethodId", p.accusedMethodId ?: "")
        root.put("achievedEndingId", p.achievedEndingId ?: "")
        return root.toString()
    }

    private fun decodeProgress(raw: String, history: Set<String>): InvestigationProgress {
        return try {
            val obj = JSONObject(raw)
            val screenName = obj.optString("currentScreen", GameScreen.CRIME_SCENE.name)
            val screen = runCatching { GameScreen.valueOf(screenName) }.getOrDefault(GameScreen.CRIME_SCENE)
            val selectedSuspectName = obj.optString("selectedSuspect", SuspectId.VICTOR.name)
            val selectedSuspect = runCatching { SuspectId.valueOf(selectedSuspectName) }.getOrDefault(SuspectId.VICTOR)

            val stressMap = mutableMapOf<SuspectId, Int>()
            obj.optJSONObject("suspectStress")?.let { sObj ->
                SuspectId.entries.forEach { id ->
                    if (sObj.has(id.name)) stressMap[id] = sObj.optInt(id.name)
                }
            }

            val dlgMap = mutableMapOf<SuspectId, String>()
            obj.optJSONObject("currentDialogueBySuspect")?.let { dObj ->
                SuspectId.entries.forEach { id ->
                    val v = dObj.optString(id.name, "")
                    if (v.isNotEmpty()) dlgMap[id] = v
                }
            }

            val accusedStr = obj.optString("accusedSuspect", "")
            val accusedSuspect = if (accusedStr.isNotEmpty()) runCatching { SuspectId.valueOf(accusedStr) }.getOrNull() else null

            InvestigationProgress(
                caseId = obj.optString("caseId", "CASE_MH_01"),
                hasActiveInvestigation = obj.optBoolean("hasActiveInvestigation", false),
                currentScreen = screen,
                inspectedZones = jsonArrayToSet(obj.optJSONArray("inspectedZones")),
                collectedClues = jsonArrayToSet(obj.optJSONArray("collectedClues")),
                discoveredConnections = jsonArrayToSet(obj.optJSONArray("discoveredConnections")),
                visitedDialogueNodes = jsonArrayToSet(obj.optJSONArray("visitedDialogueNodes")),
                detectedContradictions = jsonArrayToSet(obj.optJSONArray("detectedContradictions")),
                suspectStress = stressMap,
                currentDialogueBySuspect = dlgMap,
                selectedSuspect = selectedSuspect,
                recordedDecisions = jsonArrayToList(obj.optJSONArray("recordedDecisions")),
                detectiveNotes = decodeNotes(obj.optJSONArray("detectiveNotes")),
                accusedSuspect = accusedSuspect,
                accusedEvidenceIds = jsonArrayToList(obj.optJSONArray("accusedEvidenceIds")),
                accusedMethodId = obj.optString("accusedMethodId", "").ifEmpty { null },
                achievedEndingId = obj.optString("achievedEndingId", "").ifEmpty { null },
                unlockedEndingsHistory = history
            )
        } catch (_: Exception) {
            InvestigationProgress(unlockedEndingsHistory = history)
        }
    }

    private fun encodeNotes(notes: List<DetectiveNote>): JSONArray {
        val arr = JSONArray()
        notes.forEach { n ->
            val obj = JSONObject()
            obj.put("id", n.id)
            obj.put("title", n.title)
            obj.put("body", n.body)
            obj.put("category", n.category.name)
            obj.put("linkedSuspectId", n.linkedSuspectId?.name ?: "")
            obj.put("linkedClueId", n.linkedClueId ?: "")
            obj.put("isPinned", n.isPinned)
            obj.put("updatedAtMillis", n.updatedAtMillis)
            arr.put(obj)
        }
        return arr
    }

    private fun decodeNotes(arr: JSONArray?): List<DetectiveNote> {
        if (arr == null) return emptyList()
        val list = ArrayList<DetectiveNote>(arr.length())
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val id = obj.optString("id", "")
            val body = obj.optString("body", "")
            if (id.isBlank() || body.isBlank()) continue
            val catName = obj.optString("category", NoteCategory.GENERAL.name)
            val category = runCatching { NoteCategory.valueOf(catName) }.getOrDefault(NoteCategory.GENERAL)
            val suspectStr = obj.optString("linkedSuspectId", "")
            val suspectId = if (suspectStr.isNotEmpty()) runCatching { SuspectId.valueOf(suspectStr) }.getOrNull() else null
            val clueId = obj.optString("linkedClueId", "").ifEmpty { null }
            list.add(
                DetectiveNote(
                    id = id,
                    title = obj.optString("title", ""),
                    body = body,
                    category = category,
                    linkedSuspectId = suspectId,
                    linkedClueId = clueId,
                    isPinned = obj.optBoolean("isPinned", false),
                    updatedAtMillis = obj.optLong("updatedAtMillis", 0L)
                )
            )
        }
        return list
    }

    private fun parseStringSet(raw: String?): Set<String> {
        if (raw.isNullOrBlank()) return emptySet()
        return runCatching { jsonArrayToSet(JSONArray(raw)) }.getOrDefault(emptySet())
    }

    private fun jsonArrayToSet(arr: JSONArray?): Set<String> {
        if (arr == null) return emptySet()
        val set = LinkedHashSet<String>()
        for (i in 0 until arr.length()) {
            set.add(arr.optString(i))
        }
        return set
    }

    private fun jsonArrayToList(arr: JSONArray?): List<String> {
        if (arr == null) return emptyList()
        val list = ArrayList<String>(arr.length())
        for (i in 0 until arr.length()) {
            list.add(arr.optString(i))
        }
        return list
    }
}
