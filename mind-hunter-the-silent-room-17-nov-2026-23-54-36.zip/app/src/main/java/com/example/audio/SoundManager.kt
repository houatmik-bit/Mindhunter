package com.example.audio

import com.example.model.GameScreen
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Coordinates ambient noir music and contextual sound effects (such as footsteps and page turning)
 * across game state and screen transitions.
 */
class SoundManager(
    private val backend: AudioSynthBackend = NoirSoundEngine()
) {
    private val _currentMood = MutableStateFlow(AmbientNoirMood.NONE)
    val currentMood: StateFlow<AmbientNoirMood> = _currentMood.asStateFlow()

    private val _isMuted = MutableStateFlow(false)
    val isMuted: StateFlow<Boolean> = _isMuted.asStateFlow()

    private val _isAmbientEnabled = MutableStateFlow(true)
    val isAmbientEnabled: StateFlow<Boolean> = _isAmbientEnabled.asStateFlow()

    private val _isAmbientActive = MutableStateFlow(false)
    val isAmbientActive: StateFlow<Boolean> = _isAmbientActive.asStateFlow()

    private val _lastTriggeredCue = MutableStateFlow<SoundCue?>(null)
    val lastTriggeredCue: StateFlow<SoundCue?> = _lastTriggeredCue.asStateFlow()

    private var isForeground: Boolean = true

    fun playEffect(cue: SoundCue) {
        if (_isMuted.value) return
        _lastTriggeredCue.value = cue
        backend.playEffect(cue)
    }

    fun setAmbientMood(mood: AmbientNoirMood) {
        _currentMood.value = mood
        syncAmbientPlayback()
    }

    fun onScreenTransition(fromScreen: GameScreen?, toScreen: GameScreen) {
        val targetMood = moodForScreen(toScreen)
        if (_currentMood.value != targetMood || !_isAmbientActive.value) {
            setAmbientMood(targetMood)
        }

        if (fromScreen != toScreen) {
            val transitionCue = transitionCueFor(fromScreen, toScreen)
            playEffect(transitionCue)
        }
    }

    fun onZoneChanged() {
        playEffect(SoundCue.FOOTSTEPS)
    }

    fun onDossierOrPageTurn() {
        playEffect(SoundCue.PAGE_TURN)
    }

    fun setMuted(muted: Boolean) {
        _isMuted.value = muted
        if (backend is NoirSoundEngine) {
            backend.isMuted = muted
        }
        syncAmbientPlayback()
    }

    fun setAmbientEnabled(enabled: Boolean) {
        _isAmbientEnabled.value = enabled
        syncAmbientPlayback()
    }

    fun onAppForeground() {
        isForeground = true
        syncAmbientPlayback()
    }

    fun onAppBackground() {
        isForeground = false
        syncAmbientPlayback()
    }

    fun release() {
        _isAmbientActive.value = false
        backend.release()
    }

    private fun syncAmbientPlayback() {
        val mood = _currentMood.value
        val shouldPlay = isForeground &&
            !_isMuted.value &&
            _isAmbientEnabled.value &&
            mood != AmbientNoirMood.NONE

        if (shouldPlay) {
            backend.startAmbientLoop(mood)
            _isAmbientActive.value = true
        } else {
            backend.stopAmbientLoop()
            _isAmbientActive.value = false
        }
    }

    companion object {
        fun moodForScreen(screen: GameScreen): AmbientNoirMood = when (screen) {
            GameScreen.MAIN_MENU,
            GameScreen.CASE_FILES,
            GameScreen.SETTINGS,
            GameScreen.CREDITS -> AmbientNoirMood.MENU_RAIN

            GameScreen.CASE_INTRO,
            GameScreen.CRIME_SCENE,
            GameScreen.SUSPECT_SELECTION -> AmbientNoirMood.INVESTIGATION_TENSION

            GameScreen.INTERROGATION,
            GameScreen.ACCUSATION -> AmbientNoirMood.INTERROGATION_PULSE

            GameScreen.EVIDENCE_BOARD,
            GameScreen.NOTEBOOK -> AmbientNoirMood.BOARD_CONTEMPLATION

            GameScreen.ENDING -> AmbientNoirMood.CONCLUSION_NOIR
        }

        fun transitionCueFor(fromScreen: GameScreen?, toScreen: GameScreen): SoundCue = when (toScreen) {
            GameScreen.CRIME_SCENE,
            GameScreen.INTERROGATION -> SoundCue.FOOTSTEPS

            GameScreen.CASE_FILES,
            GameScreen.CASE_INTRO,
            GameScreen.SUSPECT_SELECTION,
            GameScreen.EVIDENCE_BOARD,
            GameScreen.NOTEBOOK,
            GameScreen.ACCUSATION -> SoundCue.PAGE_TURN

            GameScreen.ENDING -> SoundCue.VERDICT

            GameScreen.MAIN_MENU,
            GameScreen.SETTINGS,
            GameScreen.CREDITS -> SoundCue.CLICK
        }
    }
}
