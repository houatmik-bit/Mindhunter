package com.example.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

enum class SoundCue {
    CLICK,
    FOOTSTEPS,
    PAGE_TURN,
    CLUE_FOUND,
    CONNECTION_LINKED,
    CONTRADICTION,
    HEARTBEAT,
    VERDICT
}

enum class AmbientNoirMood {
    NONE,
    MENU_RAIN,
    INVESTIGATION_TENSION,
    INTERROGATION_PULSE,
    BOARD_CONTEMPLATION,
    CONCLUSION_NOIR
}

interface AudioSynthBackend {
    fun playEffect(cue: SoundCue)
    fun startAmbientLoop(mood: AmbientNoirMood)
    fun stopAmbientLoop()
    fun release()
}

class NoirSoundEngine : AudioSynthBackend {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var ambientJob: Job? = null

    @Volatile
    var isMuted: Boolean = false

    @Volatile
    private var currentAmbientMood: AmbientNoirMood = AmbientNoirMood.NONE

    fun play(cue: SoundCue) = playEffect(cue)

    override fun playEffect(cue: SoundCue) {
        if (isMuted) return
        scope.launch {
            try {
                when (cue) {
                    SoundCue.CLICK -> playTone(freqHz = 520.0, durationMs = 45, volume = 0.14)
                    SoundCue.FOOTSTEPS -> playFootsteps()
                    SoundCue.PAGE_TURN -> playPageTurn()
                    SoundCue.CLUE_FOUND -> playChord(listOf(440.0, 554.37, 659.25), durationMs = 240, volume = 0.18)
                    SoundCue.CONNECTION_LINKED -> playChord(listOf(392.0, 587.33), durationMs = 220, volume = 0.2)
                    SoundCue.CONTRADICTION -> playDissonantPulse()
                    SoundCue.HEARTBEAT -> playHeartbeat()
                    SoundCue.VERDICT -> playChord(listOf(146.83, 220.0, 293.66), durationMs = 520, volume = 0.22)
                }
            } catch (_: Throwable) {
                // Gracefully ignore audio hardware unavailability on test/headless devices
            }
        }
    }

    override fun startAmbientLoop(mood: AmbientNoirMood) {
        if (mood == AmbientNoirMood.NONE || isMuted) {
            stopAmbientLoop()
            return
        }
        if (currentAmbientMood == mood && ambientJob?.isActive == true) {
            return
        }
        stopAmbientLoop()
        currentAmbientMood = mood
        ambientJob = scope.launch {
            streamAmbientNoir(mood)
        }
    }

    override fun stopAmbientLoop() {
        currentAmbientMood = AmbientNoirMood.NONE
        ambientJob?.cancel()
        ambientJob = null
    }

    override fun release() {
        stopAmbientLoop()
        scope.cancel()
    }

    private suspend fun kotlinx.coroutines.CoroutineScope.streamAmbientNoir(mood: AmbientNoirMood) {
        val sampleRate = 22050
        val chunkSamples = sampleRate / 2 // 0.5 second streaming chunks
        var track: AudioTrack? = null
        try {
            val minBuf = AudioTrack.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            ).coerceAtLeast(chunkSamples * 2)

            track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setTransferMode(AudioTrack.MODE_STREAM)
                .setBufferSizeInBytes(minBuf * 2)
                .build()

            track.play()

            val buffer = ShortArray(chunkSamples)
            var sampleCursor = 0L
            var noiseState = 13374219L
            var lowPassRain = 0.0

            // Select moody D-minor noir harmonic voicings per scene
            val chordFreqs = when (mood) {
                AmbientNoirMood.MENU_RAIN -> doubleArrayOf(73.42, 110.0, 174.61, 261.63) // Dm7
                AmbientNoirMood.INVESTIGATION_TENSION -> doubleArrayOf(73.42, 116.54, 164.81, 220.0) // Dm(b6)
                AmbientNoirMood.INTERROGATION_PULSE -> doubleArrayOf(65.41, 98.0, 155.56, 207.65) // Cm / tension
                AmbientNoirMood.BOARD_CONTEMPLATION -> doubleArrayOf(82.41, 110.0, 174.61, 246.94) // Am/E
                AmbientNoirMood.CONCLUSION_NOIR -> doubleArrayOf(73.42, 110.0, 146.83, 220.0) // Deep Dm
                AmbientNoirMood.NONE -> doubleArrayOf(73.42)
            }
            val rainMix = when (mood) {
                AmbientNoirMood.MENU_RAIN -> 0.045
                AmbientNoirMood.INVESTIGATION_TENSION -> 0.032
                AmbientNoirMood.BOARD_CONTEMPLATION -> 0.025
                AmbientNoirMood.INTERROGATION_PULSE -> 0.015
                AmbientNoirMood.CONCLUSION_NOIR -> 0.030
                AmbientNoirMood.NONE -> 0.0
            }
            val pulseHz = if (mood == AmbientNoirMood.INTERROGATION_PULSE) 1.1 else 0.35

            while (isActive && !isMuted && currentAmbientMood == mood) {
                for (i in 0 until chunkSamples) {
                    val t = (sampleCursor + i).toDouble() / sampleRate
                    // Deterministic soft filtered rain texture
                    noiseState = (noiseState * 1664525L + 1013904223L) and 0xFFFFFFFFL
                    val white = ((noiseState and 0xFFFFL).toDouble() / 32768.0) - 1.0
                    lowPassRain = lowPassRain * 0.88 + white * 0.12

                    // Warm slow-breathing noir pad
                    val lfo = 0.65 + 0.35 * sin(2.0 * PI * 0.12 * t)
                    var pad = 0.0
                    for (idx in chordFreqs.indices) {
                        val voiceLfo = 0.8 + 0.2 * sin(2.0 * PI * (0.07 + idx * 0.03) * t)
                        pad += sin(2.0 * PI * chordFreqs[idx] * t) * voiceLfo
                    }
                    pad = (pad / chordFreqs.size) * lfo * 0.095

                    // Subtle low noir pulse
                    val beatPhase = (t * pulseHz) % 1.0
                    val pulseEnv = if (mood == AmbientNoirMood.INTERROGATION_PULSE || mood == AmbientNoirMood.INVESTIGATION_TENSION) {
                        exp(-beatPhase * 8.0) * 0.06 * sin(2.0 * PI * 55.0 * t)
                    } else {
                        0.0
                    }

                    val fadeIn = ((sampleCursor + i).toDouble() / (sampleRate * 0.6)).coerceIn(0.0, 1.0)
                    val combined = (pad + lowPassRain * rainMix + pulseEnv) * fadeIn
                    buffer[i] = (combined * Short.MAX_VALUE)
                        .toInt()
                        .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
                        .toShort()
                }
                sampleCursor += chunkSamples
                if (!isActive || isMuted) break
                val written = track.write(buffer, 0, buffer.size)
                if (written < 0) break
            }
        } catch (_: Throwable) {
            // Gracefully ignore audio hardware unavailability on test/headless devices
        } finally {
            try {
                track?.pause()
                track?.flush()
                track?.stop()
                track?.release()
            } catch (_: Throwable) {
            }
        }
    }

    private fun playTone(freqHz: Double, durationMs: Int, volume: Double) {
        val sampleRate = 22050
        val count = (sampleRate * durationMs) / 1000
        val buffer = ShortArray(count)
        for (i in 0 until count) {
            val t = i.toDouble() / sampleRate
            val env = exp(-t * 35.0)
            val sample = sin(2.0 * PI * freqHz * t) * env * volume
            buffer[i] = (sample * Short.MAX_VALUE).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
        writePcm(sampleRate, buffer)
    }

    private fun playFootsteps() {
        val sampleRate = 22050
        val durationMs = 620
        val count = (sampleRate * durationMs) / 1000
        val buffer = ShortArray(count)
        val stepStartsSec = doubleArrayOf(0.01, 0.22, 0.43)
        var seed = 918273L
        var filtered = 0.0

        for (i in 0 until count) {
            val t = i.toDouble() / sampleRate
            seed = (seed * 1664525L + 1013904223L) and 0xFFFFFFFFL
            val white = ((seed and 0xFFFFL).toDouble() / 32768.0) - 1.0
            filtered = filtered * 0.72 + white * 0.28

            var mix = 0.0
            for (idx in stepStartsSec.indices) {
                val localT = t - stepStartsSec[idx]
                if (localT >= 0.0 && localT < 0.14) {
                    val heelThud = sin(2.0 * PI * (72.0 - localT * 180.0).coerceAtLeast(36.0) * localT) * exp(-localT * 34.0)
                    val woodScuff = filtered * exp(-localT * 52.0) * 0.55
                    val stepWeight = 1.0 - idx * 0.08
                    mix += (heelThud * 0.8 + woodScuff) * stepWeight
                }
            }
            val sample = mix * 0.30
            buffer[i] = (sample * Short.MAX_VALUE).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
        writePcm(sampleRate, buffer)
    }

    private fun playPageTurn() {
        val sampleRate = 22050
        val durationMs = 230
        val count = (sampleRate * durationMs) / 1000
        val buffer = ShortArray(count)
        var seed = 5512983L
        var prev = 0.0
        var smooth = 0.0

        for (i in 0 until count) {
            val u = i.toDouble() / count
            seed = (seed * 1664525L + 1013904223L) and 0xFFFFFFFFL
            val white = ((seed and 0xFFFFL).toDouble() / 32768.0) - 1.0
            // Band-like paper rustle: difference + smoothing
            val highPassed = white - prev * 0.65
            prev = white
            smooth = smooth * 0.45 + highPassed * 0.55

            val swishEnvelope = sin(PI * u) * (0.4 + 0.6 * sin(PI * u))
            val crispEnd = if (u > 0.72) exp(-(u - 0.72) * 28.0) * 0.35 else 0.0
            val sample = smooth * (swishEnvelope + crispEnd) * 0.24
            buffer[i] = (sample * Short.MAX_VALUE).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
        writePcm(sampleRate, buffer)
    }

    private fun playHeartbeat() {
        val sampleRate = 22050
        val durationMs = 420
        val count = (sampleRate * durationMs) / 1000
        val buffer = ShortArray(count)
        val beats = doubleArrayOf(0.01, 0.18)
        for (i in 0 until count) {
            val t = i.toDouble() / sampleRate
            var mix = 0.0
            beats.forEachIndexed { idx, start ->
                val dt = t - start
                if (dt >= 0.0 && dt < 0.14) {
                    val freq = if (idx == 0) 58.0 else 48.0
                    mix += sin(2.0 * PI * freq * dt) * exp(-dt * 26.0) * (if (idx == 0) 1.0 else 0.78)
                }
            }
            val sample = mix * 0.30
            buffer[i] = (sample * Short.MAX_VALUE).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
        writePcm(sampleRate, buffer)
    }

    private fun playChord(freqs: List<Double>, durationMs: Int, volume: Double) {
        val sampleRate = 22050
        val count = (sampleRate * durationMs) / 1000
        val buffer = ShortArray(count)
        for (i in 0 until count) {
            val t = i.toDouble() / sampleRate
            val attack = (i / (sampleRate * 0.015)).coerceAtMost(1.0)
            val decay = exp(-t * 6.5)
            var mix = 0.0
            for (f in freqs) {
                mix += sin(2.0 * PI * f * t)
            }
            val sample = (mix / freqs.size) * attack * decay * volume
            buffer[i] = (sample * Short.MAX_VALUE).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
        writePcm(sampleRate, buffer)
    }

    private fun playDissonantPulse() {
        val sampleRate = 22050
        val durationMs = 340
        val count = (sampleRate * durationMs) / 1000
        val buffer = ShortArray(count)
        for (i in 0 until count) {
            val t = i.toDouble() / sampleRate
            val decay = exp(-t * 8.0)
            val sample = (sin(2.0 * PI * 196.0 * t) + sin(2.0 * PI * 207.65 * t)) * 0.5 * decay * 0.22
            buffer[i] = (sample * Short.MAX_VALUE).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
        writePcm(sampleRate, buffer)
    }

    private fun writePcm(sampleRate: Int, samples: ShortArray) {
        val minBuf = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        val bufferBytes = maxOf(minBuf, samples.size * 2)
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_GAME)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setTransferMode(AudioTrack.MODE_STATIC)
            .setBufferSizeInBytes(bufferBytes)
            .build()

        track.write(samples, 0, samples.size)
        track.play()
        val sleepMs = (samples.size * 1000L) / sampleRate + 30L
        Thread.sleep(sleepMs)
        track.stop()
        track.release()
    }
}
