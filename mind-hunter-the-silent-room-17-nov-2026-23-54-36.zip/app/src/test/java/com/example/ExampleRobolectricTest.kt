package com.example

import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.audio.AmbientNoirMood
import com.example.audio.AudioSynthBackend
import com.example.audio.SoundCue
import com.example.audio.SoundManager
import com.example.data.Case01SilentRoom
import com.example.data.EvidenceRepository
import com.example.data.GameProgressRepository
import com.example.data.InterrogationEngine
import com.example.data.LocalGameData
import com.example.data.LocalizedStrings
import com.example.model.AppLanguage
import com.example.model.ClueCategory
import com.example.model.DetectiveNote
import com.example.model.GameScreen
import com.example.model.InvestigationFlowPhase
import com.example.model.InvestigationProgress
import com.example.model.NoteCategory
import com.example.model.SuspectComposure
import com.example.model.SuspectId
import com.example.viewmodel.GameStateViewModel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read app name from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Mind Hunter", appName)
    }

    @Test
    fun `verify local game data across english french and arabic`() {
        val enData = LocalGameData.getCase(AppLanguage.ENGLISH)
        AppLanguage.entries.forEach { lang ->
            val data = LocalGameData.getCase(lang)
            val strings = LocalizedStrings.get(lang)
            assertTrue("Empty app title for $lang", strings.appTitle.isNotBlank())
            assertEquals("Zone count mismatch for $lang", enData.crimeZones.size, data.crimeZones.size)
            assertEquals("Clue count mismatch for $lang", enData.clues.size, data.clues.size)
            assertEquals("Connection count mismatch for $lang", enData.clueConnections.size, data.clueConnections.size)
            assertEquals("Suspect count mismatch for $lang", enData.suspects.size, data.suspects.size)
            assertEquals("Forensic manual mismatch for $lang", 4, data.forensicManual.size)
            assertEquals(lang == AppLanguage.ARABIC, lang.isRtl)

            data.dialogueNodes.values.forEach { node ->
                node.options.forEach { opt ->
                    assertNotNull("Missing target node ${opt.nextNodeId} in $lang", data.dialogueNodes[opt.nextNodeId])
                }
            }
        }
    }

    @Test
    fun `verify case 01 clue connections and all four endings`() {
        val poisonConn = Case01SilentRoom.findMatchingConnection("clue_toxic_espresso", "clue_lab_requisition")
        assertNotNull(poisonConn)
        assertEquals("conn_poison_source", poisonConn?.id)
        assertNull(Case01SilentRoom.findMatchingConnection("clue_cufflink", "clue_shredded_note"))

        val ironclad = Case01SilentRoom.evaluateAccusation(
            accusedSuspect = SuspectId.ADRIAN,
            selectedEvidenceIds = listOf("clue_toxic_espresso", "clue_door_threshold", "clue_security_log"),
            selectedMethodId = Case01SilentRoom.TRUE_METHOD_ID,
            discoveredConnections = setOf("conn_poison_source", "conn_locked_room_trick"),
            recordedDecisions = listOf("Thorough Desk Toxicology", "Secured Marcus Cooperation")
        )
        assertEquals("ending_ironclad", ironclad.id)
        assertTrue(ironclad.isSolvedCorrectly)

        val wrong = Case01SilentRoom.evaluateAccusation(
            accusedSuspect = SuspectId.VICTOR,
            selectedEvidenceIds = listOf("clue_cufflink", "clue_audit_ledger"),
            selectedMethodId = "method_safe_struggle",
            discoveredConnections = setOf("conn_victor_theft"),
            recordedDecisions = emptyList()
        )
        assertEquals("ending_wrong_shadow", wrong.id)
        assertFalse(wrong.isSolvedCorrectly)
    }

    @Test
    fun `verify EvidenceRepository manages EvidenceItem add list filter and examine`() {
        val repo = EvidenceRepository()
        val caseData = LocalGameData.getCase(AppLanguage.ENGLISH)

        val added1 = repo.addEvidence("clue_toxic_espresso", caseData, emptySet())
        val added2 = repo.addEvidence("clue_cufflink", caseData, emptySet())
        assertNotNull(added1)
        assertNotNull(added2)

        assertEquals(2, repo.listEvidence().size)
        assertEquals(1, repo.listEvidence(ClueCategory.FORENSIC).size)
        assertEquals(1, repo.listEvidence(ClueCategory.PHYSICAL).size)

        repo.markEvidenceExamined("clue_cufflink")
        assertTrue(repo.getEvidenceById("clue_cufflink")?.isExamined == true)

        repo.clear()
        assertTrue(repo.listEvidence().isEmpty())
    }

    @Test
    fun `verify GameStateViewModel evidence and interrogation logic`() {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val vm = GameStateViewModel(app)

        assertEquals(InvestigationFlowPhase.MAIN_MENU, vm.uiState.value.flowPhase)
        assertEquals(GameScreen.MAIN_MENU, vm.uiState.value.currentScreen)

        vm.startNewInvestigation()
        assertEquals(InvestigationFlowPhase.INVESTIGATION, vm.uiState.value.flowPhase)

        // Add & list evidence through GameStateViewModel
        val item = vm.addEvidence("clue_cufflink")
        assertNotNull(item)
        assertEquals(1, vm.listEvidence().size)
        assertEquals("clue_cufflink", vm.collectedEvidence.value.first().id)

        // Enter Victor's interrogation and present matching evidence
        vm.enterInterrogationPhase(SuspectId.VICTOR)
        assertEquals(InvestigationFlowPhase.INTERROGATION, vm.uiState.value.flowPhase)

        vm.presentEvidenceToSuspect("clue_cufflink")
        assertEquals("victor_cufflink_break", vm.uiState.value.progress.currentDialogueBySuspect[SuspectId.VICTOR])
        assertTrue(vm.uiState.value.interrogationFeedback?.isContradiction == true)
        assertTrue(vm.collectedEvidence.value.first { it.id == "clue_cufflink" }.isExamined)

        // Press Victor's statement
        val beforeStress = vm.uiState.value.progress.suspectStress[SuspectId.VICTOR] ?: 0
        vm.pressCurrentStatement()
        val afterStress = vm.uiState.value.progress.suspectStress[SuspectId.VICTOR] ?: 0
        assertTrue(afterStress > beforeStress)

        // Present irrelevant evidence to Elena
        vm.enterInterrogationPhase(SuspectId.ELENA)
        vm.presentEvidenceToSuspect("clue_cufflink")
        assertFalse(vm.uiState.value.interrogationFeedback?.isContradiction == true)

        // Check composure thresholds
        assertEquals(SuspectComposure.CALM, InterrogationEngine.evaluateComposure(20))
        assertEquals(SuspectComposure.BROKEN, InterrogationEngine.evaluateComposure(92))

        val progress = InvestigationProgress(
            collectedClues = setOf("clue_toxic_espresso", "clue_lab_requisition"),
            discoveredConnections = setOf("conn_poison_source")
        )
        assertTrue(progress.completionPercentage > 0)
    }

    @Test
    fun `verify SoundManager triggers ambient noir music and footsteps or page turn on transitions`() {
        val playedCues = mutableListOf<SoundCue>()
        val startedMoods = mutableListOf<AmbientNoirMood>()
        var stopCount = 0

        val fakeBackend = object : AudioSynthBackend {
            override fun playEffect(cue: SoundCue) {
                playedCues += cue
            }

            override fun startAmbientLoop(mood: AmbientNoirMood) {
                startedMoods += mood
            }

            override fun stopAmbientLoop() {
                stopCount++
            }

            override fun release() {
                stopCount++
            }
        }

        val manager = SoundManager(fakeBackend)

        // Transitioning to Case Intro turns dossier pages and starts tension score
        manager.onScreenTransition(GameScreen.MAIN_MENU, GameScreen.CASE_INTRO)
        assertEquals(AmbientNoirMood.INVESTIGATION_TENSION, manager.currentMood.value)
        assertEquals(SoundCue.PAGE_TURN, playedCues.last())
        assertTrue(manager.isAmbientActive.value)

        // Stepping onto Crime Scene plays footsteps
        manager.onScreenTransition(GameScreen.CASE_INTRO, GameScreen.CRIME_SCENE)
        assertEquals(AmbientNoirMood.INVESTIGATION_TENSION, manager.currentMood.value)
        assertEquals(SoundCue.FOOTSTEPS, playedCues.last())

        // Opening Evidence Board turns pages & switches to contemplative mood
        manager.onScreenTransition(GameScreen.CRIME_SCENE, GameScreen.EVIDENCE_BOARD)
        assertEquals(AmbientNoirMood.BOARD_CONTEMPLATION, manager.currentMood.value)
        assertEquals(SoundCue.PAGE_TURN, playedCues.last())

        // Entering Interrogation Room triggers footsteps & interrogation pulse
        manager.onScreenTransition(GameScreen.SUSPECT_SELECTION, GameScreen.INTERROGATION)
        assertEquals(AmbientNoirMood.INTERROGATION_PULSE, manager.currentMood.value)
        assertEquals(SoundCue.FOOTSTEPS, playedCues.last())

        // App lifecycle background pauses ambient, foreground resumes same mood
        manager.onAppBackground()
        assertFalse(manager.isAmbientActive.value)
        manager.onAppForeground()
        assertTrue(manager.isAmbientActive.value)
        assertEquals(AmbientNoirMood.INTERROGATION_PULSE, startedMoods.last())

        // Disabling ambient stops loop while SFX still fire
        manager.setAmbientEnabled(false)
        assertFalse(manager.isAmbientActive.value)
        val countBeforeSfx = playedCues.size
        manager.onZoneChanged()
        assertEquals(countBeforeSfx + 1, playedCues.size)
        assertEquals(SoundCue.FOOTSTEPS, playedCues.last())

        // Muting blocks SFX and stops ambient
        manager.setAmbientEnabled(true)
        assertTrue(manager.isAmbientActive.value)
        manager.setMuted(true)
        assertFalse(manager.isAmbientActive.value)
        manager.onDossierOrPageTurn()
        assertEquals(countBeforeSfx + 1, playedCues.size)
        assertTrue(stopCount > 0)
    }

    @Test
    fun `verify GameStateViewModel triggers SoundManager across screen transitions`() {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val vm = GameStateViewModel(app)

        vm.startNewInvestigation()
        assertEquals(AmbientNoirMood.INVESTIGATION_TENSION, vm.soundManager.currentMood.value)
        assertEquals(SoundCue.PAGE_TURN, vm.soundManager.lastTriggeredCue.value)

        vm.enterInvestigationPhase()
        assertEquals(SoundCue.FOOTSTEPS, vm.soundManager.lastTriggeredCue.value)

        vm.navigateTo(GameScreen.EVIDENCE_BOARD)
        assertEquals(AmbientNoirMood.BOARD_CONTEMPLATION, vm.soundManager.currentMood.value)
        assertEquals(SoundCue.PAGE_TURN, vm.soundManager.lastTriggeredCue.value)

        vm.enterInterrogationPhase(SuspectId.ADRIAN)
        assertEquals(AmbientNoirMood.INTERROGATION_PULSE, vm.soundManager.currentMood.value)
        assertEquals(SoundCue.FOOTSTEPS, vm.soundManager.lastTriggeredCue.value)

        vm.toggleAmbientMusic()
        assertFalse(vm.uiState.value.settings.ambientMusicEnabled)
        assertFalse(vm.soundManager.isAmbientActive.value)
    }

    @Test
    fun `verify Detectives Notebook create edit pin delete and persistence`() = runBlocking {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val vm = GameStateViewModel(app)

        vm.startNewInvestigation()
        vm.enterInterrogationPhase(SuspectId.ADRIAN)

        // Open Detective's Notebook from Interrogation and confirm page turn cue + back stack
        vm.navigateTo(GameScreen.NOTEBOOK)
        assertEquals(GameScreen.NOTEBOOK, vm.uiState.value.currentScreen)
        assertEquals(SoundCue.PAGE_TURN, vm.soundManager.lastTriggeredCue.value)

        // Blank note should be rejected
        assertNull(vm.saveDetectiveNote(title = "Empty", body = "   "))

        // Create observation linked to Adrian & a clue
        val created = vm.saveDetectiveNote(
            title = "10:55 PM Timeline Gap",
            body = "Adrian knew the espresso cup timing before Marcus logged the sweep.",
            category = NoteCategory.SUSPECT,
            linkedSuspectId = SuspectId.ADRIAN,
            linkedClueId = "clue_toxic_espresso"
        )
        assertNotNull(created)
        assertEquals(1, vm.uiState.value.progress.detectiveNotes.size)
        assertEquals(SuspectId.ADRIAN, vm.uiState.value.progress.detectiveNotes.first().linkedSuspectId)

        // Edit existing observation
        val noteId = created!!.id
        vm.saveDetectiveNote(
            noteId = noteId,
            title = "10:55 PM & Threshold Lead",
            body = "Check Suite B requisition slip against Adrian's executive credential #02.",
            category = NoteCategory.THEORY,
            linkedSuspectId = SuspectId.ADRIAN,
            linkedClueId = "clue_lab_requisition"
        )
        val updated = vm.uiState.value.progress.detectiveNotes.first()
        assertEquals("10:55 PM & Threshold Lead", updated.title)
        assertEquals(NoteCategory.THEORY, updated.category)

        // Pin & unpin observation
        vm.togglePinDetectiveNote(noteId)
        assertTrue(vm.uiState.value.progress.detectiveNotes.first().isPinned)
        vm.togglePinDetectiveNote(noteId)
        assertFalse(vm.uiState.value.progress.detectiveNotes.first().isPinned)

        // Persist & reload through GameProgressRepository
        val repo = GameProgressRepository(app)
        repo.saveProgress(vm.uiState.value.progress)
        val reloaded = repo.progressFlow.first()
        assertEquals(1, reloaded.detectiveNotes.size)
        assertEquals(noteId, reloaded.detectiveNotes.first().id)
        assertEquals("clue_lab_requisition", reloaded.detectiveNotes.first().linkedClueId)

        // Delete observation
        vm.deleteDetectiveNote(noteId)
        assertTrue(vm.uiState.value.progress.detectiveNotes.isEmpty())

        // Navigating back restores Interrogation Room
        assertTrue(vm.navigateBack())
        assertEquals(GameScreen.INTERROGATION, vm.uiState.value.currentScreen)
    }
}
